---
name: story-reviewer
description: >
  Review generated stories from the AI Story Writer. Lets the PO approve, reject,
  or request revisions on individual epics and stories before JIRA push.
when_to_use: >
  After the story-writer skill has generated a preview and the PO wants to
  review and provide feedback on individual items.
allowed-tools:
  - Read
  - Write
  - Glob
model: claude-sonnet-4-5-20250514
effort: medium
---

# Story Reviewer

Review generated stories and provide approval decisions.

## Step 1: Load Generated Preview

Read the most recently generated story preview. Look for files matching `*-story-preview.md` in the working directory, or ask the PO to specify the preview file path.

## Step 2: Present Review Checklist

For each Epic and Story, evaluate against the quality checklist in [review-checklist.md](review-checklist.md).

Flag any stories that:
- Exceed 13 story points (should be split)
- Have fewer than 2 acceptance criteria
- Use vague personas ("user" instead of a specific role)
- Have unclear or untestable acceptance criteria
- Missing Definition of Done items
- Have circular dependencies

## Step 3: Collect PO Decisions

For each item, the PO can:
- **Approve**: item is ready for JIRA
- **Reject**: item should not be created (provide reason)
- **Request Revision**: item needs changes (provide specific feedback)

## Step 4: Apply Decisions

Update the review status on each item and produce a summary:
- Total approved / rejected / needs-revision counts
- Specific feedback per item
- Recommendation on whether to proceed with JIRA push

## Step 5: Hand Off

If all items are approved (or PO confirms partial push), hand off to the `/push-to-jira` command.

If revisions are requested, hand back to the story-writer skill with the revision feedback.
