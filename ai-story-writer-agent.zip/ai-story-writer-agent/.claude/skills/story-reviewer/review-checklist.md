# Story Quality Review Checklist

## Epic Level

- [ ] Epic has a clear, concise title
- [ ] Description explains the scope and boundaries
- [ ] Business value is articulated (not just "needed by stakeholders")
- [ ] Acceptance criteria are verifiable
- [ ] T-shirt size estimate is reasonable for the scope
- [ ] Stories under the epic collectively deliver the full epic scope
- [ ] No orphan requirements from the PRD are missing

## User Story Level

- [ ] **Format**: follows "As a [persona], I want [action], so that [benefit]"
- [ ] **Persona**: specific role, not generic "user"
- [ ] **Action**: concrete and unambiguous
- [ ] **Benefit**: measurable business outcome
- [ ] **Size**: story points ≤ 13 (if higher, must be split)
- [ ] **Acceptance Criteria**: minimum 2, in Given/When/Then format
- [ ] **Testability**: each acceptance criterion is independently testable
- [ ] **Independence**: story can be delivered in a single sprint
- [ ] **Dependencies**: clearly listed and non-circular
- [ ] **Definition of Done**: includes all org-standard items
- [ ] **Labels/Components**: correctly categorized

## Sub-Task Level

- [ ] Each sub-task is completable in 1–8 hours
- [ ] Includes at minimum: implementation, testing, and review tasks
- [ ] Categories are correctly assigned
- [ ] Hour estimates are realistic
- [ ] Total sub-task hours align with story point estimate

## Overall Quality

- [ ] No duplicate stories across epics
- [ ] Sprint assignments respect dependencies
- [ ] Total story points are achievable within the target timeline
- [ ] All PRD requirements are covered
- [ ] Non-functional requirements are addressed in appropriate stories
