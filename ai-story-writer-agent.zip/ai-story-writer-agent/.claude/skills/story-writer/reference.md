# Story Writer Reference

## JIRA Field Mappings

The agent maps internal data models to JIRA fields via the org config at `config/org/default.json`.

### Standard Field Mapping

| Internal Field | JIRA Field | Notes |
|---------------|-----------|-------|
| `title` | `summary` | Direct mapping |
| `description` | `description` | Converted to Atlassian Document Format (ADF) |
| `storyPoints` | Configurable (`customfield_XXXXX`) | Varies per JIRA instance |
| `priority` | `priority.id` | Mapped via `priorityMapping` in config |
| `labels` | `labels` | Array of strings |
| `components` | `components` | Array of `{ name: string }` |
| `epicLink` | Configurable (`customfield_XXXXX`) | Links story to epic |

### Custom Fields

Custom fields are defined in `config.jira.customFields[]`. Each entry specifies:
- `internalField`: the field name in the story model
- `jiraFieldId`: the JIRA custom field ID (e.g., `customfield_10050`)
- `transform`: how to convert the value (`identity`, `join_array`, `map_value`, `format_date`)

### Discovering Custom Field IDs

Use the JIRA MCP to query available fields:
```
mcp__jira__get_project { projectKey: "PROJ" }
```

Or query the JIRA REST API:
```
GET /rest/api/3/field
```

## Story Format Standards

### User Story Statement
```
As a [persona], I want [action], so that [benefit].
```

- **Persona**: a specific user role, not "user" — e.g., "platform engineer", "PO", "QA analyst"
- **Action**: a concrete capability, not vague — e.g., "filter stories by sprint", not "manage stories"
- **Benefit**: a measurable business outcome — e.g., "I can plan the next sprint in under 30 minutes"

### Acceptance Criteria (Given/When/Then)
```
Given [precondition or context]
When [action or trigger]
Then [expected outcome]
```

Minimum 2 acceptance criteria per story. Each criterion should be independently testable.

### Story Point Scale (Fibonacci)

| Points | Complexity | Example |
|--------|-----------|---------|
| 1 | Trivial | Config change, copy update |
| 2 | Small | Simple UI component, single API field |
| 3 | Medium | New endpoint with validation, component with state |
| 5 | Large | Feature with multiple components, API with business logic |
| 8 | Very Large | Cross-service feature, complex data migration |
| 13 | Maximum | Should be considered for splitting |
| 21 | Too Large | Must be split into smaller stories |

### Sub-Task Categories

| Category | Typical Tasks |
|----------|--------------|
| `frontend` | UI components, styling, state management |
| `backend` | API endpoints, business logic, data processing |
| `api` | API contracts, OpenAPI specs, integration |
| `database` | Schema changes, migrations, indexing |
| `testing` | Unit tests, integration tests, E2E tests |
| `documentation` | API docs, runbooks, architecture docs |
| `devops` | CI/CD, infrastructure, monitoring |
| `security` | Auth, authorization, vulnerability fixes |
| `design` | UI/UX design, prototyping |
| `integration` | Third-party integrations, MCP servers |
| `infrastructure` | Cloud resources, networking, storage |

## Configuration

### Org Config Location
- Default: `config/org/default.json`
- Override: pass `--config <path>` or set env `ORG_CONFIG_PATH`

### Key Config Sections

**`jira.boardConfig`**: Sprint settings
- `teamVelocity`: story points the team completes per sprint (used for sprint assignment)
- `sprintDurationWeeks`: sprint length (used for capacity planning)

**`storyDefaults`**: Template defaults
- `definitionOfDoneTemplate`: default DoD checklist items applied to all stories
- `subTaskTemplates`: per-category sub-task templates
- `maxStoryPoints`: maximum points per story (stories above this are flagged for splitting)

**`promptOverrides`**: Customize LLM behavior
- `systemPromptAddendum`: additional context for the system prompt
- `terminology`: org-specific term mappings (e.g., "sprint" → "iteration")
- `exampleStories`: few-shot examples for better output quality
