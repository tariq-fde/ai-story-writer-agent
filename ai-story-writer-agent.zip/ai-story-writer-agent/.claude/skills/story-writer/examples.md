# Example: PRD to Stories Conversion

## Input PRD (excerpt)

```markdown
# User Authentication System

## Overview
Implement a modern authentication system supporting SSO, MFA, and session management
for the enterprise platform.

## Functional Requirements
1. Users can sign in with email/password or SSO (SAML 2.0, OIDC)
2. MFA support via TOTP authenticator apps
3. Session management with configurable timeout
4. Password reset via email verification
5. Audit logging for all authentication events

## Non-Functional Requirements
- Authentication latency < 200ms (P99)
- Support 10,000 concurrent sessions
- SOC 2 Type II compliance
```

## Generated Output

### Epic 1: Core Authentication

**Description:** Implement the foundational authentication flows including email/password sign-in, session management, and password reset.

**Business Value:** Enables secure user access to the platform, replacing the legacy auth system that lacks compliance controls.

**Size:** L | **Priority:** 1

---

#### Story 1: Email/Password Sign-In

> As a **platform user**, I want **to sign in with my email and password**, so that **I can securely access my workspace**.

**Points:** 5 | **Priority:** must-have | **Sprint:** 1

**Acceptance Criteria:**

1. **Valid credentials grant access**
   - Given a registered user with verified email
   - When they submit correct email and password on the login form
   - Then they are authenticated and redirected to the dashboard

2. **Invalid credentials are rejected**
   - Given a user attempting to sign in
   - When they submit an incorrect password
   - Then they see an error message and the attempt is logged

3. **Account lockout after failures**
   - Given a user who has failed authentication 5 times
   - When they attempt to sign in again
   - Then the account is locked for 15 minutes and they are notified

**Sub-Tasks:**

| Task | Category | Hours |
|------|----------|-------|
| Implement login API endpoint with bcrypt validation | backend | 4h |
| Build login form component with validation | frontend | 3h |
| Add account lockout logic and rate limiting | backend | 3h |
| Write unit tests for auth service | testing | 3h |
| Write E2E tests for login flow | testing | 2h |
| Update API documentation | documentation | 1h |

**Definition of Done:**
- [ ] Code reviewed and approved
- [ ] Unit tests passing with >80% coverage
- [ ] E2E tests passing
- [ ] API documentation updated
- [ ] Deployed to staging and verified

---

#### Story 2: Session Management

> As a **security administrator**, I want **configurable session timeouts and management**, so that **inactive sessions are automatically terminated per our compliance policy**.

**Points:** 5 | **Priority:** must-have | **Sprint:** 1

**Acceptance Criteria:**

1. **Sessions expire after configured timeout**
   - Given a user with an active session
   - When they are inactive for longer than the configured timeout (default 30 min)
   - Then their session is invalidated and they must re-authenticate

2. **Active sessions are visible and revocable**
   - Given an authenticated user
   - When they view their security settings
   - Then they see all active sessions and can revoke any of them

---

### Epic 2: SSO Integration

**Description:** Implement Single Sign-On support for SAML 2.0 and OpenID Connect identity providers.

**Business Value:** Enables enterprise customers to use their existing identity providers, reducing onboarding friction and meeting enterprise procurement requirements.

**Size:** L | **Priority:** 2

*(Stories continue...)*
