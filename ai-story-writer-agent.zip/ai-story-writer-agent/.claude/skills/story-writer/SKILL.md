---
name: story-writer
description: >
  Generate JIRA-ready Epics, User Stories, and Sub-Tasks from a PRD document.
  Produces structured Scrum artifacts with acceptance criteria, story points,
  and sprint assignments. Supports review-and-approve workflow before JIRA push.
when_to_use: >
  When a refined PRD is ready for story decomposition, when creating JIRA work items
  from requirements, or when breaking down features into implementable user stories.
argument-hint: "<prd-path>"
arguments: [prd]
context: fork
background: false
allowed-tools:
  - mcp__jira__create_issue
  - mcp__jira__search_issues
  - mcp__jira__get_issue
  - mcp__jira__bulk_create_issues
  - mcp__jira__get_project
  - mcp__confluence__get_page
  - mcp__confluence__search
  - mcp__github__search_code
  - mcp__github__get_file_contents
  - Bash(npm run *)
  - Read
  - Write
  - Glob
  - Grep
model: claude-sonnet-4-5-20250514
effort: high
---

# AI Story Writer Agent

Generate JIRA-ready Scrum work items from PRD: $ARGUMENTS

## Step 1: Load and Parse PRD

Read the PRD file at the path provided. If the argument is a Confluence page URL, use `mcp__confluence__get_page` to fetch its content.

Extract:
- Title and overview
- Functional requirements
- Non-functional requirements
- Technical constraints
- Dependencies
- Stakeholders

If the PRD references GitHub repositories for technical context, use `mcp__github__search_code` or `mcp__github__get_file_contents` to explore relevant code — never clone repositories locally.

## Step 2: Decompose PRD into Epics

Analyze the PRD and decompose it into **2–6 Epics**. Each epic should represent a cohesive, independently deliverable feature area.

For each Epic provide:
- **Title**: concise name for the JIRA epic
- **Description**: business context and scope
- **Business Value**: why this epic matters
- **Acceptance Criteria**: high-level criteria for the epic as a whole
- **T-shirt Size Estimate**: XS / S / M / L / XL
- **Priority**: ordering by dependency then business value
- **Labels and Components**: for JIRA categorization

Output the epics as a structured JSON array matching the `epicGenerationOutputSchema`.

## Step 3: Generate User Stories per Epic

For each Epic, generate **3–8 User Stories** in standard Scrum format.

Each story MUST include:
- **Title**: concise summary for the JIRA summary field
- **User Story Statement**: "As a [persona], I want [action], so that [benefit]"
- **Description**: detailed context for the development team
- **Acceptance Criteria** (minimum 2): in Given/When/Then format
- **Story Points**: Fibonacci scale (1, 2, 3, 5, 8, 13, 21) — no story exceeds 13 points
- **Priority**: MoSCoW (must-have, should-have, could-have, wont-have)
- **Dependencies**: references to other stories this one depends on
- **Definition of Done**: checklist items
- **Suggested Sprint**: based on dependencies and team velocity

Load the org config from `config/org/default.json` for:
- Team velocity (story points per sprint)
- Default labels and components
- Definition of Done template
- Story point estimation scale

Output stories as JSON matching the `storyGenerationOutputSchema`.

## Step 4: Generate Sub-Tasks per Story

For each User Story, generate **3–7 Sub-Tasks** representing the implementation work.

Each sub-task includes:
- **Title**: specific implementation task
- **Description**: what needs to be done
- **Category**: frontend / backend / api / database / testing / documentation / etc.
- **Estimated Hours**: 0.5 to 8 hours per sub-task
- **Technical Details**: implementation notes (optional)

At minimum include: implementation, unit tests, and code review sub-tasks.

## Step 5: Present Preview for Review

Format all generated items as a structured Markdown preview using the format from `packages/skill/src/formatters/markdown-preview.ts`.

Present the preview to the PO and ask for review:
- Approve all
- Approve specific epics/stories
- Request revisions on specific items
- Reject items with feedback

**DO NOT proceed to JIRA push without explicit PO approval.**

## Step 6: Push to JIRA (After Approval)

Only after the PO explicitly approves, create JIRA items in this order:
1. Create Epics using `mcp__jira__create_issue`
2. Create Stories linked to their parent Epics
3. Create Sub-Tasks linked to their parent Stories

For each created item, report back the JIRA key (e.g., PROJ-123) and URL.

If any creation fails, report the error and continue with remaining items.

## References

- [JIRA Field Mapping Reference](reference.md)
- [Example PRD-to-Stories Conversion](examples.md)
- [Org Config Schema](../../packages/core/src/schemas/config-schema.ts)
