Push approved stories to JIRA.

Usage: /push-to-jira [--dry-run]

Push all approved epics, stories, and sub-tasks to JIRA using MCP:
1. Validate that stories have been reviewed and approved
2. Build JIRA payloads using the org config field mappings
3. Create Epics first, then Stories linked to Epics, then Sub-Tasks linked to Stories
4. Report created JIRA keys and URLs

Use --dry-run to see what would be created without actually creating JIRA items.

Requires JIRA MCP to be configured in .mcp.json with a valid API token.
