Run the AI Story Writer skill to generate JIRA-ready epics and stories from a PRD.

Usage: /generate-stories <prd-path>

Read the PRD file at the given path, then invoke the story-writer skill to:
1. Parse and analyze the PRD
2. Decompose into Epics (2–6)
3. Generate User Stories per Epic (3–8 each)
4. Generate Sub-Tasks per Story (3–7 each)
5. Present a structured Markdown preview for PO review

If no path is provided, look for .md files in the current directory and ask which one to use.
