Review generated stories using the story-reviewer skill.

Usage: /review-stories [preview-path]

Load the most recently generated story preview and walk through the quality checklist:
1. Evaluate each Epic and Story against quality standards
2. Flag items that need attention
3. Collect approval/rejection/revision decisions
4. Produce a review summary

If no path is given, look for the most recent *-story-preview.md file.
