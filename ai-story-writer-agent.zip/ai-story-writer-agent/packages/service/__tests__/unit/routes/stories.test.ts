import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import express from 'express';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));

// Mock all external services before importing the route
vi.mock('../../../src/services/anthropic-service.js', () => ({
  callLlmForJson: vi.fn(),
}));
vi.mock('../../../src/services/firestore-service.js', () => ({
  savePrdDocument: vi.fn().mockResolvedValue(undefined),
  saveGenerationRun: vi.fn().mockResolvedValue(undefined),
  updateGenerationRun: vi.fn().mockResolvedValue(undefined),
  saveStoryPreview: vi.fn().mockResolvedValue(undefined),
  saveReviewSession: vi.fn().mockResolvedValue(undefined),
}));
vi.mock('../../../src/services/pubsub-service.js', () => ({
  publishEvent: vi.fn().mockResolvedValue('msg-id'),
}));
vi.mock('../../../src/config/env.js', () => ({
  getEnvConfig: () => ({
    PORT: 8080,
    NODE_ENV: 'test',
    GCP_PROJECT_ID: 'test-project',
    ANTHROPIC_API_KEY: 'test-key',
    JIRA_BASE_URL: 'https://test.atlassian.net',
    JIRA_API_TOKEN: 'test-token',
    JIRA_USER_EMAIL: 'test@example.com',
    CONFLUENCE_BASE_URL: 'https://test.atlassian.net',
    CONFLUENCE_API_TOKEN: 'test-token',
    CONFLUENCE_USER_EMAIL: 'test@example.com',
    GITHUB_PAT: 'ghp_test',
    FIRESTORE_COLLECTION_PREFIX: 'test',
    LOG_LEVEL: 'silent',
  }),
}));
vi.mock('../../../src/services/logger.js', () => ({
  logger: {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    debug: vi.fn(),
  },
}));

describe('POST /api/v1/stories/generate', () => {
  let app: express.Express;

  beforeEach(async () => {
    vi.clearAllMocks();

    const { callLlmForJson } = await import('../../../src/services/anthropic-service.js');
    const mockCallLlm = vi.mocked(callLlmForJson);

    // First call: epic generation
    mockCallLlm.mockResolvedValueOnce({
      parsed: {
        epics: [
          {
            title: 'Authentication Core',
            description: 'Core authentication functionality',
            businessValue: 'Enable secure user login',
            acceptanceCriteria: ['Users can log in'],
            estimate: { size: 'M' },
            priority: 1,
            labels: ['auth'],
            components: ['backend'],
          },
        ],
      },
      rawText: '{}',
      usage: { inputTokens: 100, outputTokens: 200 },
    });

    // Second call: story generation for the epic
    mockCallLlm.mockResolvedValueOnce({
      parsed: {
        stories: [
          {
            title: 'Implement email/password registration',
            userStoryStatement: {
              persona: 'new user',
              action: 'register with my email and password',
              benefit: 'I can create an account',
            },
            description: 'Implement registration endpoint',
            acceptanceCriteria: [
              {
                title: 'Valid registration',
                given: 'a valid email and password',
                when: 'the user submits the registration form',
                then: 'an account is created',
              },
              {
                title: 'Duplicate email',
                given: 'an email already in use',
                when: 'the user tries to register',
                then: 'an error is returned',
              },
            ],
            storyPoints: 5,
            priority: 'must-have',
            labels: ['auth', 'registration'],
            components: ['backend'],
            dependsOn: [],
            definitionOfDone: ['Tests passing', 'Code reviewed'],
            suggestedSprint: 1,
          },
        ],
      },
      rawText: '{}',
      usage: { inputTokens: 150, outputTokens: 300 },
    });

    const storiesRouter = (await import('../../../src/routes/stories.js')).default;
    const { errorHandler } = await import('../../../src/middleware/error-handler.js');

    app = express();
    app.use(express.json());
    app.use(storiesRouter);
    app.use(errorHandler);
  });

  it('returns 400 for missing prdMarkdown', async () => {
    const res = await request(app).post('/api/v1/stories/generate').send({ prdTitle: 'Test' });

    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
  });

  it('returns 400 for PRD that is too short', async () => {
    const res = await request(app)
      .post('/api/v1/stories/generate')
      .send({ prdMarkdown: 'Too short', prdTitle: 'Test' });

    expect(res.status).toBe(400);
  });

  it('generates stories from a valid PRD', async () => {
    const prdMarkdown = readFileSync(join(__dirname, '../../fixtures/mock-prd.md'), 'utf-8');

    const res = await request(app)
      .post('/api/v1/stories/generate')
      .send({ prdMarkdown, prdTitle: 'User Authentication System' });

    expect(res.status).toBe(201);
    expect(res.body.status).toBe('completed');
    expect(res.body.epics).toHaveLength(1);
    expect(res.body.epics[0].title).toBe('Authentication Core');
    expect(res.body.epics[0].stories).toHaveLength(1);
    expect(res.body.summary.epicCount).toBe(1);
    expect(res.body.summary.storyCount).toBe(1);
  });
});
