import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

vi.mock('../../../src/config/env.js', () => ({
  getEnvConfig: () => ({
    JIRA_BASE_URL: 'https://test.atlassian.net',
    JIRA_API_TOKEN: 'test-token',
    JIRA_USER_EMAIL: 'user@test.com',
  }),
}));

const mockFetch = vi.fn();
vi.stubGlobal('fetch', mockFetch);

describe('jira-service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('createIssue sends correct payload and returns result', async () => {
    const { createIssue } = await import('../../../src/services/jira-service.js');

    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        id: '10001',
        key: 'PROJ-42',
        self: 'https://test.atlassian.net/rest/api/3/issue/10001',
      }),
    });

    const result = await createIssue({
      fields: {
        project: { key: 'PROJ' },
        issuetype: { id: '10001' },
        summary: 'Test story',
        description: { type: 'doc', version: 1, content: [] },
      },
    });

    expect(result.key).toBe('PROJ-42');
    expect(result.id).toBe('10001');

    expect(mockFetch).toHaveBeenCalledOnce();
    const [url, opts] = mockFetch.mock.calls[0];
    expect(url).toBe('https://test.atlassian.net/rest/api/3/issue');
    expect(opts.method).toBe('POST');
    expect(opts.headers.Authorization).toMatch(/^Basic /);

    const body = JSON.parse(opts.body);
    expect(body.fields.summary).toBe('Test story');
  });

  it('createIssue throws on HTTP error', async () => {
    const { createIssue } = await import('../../../src/services/jira-service.js');

    mockFetch.mockResolvedValueOnce({
      ok: false,
      status: 400,
      text: async () => '{"errors":{"summary":"Field is required"}}',
    });

    await expect(
      createIssue({
        fields: {
          project: { key: 'PROJ' },
          issuetype: { id: '10001' },
          summary: '',
          description: { type: 'doc', version: 1, content: [] },
        },
      }),
    ).rejects.toThrow('JIRA createIssue failed (400)');
  });

  it('searchIssues passes JQL and returns results', async () => {
    const { searchIssues } = await import('../../../src/services/jira-service.js');

    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        issues: [{ id: '1', key: 'PROJ-1', self: '' }],
        total: 1,
        startAt: 0,
        maxResults: 50,
      }),
    });

    const result = await searchIssues('project = PROJ', 10);
    expect(result.total).toBe(1);
    expect(result.issues).toHaveLength(1);

    const [url] = mockFetch.mock.calls[0];
    expect(url).toContain('jql=project');
    expect(url).toContain('maxResults=10');
  });

  it('getProject returns project details', async () => {
    const { getProject } = await import('../../../src/services/jira-service.js');

    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        id: '10000',
        key: 'PROJ',
        name: 'Test Project',
        issueTypes: [
          { id: '10000', name: 'Epic', subtask: false },
          { id: '10001', name: 'Story', subtask: false },
          { id: '10003', name: 'Sub-task', subtask: true },
        ],
      }),
    });

    const result = await getProject('PROJ');
    expect(result.key).toBe('PROJ');
    expect(result.issueTypes).toHaveLength(3);
  });
});
