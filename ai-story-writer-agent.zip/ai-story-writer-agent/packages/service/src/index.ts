import { createApp } from './app.js';
import { logger } from './services/logger.js';
import { getEnvConfigSafe } from './config/env.js';

const configResult = getEnvConfigSafe();
if (!configResult.success) {
  logger.error({ issues: configResult.error.issues }, 'Invalid environment configuration');
  process.exit(1);
}

const app = createApp();
const port = configResult.data.PORT;

app.listen(port, () => {
  logger.info({ port, env: configResult.data.NODE_ENV }, 'AI Story Writer service started');
});
