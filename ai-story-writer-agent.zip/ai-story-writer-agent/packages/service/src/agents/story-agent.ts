import Anthropic from '@anthropic-ai/sdk';
import type { MessageParam, ContentBlockParam } from '@anthropic-ai/sdk/resources/messages.js';
import { getAnthropicClient } from '../config/anthropic.js';
import {
  jiraToolDefinitions,
  confluenceToolDefinitions,
  githubToolDefinitions,
  executeTool,
} from './tools/index.js';
import { logger } from '../services/logger.js';

const MODEL = 'claude-sonnet-4-5-20250514';
const MAX_TOKENS = 8192;
const MAX_TURNS = 20;

export interface StoryAgentOptions {
  systemPrompt: string;
  userMessage: string;
  enabledTools?: ('jira' | 'confluence' | 'github')[];
  maxTurns?: number;
}

export interface StoryAgentResult {
  finalText: string;
  toolCallsExecuted: number;
  totalInputTokens: number;
  totalOutputTokens: number;
}

export async function runStoryAgent(options: StoryAgentOptions): Promise<StoryAgentResult> {
  const client = getAnthropicClient();
  const enabledTools = options.enabledTools ?? ['jira', 'confluence', 'github'];
  const maxTurns = options.maxTurns ?? MAX_TURNS;

  const tools: Anthropic.Messages.Tool[] = [
    ...(enabledTools.includes('jira') ? jiraToolDefinitions : []),
    ...(enabledTools.includes('confluence') ? confluenceToolDefinitions : []),
    ...(enabledTools.includes('github') ? githubToolDefinitions : []),
  ];

  const messages: MessageParam[] = [{ role: 'user', content: options.userMessage }];

  let toolCallsExecuted = 0;
  let totalInputTokens = 0;
  let totalOutputTokens = 0;
  let finalText = '';

  for (let turn = 0; turn < maxTurns; turn++) {
    const response = await client.messages.create({
      model: MODEL,
      max_tokens: MAX_TOKENS,
      system: options.systemPrompt,
      tools,
      messages,
    });

    totalInputTokens += response.usage.input_tokens;
    totalOutputTokens += response.usage.output_tokens;

    // Collect text blocks from this response
    for (const block of response.content) {
      if (block.type === 'text') {
        finalText += block.text;
      }
    }

    if (response.stop_reason === 'end_turn') {
      logger.info({ turn, toolCallsExecuted }, 'Agent completed');
      break;
    }

    if (response.stop_reason !== 'tool_use') {
      logger.warn({ stopReason: response.stop_reason, turn }, 'Unexpected stop reason');
      break;
    }

    // Process tool calls
    messages.push({ role: 'assistant', content: response.content });

    const toolResults: ContentBlockParam[] = [];

    for (const block of response.content) {
      if (block.type !== 'tool_use') continue;

      toolCallsExecuted++;
      logger.info({ tool: block.name, turn, callNumber: toolCallsExecuted }, 'Executing tool call');

      try {
        const result = await executeTool(block.name, block.input as Record<string, unknown>);
        toolResults.push({
          type: 'tool_result',
          tool_use_id: block.id,
          content: result,
        } as unknown as ContentBlockParam);
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        logger.error({ tool: block.name, error: errorMsg }, 'Tool execution failed');
        toolResults.push({
          type: 'tool_result',
          tool_use_id: block.id,
          content: JSON.stringify({ error: errorMsg }),
          is_error: true,
        } as unknown as ContentBlockParam);
      }
    }

    messages.push({ role: 'user', content: toolResults });
  }

  return {
    finalText,
    toolCallsExecuted,
    totalInputTokens,
    totalOutputTokens,
  };
}
