import * as jiraService from '../../services/jira-service.js';
import * as confluenceService from '../../services/confluence-service.js';
import * as githubService from '../../services/github-service.js';
import { logger } from '../../services/logger.js';

export async function executeTool(
  toolName: string,
  input: Record<string, unknown>,
): Promise<string> {
  logger.debug({ toolName, input }, 'Executing tool');

  switch (toolName) {
    case 'jira_create_issue':
      return executeJiraCreateIssue(input);
    case 'jira_search':
      return executeJiraSearch(input);
    case 'jira_get_project':
      return executeJiraGetProject(input);
    case 'confluence_get_page':
      return executeConfluenceGetPage(input);
    case 'confluence_search':
      return executeConfluenceSearch(input);
    case 'github_search_code':
      return executeGithubSearchCode(input);
    case 'github_get_file':
      return executeGithubGetFile(input);
    case 'github_search_repos':
      return executeGithubSearchRepos(input);
    default:
      return JSON.stringify({ error: `Unknown tool: ${toolName}` });
  }
}

async function executeJiraCreateIssue(input: Record<string, unknown>): Promise<string> {
  const payload = {
    fields: {
      project: { key: input.projectKey as string },
      issuetype: { id: input.issueTypeId as string },
      summary: input.summary as string,
      description: {
        type: 'doc' as const,
        version: 1 as const,
        content: [
          {
            type: 'paragraph',
            content: [{ type: 'text', text: input.description as string }],
          },
        ],
      },
      ...(input.priority ? { priority: { name: input.priority as string } } : {}),
      ...(input.labels ? { labels: input.labels as string[] } : {}),
    },
  };

  const result = await jiraService.createIssue(payload);
  return JSON.stringify({ key: result.key, id: result.id, self: result.self });
}

async function executeJiraSearch(input: Record<string, unknown>): Promise<string> {
  const result = await jiraService.searchIssues(
    input.jql as string,
    (input.maxResults as number) ?? 20,
  );
  return JSON.stringify({
    total: result.total,
    issues: result.issues.map((i) => ({ key: i.key, id: i.id })),
  });
}

async function executeJiraGetProject(input: Record<string, unknown>): Promise<string> {
  const result = await jiraService.getProject(input.projectKey as string);
  return JSON.stringify({
    key: result.key,
    name: result.name,
    issueTypes: result.issueTypes.map((it) => ({
      id: it.id,
      name: it.name,
      subtask: it.subtask,
    })),
  });
}

async function executeConfluenceGetPage(input: Record<string, unknown>): Promise<string> {
  const result = await confluenceService.getPage(
    input.pageId as string,
    (input.expand as string) ?? 'body.storage,version',
  );
  return JSON.stringify({
    id: result.id,
    title: result.title,
    body: result.body?.storage?.value ?? '',
    version: result.version.number,
  });
}

async function executeConfluenceSearch(input: Record<string, unknown>): Promise<string> {
  const result = await confluenceService.searchPages(
    input.cql as string,
    (input.limit as number) ?? 25,
  );
  return JSON.stringify({
    total: result.totalSize,
    results: result.results.map((r) => ({
      id: r.id,
      title: r.title,
      status: r.status,
    })),
  });
}

async function executeGithubSearchCode(input: Record<string, unknown>): Promise<string> {
  const result = await githubService.searchCode(
    input.query as string,
    (input.perPage as number) ?? 30,
  );
  return JSON.stringify({
    total: result.total_count,
    items: result.items.map((item) => ({
      name: item.name,
      path: item.path,
      repo: item.repository.full_name,
      url: item.html_url,
    })),
  });
}

async function executeGithubGetFile(input: Record<string, unknown>): Promise<string> {
  const result = await githubService.getFileContents(
    input.owner as string,
    input.repo as string,
    input.path as string,
    input.ref as string | undefined,
  );

  const decoded =
    result.encoding === 'base64' ? Buffer.from(result.content, 'base64').toString('utf-8') : result.content;

  return JSON.stringify({
    name: result.name,
    path: result.path,
    size: result.size,
    content: decoded.length > 10000 ? decoded.slice(0, 10000) + '\n...[truncated]' : decoded,
  });
}

async function executeGithubSearchRepos(input: Record<string, unknown>): Promise<string> {
  const result = await githubService.searchRepositories(
    input.query as string,
    (input.perPage as number) ?? 10,
  );
  return JSON.stringify({
    total: result.total_count,
    repos: result.items.map((r) => ({
      fullName: r.full_name,
      description: r.description,
      url: r.html_url,
      language: r.language,
      defaultBranch: r.default_branch,
    })),
  });
}
