import type Anthropic from '@anthropic-ai/sdk';

export const confluenceToolDefinitions: Anthropic.Messages.Tool[] = [
  {
    name: 'confluence_get_page',
    description: 'Retrieve a Confluence page by its ID. Returns the page title, body content, and version.',
    input_schema: {
      type: 'object' as const,
      properties: {
        pageId: { type: 'string', description: 'The Confluence page ID' },
        expand: {
          type: 'string',
          description: 'Comma-separated fields to expand (default: body.storage,version)',
        },
      },
      required: ['pageId'],
    },
  },
  {
    name: 'confluence_search',
    description: 'Search Confluence pages using CQL (Confluence Query Language). Returns matching pages.',
    input_schema: {
      type: 'object' as const,
      properties: {
        cql: { type: 'string', description: 'CQL query string (e.g., "type=page AND text~\\"search term\\"")' },
        limit: { type: 'number', description: 'Maximum results (default 25)' },
      },
      required: ['cql'],
    },
  },
];
