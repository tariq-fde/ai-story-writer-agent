import type Anthropic from '@anthropic-ai/sdk';

export const jiraToolDefinitions: Anthropic.Messages.Tool[] = [
  {
    name: 'jira_create_issue',
    description:
      'Create a single issue in JIRA. Use for creating epics, stories, or sub-tasks. Returns the created issue key and URL.',
    input_schema: {
      type: 'object' as const,
      properties: {
        projectKey: { type: 'string', description: 'The JIRA project key (e.g., "PROJ")' },
        issueTypeId: { type: 'string', description: 'The issue type ID' },
        summary: { type: 'string', description: 'Issue summary/title' },
        description: { type: 'string', description: 'Issue description in plain text' },
        priority: { type: 'string', description: 'Priority name (Highest, High, Medium, Low, Lowest)' },
        labels: { type: 'array', items: { type: 'string' }, description: 'Labels to apply' },
        epicKey: { type: 'string', description: 'Parent epic key for stories' },
        parentKey: { type: 'string', description: 'Parent story key for sub-tasks' },
        storyPoints: { type: 'number', description: 'Story point estimate' },
      },
      required: ['projectKey', 'issueTypeId', 'summary', 'description'],
    },
  },
  {
    name: 'jira_search',
    description: 'Search JIRA issues using JQL. Returns matching issues with key, summary, status, and type.',
    input_schema: {
      type: 'object' as const,
      properties: {
        jql: { type: 'string', description: 'JQL query string' },
        maxResults: { type: 'number', description: 'Maximum results to return (default 20)' },
      },
      required: ['jql'],
    },
  },
  {
    name: 'jira_get_project',
    description: 'Get JIRA project details including available issue types and components.',
    input_schema: {
      type: 'object' as const,
      properties: {
        projectKey: { type: 'string', description: 'The JIRA project key' },
      },
      required: ['projectKey'],
    },
  },
];
