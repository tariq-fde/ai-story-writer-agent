import type Anthropic from '@anthropic-ai/sdk';

export const githubToolDefinitions: Anthropic.Messages.Tool[] = [
  {
    name: 'github_search_code',
    description:
      'Search for code across GitHub repositories. Useful for finding implementations, API patterns, and code references without cloning repos locally.',
    input_schema: {
      type: 'object' as const,
      properties: {
        query: {
          type: 'string',
          description: 'GitHub code search query (e.g., "auth middleware repo:org/repo language:typescript")',
        },
        perPage: { type: 'number', description: 'Results per page (default 30, max 100)' },
      },
      required: ['query'],
    },
  },
  {
    name: 'github_get_file',
    description:
      'Get the contents of a specific file from a GitHub repository. Returns the decoded file content.',
    input_schema: {
      type: 'object' as const,
      properties: {
        owner: { type: 'string', description: 'Repository owner (org or user)' },
        repo: { type: 'string', description: 'Repository name' },
        path: { type: 'string', description: 'File path within the repository' },
        ref: { type: 'string', description: 'Branch, tag, or commit SHA (default: default branch)' },
      },
      required: ['owner', 'repo', 'path'],
    },
  },
  {
    name: 'github_search_repos',
    description: 'Search for GitHub repositories by name, description, or topic.',
    input_schema: {
      type: 'object' as const,
      properties: {
        query: { type: 'string', description: 'Repository search query' },
        perPage: { type: 'number', description: 'Results per page (default 10)' },
      },
      required: ['query'],
    },
  },
];
