import type { Epic, GenerationRun, ReviewSession } from '@ai-story-writer/core';

export interface GenerateStoriesRequest {
  prdMarkdown: string;
  prdTitle: string;
  orgConfigId?: string;
  options?: {
    maxEpics?: number;
    maxStoriesPerEpic?: number;
    includeSubTasks?: boolean;
  };
}

export interface GenerateStoriesResponse {
  runId: string;
  previewId: string;
  status: 'completed' | 'failed';
  epics: Epic[];
  summary: {
    epicCount: number;
    storyCount: number;
    subTaskCount: number;
    totalStoryPoints: number;
  };
}

export interface GetReviewResponse {
  review: ReviewSession;
  preview: {
    epics: Epic[];
  };
}

export interface ApproveReviewRequest {
  reviewer: string;
  comments?: string;
}

export interface RejectReviewRequest {
  reviewer: string;
  comments: string;
  rejectedItems?: Array<{
    targetType: 'epic' | 'story' | 'subtask';
    targetId: string;
    reason: string;
  }>;
}

export interface JiraPushRequest {
  previewId: string;
  projectKey?: string;
  dryRun?: boolean;
}

export interface JiraPushResponse {
  success: boolean;
  dryRun: boolean;
  created: Array<{
    internalId: string;
    jiraKey: string;
    issueType: 'epic' | 'story' | 'subtask';
    selfUrl: string;
  }>;
  errors: Array<{
    internalId: string;
    issueType: 'epic' | 'story' | 'subtask';
    error: string;
  }>;
}

export interface WebhookPayload {
  message: {
    data: string;
    messageId: string;
    publishTime: string;
    attributes?: Record<string, string>;
  };
  subscription: string;
}

export interface HealthResponse {
  status: 'ok';
  version: string;
  timestamp: string;
}

export interface ErrorResponse {
  error: {
    code: string;
    message: string;
    details?: unknown;
  };
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    total: number;
    offset: number;
    limit: number;
  };
}
