import Anthropic from '@anthropic-ai/sdk';
import { getEnvConfig } from './env.js';

let _client: Anthropic | undefined;

export function getAnthropicClient(): Anthropic {
  if (!_client) {
    const config = getEnvConfig();
    _client = new Anthropic({ apiKey: config.ANTHROPIC_API_KEY });
  }
  return _client;
}
