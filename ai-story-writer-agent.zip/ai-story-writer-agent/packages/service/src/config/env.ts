import { z } from 'zod';

const envSchema = z.object({
  PORT: z.coerce.number().default(8080),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  GCP_PROJECT_ID: z.string().min(1),
  ANTHROPIC_API_KEY: z.string().min(1),
  JIRA_BASE_URL: z.string().url(),
  JIRA_API_TOKEN: z.string().min(1),
  JIRA_USER_EMAIL: z.string().email(),
  CONFLUENCE_BASE_URL: z.string().url(),
  CONFLUENCE_API_TOKEN: z.string().min(1),
  CONFLUENCE_USER_EMAIL: z.string().email(),
  GITHUB_PAT: z.string().min(1),
  FIRESTORE_COLLECTION_PREFIX: z.string().default('story-writer'),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace']).default('info'),
});

export type EnvConfig = z.infer<typeof envSchema>;

let _config: EnvConfig | undefined;

export function getEnvConfig(): EnvConfig {
  if (!_config) {
    _config = envSchema.parse(process.env);
  }
  return _config;
}

export function getEnvConfigSafe(): { success: true; data: EnvConfig } | { success: false; error: z.ZodError } {
  const result = envSchema.safeParse(process.env);
  if (result.success) {
    _config = result.data;
  }
  return result;
}
