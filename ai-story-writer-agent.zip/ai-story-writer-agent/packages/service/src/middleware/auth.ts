import type { Request, Response, NextFunction } from 'express';
import { AppError } from './error-handler.js';
import { getEnvConfig } from '../config/env.js';

export function authMiddleware(req: Request, _res: Response, next: NextFunction): void {
  const config = getEnvConfig();

  if (config.NODE_ENV === 'development') {
    next();
    return;
  }

  const authHeader = req.headers.authorization;
  if (!authHeader) {
    next(new AppError(401, 'UNAUTHORIZED', 'Missing Authorization header'));
    return;
  }

  const [scheme, token] = authHeader.split(' ');

  if (scheme === 'Bearer' && token) {
    // In production, validate GCP IAM token or service-to-service token.
    // For now, we accept any bearer token and leave full IAM validation
    // to the Cloud Run IAM invoker policy.
    req.headers['x-authenticated'] = 'true';
    next();
    return;
  }

  if (scheme === 'ApiKey' && token) {
    req.headers['x-authenticated'] = 'true';
    next();
    return;
  }

  next(new AppError(401, 'UNAUTHORIZED', 'Invalid Authorization scheme. Use "Bearer <token>" or "ApiKey <key>"'));
}
