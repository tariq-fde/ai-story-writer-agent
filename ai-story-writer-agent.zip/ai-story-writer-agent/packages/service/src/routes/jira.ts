import { Router } from 'express';
import { z } from 'zod';
import type { Epic, JiraCreateIssuePayload } from '@ai-story-writer/core';
import * as jiraService from '../services/jira-service.js';
import * as firestoreService from '../services/firestore-service.js';
import * as pubsubService from '../services/pubsub-service.js';
import { AppError } from '../middleware/error-handler.js';
import { logger } from '../services/logger.js';
import type { JiraPushRequest, JiraPushResponse } from '../types/api.js';

const router = Router();

const pushSchema = z.object({
  previewId: z.string().uuid(),
  projectKey: z.string().min(1).max(10).optional(),
  dryRun: z.boolean().optional(),
});

router.post('/api/v1/jira/push', async (req, res, next) => {
  try {
    const body = pushSchema.parse(req.body) as JiraPushRequest;

    const preview = await firestoreService.getStoryPreview(body.previewId);
    if (!preview) {
      throw new AppError(404, 'NOT_FOUND', `Story preview ${body.previewId} not found`);
    }

    const projectKey = body.projectKey ?? 'PROJ';

    if (body.dryRun) {
      const payloads = buildAllPayloads(preview.epics, projectKey);
      const response: JiraPushResponse = {
        success: true,
        dryRun: true,
        created: payloads.map((p) => ({
          internalId: p.fields.summary,
          jiraKey: `${projectKey}-DRY`,
          issueType: inferType(p.fields.issuetype.id),
          selfUrl: '',
        })),
        errors: [],
      };
      res.json(response);
      return;
    }

    const payloads = buildAllPayloads(preview.epics, projectKey);
    const result = await jiraService.bulkCreateIssues(payloads);

    await pubsubService
      .publishEvent('jira-pushed', {
        previewId: body.previewId,
        projectKey,
        createdCount: result.createdIssues.length,
        errorCount: result.errors.length,
      })
      .catch((err) => logger.warn({ err }, 'Failed to publish jira-pushed event'));

    logger.info(
      { previewId: body.previewId, created: result.createdIssues.length, errors: result.errors.length },
      'JIRA push completed',
    );

    const response: JiraPushResponse = {
      success: result.success,
      dryRun: false,
      created: result.createdIssues.map((i) => ({
        internalId: i.internalId,
        jiraKey: i.jiraKey,
        issueType: i.issueType,
        selfUrl: i.selfUrl,
      })),
      errors: result.errors.map((e) => ({
        internalId: e.internalId,
        issueType: e.issueType,
        error: e.error,
      })),
    };

    res.status(result.success ? 201 : 207).json(response);
  } catch (err) {
    next(err);
  }
});

export default router;

function buildAllPayloads(epics: Epic[], projectKey: string): JiraCreateIssuePayload[] {
  const payloads: JiraCreateIssuePayload[] = [];

  for (const epic of epics) {
    payloads.push({
      fields: {
        project: { key: projectKey },
        issuetype: { id: '10000' },
        summary: epic.title,
        description: {
          type: 'doc',
          version: 1,
          content: [
            {
              type: 'paragraph',
              content: [{ type: 'text', text: epic.description }],
            },
          ],
        },
        labels: epic.labels,
        components: epic.components.map((c) => ({ name: c })),
      },
    });

    for (const story of epic.stories) {
      const storyStatement = `As a ${story.userStoryStatement.persona}, I want ${story.userStoryStatement.action}, so that ${story.userStoryStatement.benefit}`;
      const acText = story.acceptanceCriteria
        .map((ac) => `**${ac.title}**\nGiven ${ac.given}\nWhen ${ac.when}\nThen ${ac.then}`)
        .join('\n\n');

      payloads.push({
        fields: {
          project: { key: projectKey },
          issuetype: { id: '10001' },
          summary: story.title,
          description: {
            type: 'doc',
            version: 1,
            content: [
              { type: 'paragraph', content: [{ type: 'text', text: storyStatement }] },
              {
                type: 'heading',
                attrs: { level: 3 },
                content: [{ type: 'text', text: 'Acceptance Criteria' }],
              },
              { type: 'paragraph', content: [{ type: 'text', text: acText }] },
            ],
          },
          labels: story.labels,
          components: story.components.map((c) => ({ name: c })),
        },
      });

      for (const task of story.subTasks) {
        payloads.push({
          fields: {
            project: { key: projectKey },
            issuetype: { id: '10003' },
            summary: task.title,
            description: {
              type: 'doc',
              version: 1,
              content: [
                { type: 'paragraph', content: [{ type: 'text', text: task.description }] },
              ],
            },
            labels: task.labels,
          },
        });
      }
    }
  }

  return payloads;
}

function inferType(typeId: string): 'epic' | 'story' | 'subtask' {
  if (typeId === '10000') return 'epic';
  if (typeId === '10003') return 'subtask';
  return 'story';
}
