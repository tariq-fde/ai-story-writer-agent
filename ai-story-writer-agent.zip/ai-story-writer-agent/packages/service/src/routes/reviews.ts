import { Router } from 'express';
import { z } from 'zod';
import * as firestoreService from '../services/firestore-service.js';
import * as pubsubService from '../services/pubsub-service.js';
import { AppError } from '../middleware/error-handler.js';
import { logger } from '../services/logger.js';
import type { ApproveReviewRequest, RejectReviewRequest, GetReviewResponse } from '../types/api.js';

const router = Router();

router.get('/api/v1/reviews/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const session = await firestoreService.getReviewSession(id);
    if (!session) {
      throw new AppError(404, 'NOT_FOUND', `Review session ${id} not found`);
    }

    const preview = await firestoreService.getStoryPreview(session.previewId);
    if (!preview) {
      throw new AppError(404, 'NOT_FOUND', `Story preview ${session.previewId} not found`);
    }

    const response: GetReviewResponse = {
      review: session,
      preview: { epics: preview.epics },
    };

    res.json(response);
  } catch (err) {
    next(err);
  }
});

const approveSchema = z.object({
  reviewer: z.string().min(1),
  comments: z.string().optional(),
});

router.put('/api/v1/reviews/:id/approve', async (req, res, next) => {
  try {
    const { id } = req.params;
    const body = approveSchema.parse(req.body) as ApproveReviewRequest;

    const session = await firestoreService.getReviewSession(id);
    if (!session) {
      throw new AppError(404, 'NOT_FOUND', `Review session ${id} not found`);
    }

    if (session.status === 'approved') {
      throw new AppError(409, 'ALREADY_APPROVED', 'This review has already been approved');
    }

    await firestoreService.updateReviewSession(id, {
      status: 'approved',
      reviewer: body.reviewer,
      updatedAt: new Date().toISOString(),
    });

    await pubsubService
      .publishEvent('story-approved', {
        reviewId: id,
        previewId: session.previewId,
        reviewer: body.reviewer,
      })
      .catch((err) => logger.warn({ err }, 'Failed to publish story-approved event'));

    logger.info({ reviewId: id, reviewer: body.reviewer }, 'Review approved');

    res.json({ status: 'approved', reviewId: id, previewId: session.previewId });
  } catch (err) {
    next(err);
  }
});

const rejectSchema = z.object({
  reviewer: z.string().min(1),
  comments: z.string().min(1),
  rejectedItems: z
    .array(
      z.object({
        targetType: z.enum(['epic', 'story', 'subtask']),
        targetId: z.string().min(1),
        reason: z.string().min(1),
      }),
    )
    .optional(),
});

router.put('/api/v1/reviews/:id/reject', async (req, res, next) => {
  try {
    const { id } = req.params;
    const body = rejectSchema.parse(req.body) as RejectReviewRequest;

    const session = await firestoreService.getReviewSession(id);
    if (!session) {
      throw new AppError(404, 'NOT_FOUND', `Review session ${id} not found`);
    }

    const newComments = [
      ...session.comments,
      {
        id: `comment-${Date.now()}`,
        author: body.reviewer,
        timestamp: new Date().toISOString(),
        comment: body.comments,
        targetType: 'epic' as const,
        targetId: 'general',
        resolved: false,
      },
    ];

    await firestoreService.updateReviewSession(id, {
      status: 'rejected',
      reviewer: body.reviewer,
      comments: newComments,
      updatedAt: new Date().toISOString(),
    });

    logger.info({ reviewId: id, reviewer: body.reviewer }, 'Review rejected');

    res.json({ status: 'rejected', reviewId: id, comments: body.comments });
  } catch (err) {
    next(err);
  }
});

export default router;
