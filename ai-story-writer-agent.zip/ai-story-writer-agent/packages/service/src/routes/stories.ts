import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import type { Epic } from '@ai-story-writer/core';
import { callLlmForJson } from '../services/anthropic-service.js';
import * as firestoreService from '../services/firestore-service.js';
import * as pubsubService from '../services/pubsub-service.js';
import { AppError } from '../middleware/error-handler.js';
import { logger } from '../services/logger.js';
import type { GenerateStoriesRequest, GenerateStoriesResponse } from '../types/api.js';

const router = Router();

const generateRequestSchema = z.object({
  prdMarkdown: z.string().min(50, 'PRD markdown must be at least 50 characters'),
  prdTitle: z.string().min(1),
  orgConfigId: z.string().optional(),
  options: z
    .object({
      maxEpics: z.number().int().min(1).max(10).optional(),
      maxStoriesPerEpic: z.number().int().min(1).max(15).optional(),
      includeSubTasks: z.boolean().optional(),
    })
    .optional(),
});

router.post('/api/v1/stories/generate', async (req, res, next) => {
  try {
    const body = generateRequestSchema.parse(req.body) as GenerateStoriesRequest;
    const runId = randomUUID();
    const previewId = randomUUID();
    const prdId = randomUUID();

    // Save PRD document
    await firestoreService.savePrdDocument({
      id: prdId,
      title: body.prdTitle,
      rawMarkdown: body.prdMarkdown,
      metadata: { orgConfigId: body.orgConfigId },
    });

    // Save generation run (in progress)
    await firestoreService.saveGenerationRun({
      id: runId,
      prdId,
      status: 'in_progress',
      epicCount: 0,
      storyCount: 0,
      subTaskCount: 0,
      startedAt: new Date().toISOString(),
    });

    logger.info({ runId, prdId, prdTitle: body.prdTitle }, 'Starting story generation');

    const systemPrompt = buildSystemPrompt();
    const epicPrompt = buildEpicPrompt(body.prdMarkdown, body.prdTitle, body.options?.maxEpics);

    // Step 1: Generate epics
    const epicResult = await callLlmForJson(
      { systemPrompt, userPrompt: epicPrompt },
      (text) => {
        const parsed = JSON.parse(text);
        if (!parsed.epics || !Array.isArray(parsed.epics)) {
          throw new Error('Response must contain an "epics" array');
        }
        return parsed as { epics: RawEpic[] };
      },
    );

    // Step 2: Generate stories for each epic
    const maxStories = body.options?.maxStoriesPerEpic ?? 8;
    const includeSubTasks = body.options?.includeSubTasks ?? true;
    const epics: Epic[] = [];

    for (const [index, rawEpic] of epicResult.parsed.epics.entries()) {
      const storyPrompt = buildStoryPrompt(rawEpic, body.prdMarkdown, maxStories);

      const storyResult = await callLlmForJson(
        { systemPrompt, userPrompt: storyPrompt },
        (text) => {
          const parsed = JSON.parse(text);
          if (!parsed.stories || !Array.isArray(parsed.stories)) {
            throw new Error('Response must contain a "stories" array');
          }
          return parsed as { stories: RawStory[] };
        },
      );

      const epicId = randomUUID();
      const stories = storyResult.parsed.stories.map((s, si) => ({
        id: randomUUID(),
        epicId,
        title: s.title,
        userStoryStatement: s.userStoryStatement,
        description: s.description,
        acceptanceCriteria: (s.acceptanceCriteria ?? []).map((ac: RawAc, ai: number) => ({
          id: `ac-${si}-${ai}`,
          ...ac,
        })),
        storyPoints: s.storyPoints,
        priority: s.priority ?? 'should-have',
        labels: s.labels ?? [],
        components: s.components ?? [],
        dependsOn: s.dependsOn ?? [],
        subTasks: [],
        technicalNotes: s.technicalNotes,
        definitionOfDone: s.definitionOfDone ?? [
          'Code reviewed and approved',
          'Unit tests passing',
          'Deployed to staging',
        ],
        suggestedSprint: s.suggestedSprint,
        reviewStatus: 'draft' as const,
        reviewComments: [],
      }));

      const totalStoryPoints = stories.reduce((sum, s) => sum + (s.storyPoints ?? 0), 0);

      epics.push({
        id: epicId,
        prdId,
        title: rawEpic.title,
        description: rawEpic.description,
        businessValue: rawEpic.businessValue ?? '',
        acceptanceCriteria: rawEpic.acceptanceCriteria ?? [],
        estimate: {
          size: rawEpic.estimate?.size ?? 'M',
          totalStoryPoints,
          estimatedSprintCount: Math.ceil(totalStoryPoints / 40),
        },
        priority: rawEpic.priority ?? index + 1,
        labels: rawEpic.labels ?? [],
        components: rawEpic.components ?? [],
        stories,
        reviewStatus: 'draft',
      });
    }

    const storyCount = epics.reduce((sum, e) => sum + e.stories.length, 0);
    const subTaskCount = epics.reduce(
      (sum, e) => sum + e.stories.reduce((s2, s) => s2 + s.subTasks.length, 0),
      0,
    );
    const totalPoints = epics.reduce(
      (sum, e) => sum + e.stories.reduce((s2, s) => s2 + s.storyPoints, 0),
      0,
    );

    // Save preview and update run
    await firestoreService.saveStoryPreview({ id: previewId, runId, epics });
    await firestoreService.updateGenerationRun(runId, {
      status: 'completed',
      epicCount: epics.length,
      storyCount,
      subTaskCount,
      completedAt: new Date().toISOString(),
    });

    // Create review session
    await firestoreService.saveReviewSession({
      id: randomUUID(),
      previewId,
      reviewer: '',
      status: 'draft',
      comments: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    // Publish event
    await pubsubService
      .publishEvent('story-generated', { runId, previewId, epicCount: epics.length, storyCount })
      .catch((err) => logger.warn({ err }, 'Failed to publish story-generated event'));

    const response: GenerateStoriesResponse = {
      runId,
      previewId,
      status: 'completed',
      epics,
      summary: {
        epicCount: epics.length,
        storyCount,
        subTaskCount,
        totalStoryPoints: totalPoints,
      },
    };

    res.status(201).json(response);
  } catch (err) {
    next(err);
  }
});

export default router;

// --- Prompt builders (local to this route) ---

function buildSystemPrompt(): string {
  return `You are an expert Agile Product Owner assistant specializing in Scrum story writing.
Your job is to decompose Product Requirements Documents (PRDs) into well-structured JIRA-ready work items following the hierarchy: Epic > User Story > Sub-Task.

Output Standards:
- User stories MUST follow "As a <persona>, I want <action>, so that <benefit>"
- Acceptance criteria MUST follow Given/When/Then format
- Story points use Fibonacci scale: 1, 2, 3, 5, 8, 13, 21
- Stories exceeding 13 points must be split
- Every story must have at least 2 acceptance criteria
- Sub-tasks must be independently completable within a sprint

IMPORTANT: Respond with ONLY valid JSON. No markdown fences, no commentary outside the JSON.`;
}

function buildEpicPrompt(prdMarkdown: string, title: string, maxEpics?: number): string {
  return `Analyze the following PRD and decompose it into Epics.

## PRD: ${title}
${prdMarkdown}

## Instructions
1. Identify ${maxEpics ? `up to ${maxEpics}` : '2-6'} distinct Epics that together cover all PRD requirements
2. Each Epic should represent a cohesive deliverable
3. Order Epics by dependency (prerequisite epics first) then priority
4. For each Epic provide: title, description, businessValue, acceptanceCriteria array, estimate object with size (XS/S/M/L/XL), priority number, labels array, components array

Respond with JSON: { "epics": [{ "title": "...", "description": "...", "businessValue": "...", "acceptanceCriteria": ["..."], "estimate": { "size": "M" }, "priority": 1, "labels": [], "components": [] }] }`;
}

function buildStoryPrompt(epic: RawEpic, prdMarkdown: string, maxStories: number): string {
  return `Generate User Stories for the following Epic.

## Epic: ${epic.title}
${epic.description}

## Business Value
${epic.businessValue ?? 'Not specified'}

## Full PRD Context (reference only)
<prd_context>
${prdMarkdown}
</prd_context>

## Instructions
1. Create up to ${maxStories} user stories that together deliver this Epic
2. Each story must be independently deliverable within a single sprint
3. Stories must not exceed 13 story points; split larger work
4. Include at least 2 acceptance criteria per story in Given/When/Then format
5. Assign story points using Fibonacci: 1, 2, 3, 5, 8, 13, 21
6. Identify inter-story dependencies by title reference
7. Suggest sprint assignment numbers starting from 1

Respond with JSON: { "stories": [{ "title": "...", "userStoryStatement": { "persona": "...", "action": "...", "benefit": "..." }, "description": "...", "acceptanceCriteria": [{ "title": "...", "given": "...", "when": "...", "then": "..." }], "storyPoints": 5, "priority": "must-have", "labels": [], "components": [], "dependsOn": [], "technicalNotes": "...", "definitionOfDone": ["..."], "suggestedSprint": 1 }] }`;
}

// --- Raw types for LLM output parsing ---

interface RawEpic {
  title: string;
  description: string;
  businessValue?: string;
  acceptanceCriteria?: string[];
  estimate?: { size: string };
  priority?: number;
  labels?: string[];
  components?: string[];
}

interface RawStory {
  title: string;
  userStoryStatement: { persona: string; action: string; benefit: string };
  description: string;
  acceptanceCriteria?: RawAc[];
  storyPoints: number;
  priority?: string;
  labels?: string[];
  components?: string[];
  dependsOn?: string[];
  technicalNotes?: string;
  definitionOfDone?: string[];
  suggestedSprint?: number;
}

interface RawAc {
  title: string;
  given: string;
  when: string;
  then: string;
}
