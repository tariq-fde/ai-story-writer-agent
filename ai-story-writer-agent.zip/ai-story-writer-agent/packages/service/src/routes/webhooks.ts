import { Router } from 'express';
import { logger } from '../services/logger.js';
import type { WebhookPayload } from '../types/api.js';

const router = Router();

router.post('/api/v1/webhooks', async (req, res, next) => {
  try {
    const payload = req.body as WebhookPayload;

    if (!payload.message?.data) {
      res.status(400).json({ error: 'Missing message data' });
      return;
    }

    const decoded = Buffer.from(payload.message.data, 'base64').toString('utf-8');
    let data: Record<string, unknown>;
    try {
      data = JSON.parse(decoded);
    } catch {
      res.status(400).json({ error: 'Invalid JSON in message data' });
      return;
    }

    const eventType = payload.message.attributes?.eventType ?? 'unknown';

    logger.info(
      { messageId: payload.message.messageId, eventType, subscription: payload.subscription },
      'Received Pub/Sub webhook',
    );

    switch (eventType) {
      case 'story-approved':
        logger.info({ data }, 'Processing story-approved webhook — JIRA push may be triggered');
        break;
      default:
        logger.info({ eventType }, 'Received unhandled webhook event type');
    }

    // Acknowledge message
    res.status(204).end();
  } catch (err) {
    next(err);
  }
});

export default router;
