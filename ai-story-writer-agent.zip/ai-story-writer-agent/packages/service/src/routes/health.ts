import { Router } from 'express';
import type { HealthResponse } from '../types/api.js';

const router = Router();

router.get('/health', (_req, res) => {
  const body: HealthResponse = {
    status: 'ok',
    version: process.env.npm_package_version ?? '1.0.0',
    timestamp: new Date().toISOString(),
  };
  res.json(body);
});

export default router;
