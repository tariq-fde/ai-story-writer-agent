import type { Express } from 'express';
import healthRouter from './health.js';
import storiesRouter from './stories.js';
import reviewsRouter from './reviews.js';
import jiraRouter from './jira.js';
import webhooksRouter from './webhooks.js';

export function mountRoutes(app: Express): void {
  app.use(healthRouter);
  app.use(storiesRouter);
  app.use(reviewsRouter);
  app.use(jiraRouter);
  app.use(webhooksRouter);
}
