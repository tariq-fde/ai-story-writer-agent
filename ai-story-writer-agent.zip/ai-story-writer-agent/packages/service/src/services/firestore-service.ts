import { Firestore } from '@google-cloud/firestore';
import type { Epic, GenerationRun, ReviewSession } from '@ai-story-writer/core';
import { getEnvConfig } from '../config/env.js';

let _db: Firestore | undefined;

function getDb(): Firestore {
  if (!_db) {
    const config = getEnvConfig();
    _db = new Firestore({ projectId: config.GCP_PROJECT_ID });
  }
  return _db;
}

function collectionName(name: string): string {
  const prefix = getEnvConfig().FIRESTORE_COLLECTION_PREFIX;
  return `${prefix}_${name}`;
}

// --- PRD Documents ---

export async function savePrdDocument(doc: {
  id: string;
  title: string;
  rawMarkdown: string;
  metadata: Record<string, unknown>;
}): Promise<void> {
  await getDb().collection(collectionName('prd_documents')).doc(doc.id).set({
    ...doc,
    createdAt: new Date().toISOString(),
  });
}

export async function getPrdDocument(id: string) {
  const snap = await getDb().collection(collectionName('prd_documents')).doc(id).get();
  return snap.exists ? (snap.data() as Record<string, unknown>) : null;
}

// --- Generation Runs ---

export async function saveGenerationRun(run: GenerationRun): Promise<void> {
  await getDb().collection(collectionName('generation_runs')).doc(run.id).set(run);
}

export async function updateGenerationRun(
  id: string,
  updates: Partial<GenerationRun>,
): Promise<void> {
  await getDb().collection(collectionName('generation_runs')).doc(id).update(updates);
}

export async function getGenerationRun(id: string): Promise<GenerationRun | null> {
  const snap = await getDb().collection(collectionName('generation_runs')).doc(id).get();
  return snap.exists ? (snap.data() as GenerationRun) : null;
}

// --- Story Previews ---

export async function saveStoryPreview(preview: {
  id: string;
  runId: string;
  epics: Epic[];
}): Promise<void> {
  await getDb()
    .collection(collectionName('story_previews'))
    .doc(preview.id)
    .set({
      ...preview,
      createdAt: new Date().toISOString(),
    });
}

export async function getStoryPreview(
  id: string,
): Promise<{ id: string; runId: string; epics: Epic[] } | null> {
  const snap = await getDb().collection(collectionName('story_previews')).doc(id).get();
  return snap.exists ? (snap.data() as { id: string; runId: string; epics: Epic[] }) : null;
}

// --- Review Sessions ---

export async function saveReviewSession(session: ReviewSession): Promise<void> {
  await getDb().collection(collectionName('review_sessions')).doc(session.id).set(session);
}

export async function getReviewSession(id: string): Promise<ReviewSession | null> {
  const snap = await getDb().collection(collectionName('review_sessions')).doc(id).get();
  return snap.exists ? (snap.data() as ReviewSession) : null;
}

export async function updateReviewSession(
  id: string,
  updates: Partial<ReviewSession>,
): Promise<void> {
  await getDb().collection(collectionName('review_sessions')).doc(id).update(updates);
}
