import { PubSub } from '@google-cloud/pubsub';
import { getEnvConfig } from '../config/env.js';
import { logger } from './logger.js';

let _pubsub: PubSub | undefined;

function getPubSub(): PubSub {
  if (!_pubsub) {
    const config = getEnvConfig();
    _pubsub = new PubSub({ projectId: config.GCP_PROJECT_ID });
  }
  return _pubsub;
}

type EventType = 'story-generated' | 'story-approved' | 'jira-pushed';

function topicName(event: EventType): string {
  const prefix = getEnvConfig().FIRESTORE_COLLECTION_PREFIX;
  return `${prefix}.${event}`;
}

export async function publishEvent(
  event: EventType,
  data: Record<string, unknown>,
  attributes?: Record<string, string>,
): Promise<string> {
  const topic = getPubSub().topic(topicName(event));
  const messageBuffer = Buffer.from(JSON.stringify(data));

  try {
    const messageId = await topic.publishMessage({
      data: messageBuffer,
      attributes: attributes ?? {},
    });
    logger.info({ event, messageId }, 'Published Pub/Sub event');
    return messageId;
  } catch (err) {
    logger.error({ event, error: err }, 'Failed to publish Pub/Sub event');
    throw err;
  }
}

export async function ensureTopicsExist(): Promise<void> {
  const pubsub = getPubSub();
  const events: EventType[] = ['story-generated', 'story-approved', 'jira-pushed'];

  for (const event of events) {
    const name = topicName(event);
    const [exists] = await pubsub.topic(name).exists();
    if (!exists) {
      await pubsub.createTopic(name);
      logger.info({ topic: name }, 'Created Pub/Sub topic');
    }
  }
}
