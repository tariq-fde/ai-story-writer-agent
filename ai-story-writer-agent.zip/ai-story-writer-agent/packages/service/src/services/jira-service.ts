import type {
  JiraCreateIssuePayload,
  JiraCreatedIssue,
  JiraPushError,
  JiraPushResult,
} from '@ai-story-writer/core';
import { getEnvConfig } from '../config/env.js';
import { logger } from './logger.js';

interface JiraApiIssue {
  id: string;
  key: string;
  self: string;
  fields?: Record<string, unknown>;
}

interface JiraProject {
  id: string;
  key: string;
  name: string;
  issueTypes: Array<{ id: string; name: string; subtask: boolean }>;
}

interface JiraSearchResult {
  issues: JiraApiIssue[];
  total: number;
  startAt: number;
  maxResults: number;
}

function getAuthHeaders(): Record<string, string> {
  const config = getEnvConfig();
  const credentials = Buffer.from(`${config.JIRA_USER_EMAIL}:${config.JIRA_API_TOKEN}`).toString('base64');
  return {
    Authorization: `Basic ${credentials}`,
    'Content-Type': 'application/json',
    Accept: 'application/json',
  };
}

function baseUrl(): string {
  return getEnvConfig().JIRA_BASE_URL;
}

export async function createIssue(payload: JiraCreateIssuePayload): Promise<JiraApiIssue> {
  const response = await fetch(`${baseUrl()}/rest/api/3/issue`, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`JIRA createIssue failed (${response.status}): ${errorBody}`);
  }

  return (await response.json()) as JiraApiIssue;
}

export async function bulkCreateIssues(
  payloads: JiraCreateIssuePayload[],
): Promise<JiraPushResult> {
  const createdIssues: JiraCreatedIssue[] = [];
  const errors: JiraPushError[] = [];

  for (const payload of payloads) {
    try {
      const result = await createIssue(payload);
      const issueType = inferIssueType(payload);
      createdIssues.push({
        internalId: payload.fields.summary,
        jiraKey: result.key,
        jiraId: result.id,
        issueType,
        selfUrl: result.self,
      });
      logger.info({ jiraKey: result.key, issueType }, 'Created JIRA issue');
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      errors.push({
        internalId: payload.fields.summary,
        issueType: inferIssueType(payload),
        error: message,
      });
      logger.error({ error: message, summary: payload.fields.summary }, 'Failed to create JIRA issue');
    }
  }

  return {
    success: errors.length === 0,
    createdIssues,
    errors,
  };
}

export async function getProject(projectKey: string): Promise<JiraProject> {
  const response = await fetch(`${baseUrl()}/rest/api/3/project/${projectKey}`, {
    headers: getAuthHeaders(),
  });

  if (!response.ok) {
    throw new Error(`JIRA getProject failed (${response.status}): ${await response.text()}`);
  }

  return (await response.json()) as JiraProject;
}

export async function getIssueTypes(): Promise<Array<{ id: string; name: string; subtask: boolean }>> {
  const response = await fetch(`${baseUrl()}/rest/api/3/issuetype`, {
    headers: getAuthHeaders(),
  });

  if (!response.ok) {
    throw new Error(`JIRA getIssueTypes failed (${response.status}): ${await response.text()}`);
  }

  return (await response.json()) as Array<{ id: string; name: string; subtask: boolean }>;
}

export async function searchIssues(jql: string, maxResults = 50): Promise<JiraSearchResult> {
  const params = new URLSearchParams({ jql, maxResults: String(maxResults) });
  const response = await fetch(`${baseUrl()}/rest/api/3/search?${params}`, {
    headers: getAuthHeaders(),
  });

  if (!response.ok) {
    throw new Error(`JIRA search failed (${response.status}): ${await response.text()}`);
  }

  return (await response.json()) as JiraSearchResult;
}

function inferIssueType(payload: JiraCreateIssuePayload): 'epic' | 'story' | 'subtask' {
  const typeId = payload.fields.issuetype.id;
  // Heuristic based on typical JIRA issue type IDs; the actual mapping comes from org config
  if (typeId === '10000') return 'epic';
  if (typeId === '10003') return 'subtask';
  return 'story';
}
