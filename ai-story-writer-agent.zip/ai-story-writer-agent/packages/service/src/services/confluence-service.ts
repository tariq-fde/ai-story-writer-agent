import { getEnvConfig } from '../config/env.js';

interface ConfluencePage {
  id: string;
  type: string;
  status: string;
  title: string;
  body?: {
    storage?: { value: string; representation: string };
    view?: { value: string; representation: string };
  };
  version: { number: number };
  _links: { webui: string; self: string };
}

interface ConfluenceSearchResult {
  results: ConfluencePage[];
  start: number;
  limit: number;
  totalSize: number;
}

function getAuthHeaders(): Record<string, string> {
  const config = getEnvConfig();
  const credentials = Buffer.from(`${config.CONFLUENCE_USER_EMAIL}:${config.CONFLUENCE_API_TOKEN}`).toString('base64');
  return {
    Authorization: `Basic ${credentials}`,
    'Content-Type': 'application/json',
    Accept: 'application/json',
  };
}

function baseUrl(): string {
  return getEnvConfig().CONFLUENCE_BASE_URL;
}

export async function getPage(pageId: string, expand = 'body.storage,version'): Promise<ConfluencePage> {
  const params = new URLSearchParams({ expand });
  const response = await fetch(`${baseUrl()}/wiki/api/v2/pages/${pageId}?${params}`, {
    headers: getAuthHeaders(),
  });

  if (!response.ok) {
    throw new Error(`Confluence getPage failed (${response.status}): ${await response.text()}`);
  }

  return (await response.json()) as ConfluencePage;
}

export async function searchPages(
  cql: string,
  limit = 25,
  start = 0,
): Promise<ConfluenceSearchResult> {
  const params = new URLSearchParams({
    cql,
    limit: String(limit),
    start: String(start),
  });

  const response = await fetch(`${baseUrl()}/wiki/rest/api/content/search?${params}`, {
    headers: getAuthHeaders(),
  });

  if (!response.ok) {
    throw new Error(`Confluence search failed (${response.status}): ${await response.text()}`);
  }

  return (await response.json()) as ConfluenceSearchResult;
}
