import Anthropic from '@anthropic-ai/sdk';
import type { MessageParam, ContentBlockParam } from '@anthropic-ai/sdk/resources/messages.js';
import { getAnthropicClient } from '../config/anthropic.js';
import { logger } from './logger.js';

const MODEL = 'claude-sonnet-4-5-20250514';
const MAX_TOKENS = 8192;
const MAX_RETRIES = 3;

export interface LlmCallOptions {
  systemPrompt: string;
  userPrompt: string;
  temperature?: number;
  maxTokens?: number;
}

export interface LlmJsonResult<T> {
  parsed: T;
  rawText: string;
  usage: { inputTokens: number; outputTokens: number };
}

export async function callLlmForJson<T>(
  options: LlmCallOptions,
  parser: (text: string) => T,
): Promise<LlmJsonResult<T>> {
  const client = getAnthropicClient();
  const messages: MessageParam[] = [{ role: 'user', content: options.userPrompt }];

  let lastError: Error | undefined;

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    const effectiveMessages: MessageParam[] =
      attempt === 1
        ? messages
        : [
            ...messages,
            {
              role: 'assistant',
              content: 'I will provide the JSON output.',
            },
            {
              role: 'user',
              content: `Your previous response was not valid JSON. Error: ${lastError?.message}. Please respond with ONLY valid JSON matching the requested schema. No markdown fences, no commentary.`,
            },
          ];

    const response = await client.messages.create({
      model: MODEL,
      max_tokens: options.maxTokens ?? MAX_TOKENS,
      temperature: options.temperature ?? 0.3,
      system: options.systemPrompt,
      messages: effectiveMessages,
    });

    const textBlock = response.content.find((b): b is Anthropic.TextBlock => b.type === 'text');
    if (!textBlock) {
      lastError = new Error('No text block in response');
      logger.warn({ attempt }, 'LLM returned no text block, retrying');
      continue;
    }

    const rawText = textBlock.text.trim();

    try {
      const jsonStr = extractJson(rawText);
      const parsed = parser(jsonStr);
      return {
        parsed,
        rawText,
        usage: {
          inputTokens: response.usage.input_tokens,
          outputTokens: response.usage.output_tokens,
        },
      };
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
      logger.warn({ attempt, error: lastError.message }, 'LLM output failed validation, retrying');
    }
  }

  throw new Error(`LLM failed to produce valid JSON after ${MAX_RETRIES} attempts: ${lastError?.message}`);
}

export async function callLlmForText(options: LlmCallOptions): Promise<string> {
  const client = getAnthropicClient();
  const response = await client.messages.create({
    model: MODEL,
    max_tokens: options.maxTokens ?? MAX_TOKENS,
    temperature: options.temperature ?? 0.3,
    system: options.systemPrompt,
    messages: [{ role: 'user', content: options.userPrompt }],
  });

  const textBlock = response.content.find((b): b is Anthropic.TextBlock => b.type === 'text');
  return textBlock?.text.trim() ?? '';
}

function extractJson(text: string): string {
  const fenced = text.match(/```(?:json)?\s*\n?([\s\S]*?)```/);
  if (fenced) return fenced[1].trim();

  const braceStart = text.indexOf('{');
  const bracketStart = text.indexOf('[');
  if (braceStart === -1 && bracketStart === -1) return text;

  const start = braceStart === -1 ? bracketStart : bracketStart === -1 ? braceStart : Math.min(braceStart, bracketStart);
  const opener = text[start];
  const closer = opener === '{' ? '}' : ']';

  let depth = 0;
  for (let i = start; i < text.length; i++) {
    if (text[i] === opener) depth++;
    if (text[i] === closer) depth--;
    if (depth === 0) return text.slice(start, i + 1);
  }

  return text.slice(start);
}
