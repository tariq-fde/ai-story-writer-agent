import { getEnvConfig } from '../config/env.js';

const GITHUB_GRAPHQL_URL = 'https://api.github.com/graphql';

interface GraphQLResponse<T> {
  data: T;
  errors?: Array<{ message: string }>;
}

interface CodeSearchResult {
  items: Array<{
    name: string;
    path: string;
    repository: { full_name: string; html_url: string };
    html_url: string;
    sha: string;
  }>;
  total_count: number;
}

interface FileContentsResult {
  name: string;
  path: string;
  sha: string;
  content: string;
  encoding: string;
  size: number;
}

interface RepoSearchResult {
  items: Array<{
    full_name: string;
    description: string;
    html_url: string;
    default_branch: string;
    language: string;
    updated_at: string;
  }>;
  total_count: number;
}

function getHeaders(): Record<string, string> {
  const config = getEnvConfig();
  return {
    Authorization: `Bearer ${config.GITHUB_PAT}`,
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
  };
}

export async function searchCode(query: string, perPage = 30): Promise<CodeSearchResult> {
  const params = new URLSearchParams({ q: query, per_page: String(perPage) });
  const response = await fetch(`https://api.github.com/search/code?${params}`, {
    headers: getHeaders(),
  });

  if (!response.ok) {
    throw new Error(`GitHub code search failed (${response.status}): ${await response.text()}`);
  }

  return (await response.json()) as CodeSearchResult;
}

export async function getFileContents(
  owner: string,
  repo: string,
  path: string,
  ref?: string,
): Promise<FileContentsResult> {
  const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}${ref ? `?ref=${ref}` : ''}`;
  const response = await fetch(url, { headers: getHeaders() });

  if (!response.ok) {
    throw new Error(`GitHub getFileContents failed (${response.status}): ${await response.text()}`);
  }

  return (await response.json()) as FileContentsResult;
}

export async function searchRepositories(query: string, perPage = 10): Promise<RepoSearchResult> {
  const params = new URLSearchParams({ q: query, per_page: String(perPage) });
  const response = await fetch(`https://api.github.com/search/repositories?${params}`, {
    headers: getHeaders(),
  });

  if (!response.ok) {
    throw new Error(`GitHub repo search failed (${response.status}): ${await response.text()}`);
  }

  return (await response.json()) as RepoSearchResult;
}

export async function graphqlQuery<T>(query: string, variables?: Record<string, unknown>): Promise<T> {
  const response = await fetch(GITHUB_GRAPHQL_URL, {
    method: 'POST',
    headers: { ...getHeaders(), 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  });

  if (!response.ok) {
    throw new Error(`GitHub GraphQL failed (${response.status}): ${await response.text()}`);
  }

  const result = (await response.json()) as GraphQLResponse<T>;
  if (result.errors?.length) {
    throw new Error(`GitHub GraphQL errors: ${result.errors.map((e) => e.message).join(', ')}`);
  }

  return result.data;
}
