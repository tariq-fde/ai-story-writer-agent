import express from 'express';
import { requestLogger } from './middleware/request-logger.js';
import { authMiddleware } from './middleware/auth.js';
import { errorHandler } from './middleware/error-handler.js';
import { mountRoutes } from './routes/index.js';

export function createApp(): express.Express {
  const app = express();

  app.use(express.json({ limit: '5mb' }));
  app.use(requestLogger);

  // Auth not required for health check
  app.use('/api', authMiddleware);

  mountRoutes(app);

  app.use(errorHandler);

  return app;
}
