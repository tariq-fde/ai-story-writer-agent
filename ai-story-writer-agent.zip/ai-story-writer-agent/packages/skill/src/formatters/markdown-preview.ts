import type { PRDDocument, Epic, UserStory, SubTask } from '@ai-story-writer/core';

export function formatMarkdownPreview(prd: PRDDocument, epics: Epic[]): string {
  const lines: string[] = [];

  lines.push(`# Story Generation Preview`);
  lines.push('');
  lines.push(`**PRD:** ${prd.title}`);
  lines.push(`**Generated:** ${new Date().toISOString().slice(0, 10)}`);
  lines.push(`**Epics:** ${epics.length}`);
  lines.push(
    `**Total Stories:** ${epics.reduce((sum, e) => sum + e.stories.length, 0)}`,
  );
  lines.push('');
  lines.push('---');

  for (const epic of epics) {
    lines.push('');
    lines.push(...formatEpic(epic));
  }

  lines.push('');
  lines.push('---');
  lines.push('');
  lines.push('## Summary Table');
  lines.push('');
  lines.push('| Epic | Stories | Total Points | Est. Sprints |');
  lines.push('|------|---------|-------------|-------------|');
  for (const epic of epics) {
    const totalPoints = epic.stories.reduce((sum, s) => sum + s.storyPoints, 0);
    lines.push(
      `| ${epic.title} | ${epic.stories.length} | ${totalPoints} | ${epic.estimate.estimatedSprintCount} |`,
    );
  }

  lines.push('');
  lines.push(
    '> **Next step:** Review the above items. Reply with approval to push to JIRA, or provide feedback on specific stories.',
  );

  return lines.join('\n');
}

function formatEpic(epic: Epic): string[] {
  const lines: string[] = [];

  lines.push(`## Epic: ${epic.title}`);
  lines.push('');
  lines.push(`**Priority:** ${epic.priority} | **Size:** ${epic.estimate.size} | **Review:** ${epic.reviewStatus}`);
  lines.push('');
  lines.push(`### Description`);
  lines.push(epic.description);
  lines.push('');
  lines.push(`### Business Value`);
  lines.push(epic.businessValue);
  lines.push('');

  if (epic.acceptanceCriteria.length > 0) {
    lines.push(`### Epic Acceptance Criteria`);
    for (const ac of epic.acceptanceCriteria) {
      lines.push(`- ${ac}`);
    }
    lines.push('');
  }

  for (let i = 0; i < epic.stories.length; i++) {
    lines.push(...formatStory(epic.stories[i], i + 1));
  }

  return lines;
}

function formatStory(story: UserStory, index: number): string[] {
  const lines: string[] = [];
  const stmt = story.userStoryStatement;

  lines.push(`#### Story ${index}: ${story.title}`);
  lines.push('');
  lines.push(`> As a **${stmt.persona}**, I want **${stmt.action}**, so that **${stmt.benefit}**.`);
  lines.push('');
  lines.push(
    `**Points:** ${story.storyPoints} | **Priority:** ${story.priority} | **Sprint:** ${story.suggestedSprint ?? 'TBD'}`,
  );
  lines.push('');

  if (story.description) {
    lines.push(story.description);
    lines.push('');
  }

  lines.push(`**Acceptance Criteria:**`);
  lines.push('');
  for (const ac of story.acceptanceCriteria) {
    lines.push(`<details><summary>${ac.title}</summary>`);
    lines.push('');
    lines.push(`- **Given** ${ac.given}`);
    lines.push(`- **When** ${ac.when}`);
    lines.push(`- **Then** ${ac.then}`);
    lines.push('');
    lines.push(`</details>`);
    lines.push('');
  }

  if (story.subTasks.length > 0) {
    lines.push(`**Sub-Tasks:**`);
    lines.push('');
    lines.push('| Task | Category | Hours |');
    lines.push('|------|----------|-------|');
    for (const st of story.subTasks) {
      lines.push(`| ${st.title} | ${st.category} | ${st.estimatedHours}h |`);
    }
    lines.push('');
  }

  if (story.definitionOfDone.length > 0) {
    lines.push(`**Definition of Done:**`);
    for (const dod of story.definitionOfDone) {
      lines.push(`- [ ] ${dod}`);
    }
    lines.push('');
  }

  return lines;
}
