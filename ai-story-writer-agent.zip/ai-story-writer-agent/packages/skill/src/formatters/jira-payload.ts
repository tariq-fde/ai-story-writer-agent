import type {
  Epic,
  UserStory,
  SubTask,
  JiraFieldMapping,
  JiraCreateIssuePayload,
  JiraAdfDocument,
  JiraAdfNode,
} from '@ai-story-writer/core';

export interface JiraPayloadSet {
  epicPayload: JiraCreateIssuePayload;
  storyPayloads: JiraCreateIssuePayload[];
  subTaskPayloads: Map<string, JiraCreateIssuePayload[]>;
}

export function buildJiraPayloads(
  epics: Epic[],
  mapping: JiraFieldMapping,
): JiraPayloadSet[] {
  return epics.map((epic) => buildEpicPayloadSet(epic, mapping));
}

function buildEpicPayloadSet(epic: Epic, mapping: JiraFieldMapping): JiraPayloadSet {
  const epicPayload = buildEpicPayload(epic, mapping);

  const storyPayloads = epic.stories.map((story) => buildStoryPayload(story, mapping));

  const subTaskPayloads = new Map<string, JiraCreateIssuePayload[]>();
  for (const story of epic.stories) {
    subTaskPayloads.set(
      story.id,
      story.subTasks.map((st) => buildSubTaskPayload(st, mapping)),
    );
  }

  return { epicPayload, storyPayloads, subTaskPayloads };
}

function buildEpicPayload(epic: Epic, mapping: JiraFieldMapping): JiraCreateIssuePayload {
  return {
    fields: {
      project: { key: mapping.projectKey },
      issuetype: { id: mapping.issueTypes.epicTypeId },
      summary: epic.title,
      description: textToAdf(epic.description),
      labels: epic.labels,
      components: epic.components.map((name) => ({ name })),
      [mapping.standardFields.epicNameField]: epic.title,
    },
  };
}

function buildStoryPayload(
  story: UserStory,
  mapping: JiraFieldMapping,
): JiraCreateIssuePayload {
  const { persona, action, benefit } = story.userStoryStatement;
  const storyText = `As a ${persona}, I want ${action}, so that ${benefit}.\n\n${story.description}`;

  const acText = story.acceptanceCriteria
    .map((ac) => `**${ac.title}**\n- Given ${ac.given}\n- When ${ac.when}\n- Then ${ac.then}`)
    .join('\n\n');

  const fullDescription = `${storyText}\n\n## Acceptance Criteria\n\n${acText}`;

  const priorityId = mapping.standardFields.priorityMapping[story.priority];

  return {
    fields: {
      project: { key: mapping.projectKey },
      issuetype: { id: mapping.issueTypes.storyTypeId },
      summary: story.title,
      description: textToAdf(fullDescription),
      ...(priorityId && { priority: { id: priorityId } }),
      labels: story.labels,
      components: story.components.map((name) => ({ name })),
      [mapping.standardFields.storyPointsField]: story.storyPoints,
    },
  };
}

function buildSubTaskPayload(
  subTask: SubTask,
  mapping: JiraFieldMapping,
): JiraCreateIssuePayload {
  return {
    fields: {
      project: { key: mapping.projectKey },
      issuetype: { id: mapping.issueTypes.subTaskTypeId },
      summary: subTask.title,
      description: textToAdf(
        `${subTask.description}\n\n**Category:** ${subTask.category}\n**Estimated Hours:** ${subTask.estimatedHours}`,
      ),
      labels: subTask.labels,
      ...(subTask.component && { components: [{ name: subTask.component }] }),
    },
  };
}

function textToAdf(text: string): JiraAdfDocument {
  const paragraphs: JiraAdfNode[] = text.split('\n\n').map((para) => ({
    type: 'paragraph',
    content: [{ type: 'text', text: para.trim() }],
  }));

  return {
    type: 'doc',
    version: 1,
    content: paragraphs,
  };
}
