import { readFileSync } from 'node:fs';
import type { PRDDocument, OrgConfig, Epic } from '@ai-story-writer/core';
import { orgConfigSchema } from '@ai-story-writer/core';
import { formatMarkdownPreview } from './formatters/markdown-preview.js';

const DEFAULT_CONFIG_PATH = 'config/org/default.json';

export interface StoryGenerationResult {
  preview: string;
  epics: Epic[];
  prd: PRDDocument;
  orgConfig: OrgConfig;
}

export async function runStoryGeneration(
  prdPath: string,
  orgConfigPath?: string,
): Promise<StoryGenerationResult> {
  const rawMarkdown = readFileSync(prdPath, 'utf-8');

  const configContent = readFileSync(orgConfigPath ?? DEFAULT_CONFIG_PATH, 'utf-8');
  const orgConfig = orgConfigSchema.parse(JSON.parse(configContent));

  const prd: PRDDocument = {
    id: crypto.randomUUID(),
    title: extractTitle(rawMarkdown),
    version: '1.0.0',
    rawMarkdown,
    sections: [],
    metadata: {
      productArea: '',
      priority: 'P2',
      stakeholders: [],
      technicalConstraints: [],
      dependencies: [],
      nfrs: [],
    },
  };

  // The actual LLM-driven decomposition happens in the skill workflow.
  // This adapter prepares the context and returns the scaffold for the
  // Claude Code skill to fill in via its multi-step prompt chain.
  const epics: Epic[] = [];

  const preview = formatMarkdownPreview(prd, epics);

  return { preview, epics, prd, orgConfig };
}

function extractTitle(markdown: string): string {
  const match = markdown.match(/^#\s+(.+)$/m);
  return match?.[1]?.trim() ?? 'Untitled PRD';
}
