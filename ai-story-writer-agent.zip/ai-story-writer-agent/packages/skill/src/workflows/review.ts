import type { Epic, ReviewStatus } from '@ai-story-writer/core';

export interface ReviewDecision {
  epicId: string;
  storyId?: string;
  status: ReviewStatus;
  comment?: string;
}

export interface ReviewResult {
  approved: Epic[];
  rejected: Epic[];
  needsRevision: Epic[];
  allApproved: boolean;
}

/**
 * Processes PO review decisions on generated stories.
 *
 * In the skill context, the PO reviews the Markdown preview and provides
 * feedback directly in the conversation. This module applies those decisions
 * to the epic/story data structures.
 */
export function reviewStories(
  epics: Epic[],
  decisions: ReviewDecision[],
): ReviewResult {
  const epicMap = new Map(epics.map((e) => [e.id, { ...e }]));

  for (const decision of decisions) {
    const epic = epicMap.get(decision.epicId);
    if (!epic) continue;

    if (decision.storyId) {
      const story = epic.stories.find((s) => s.id === decision.storyId);
      if (story) {
        story.reviewStatus = decision.status;
        if (decision.comment) {
          story.reviewComments.push({
            author: 'PO',
            timestamp: new Date().toISOString(),
            comment: decision.comment,
          });
        }
      }
    } else {
      epic.reviewStatus = decision.status;
    }
  }

  const updatedEpics = Array.from(epicMap.values());
  const approved = updatedEpics.filter((e) => e.reviewStatus === 'approved');
  const rejected = updatedEpics.filter((e) => e.reviewStatus === 'rejected');
  const needsRevision = updatedEpics.filter((e) => e.reviewStatus === 'revision_requested');

  return {
    approved,
    rejected,
    needsRevision,
    allApproved: approved.length === updatedEpics.length,
  };
}
