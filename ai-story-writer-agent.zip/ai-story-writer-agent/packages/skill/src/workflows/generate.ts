import type { PRDDocument, Epic, OrgConfig } from '@ai-story-writer/core';
import { formatMarkdownPreview } from '../formatters/markdown-preview.js';

export interface GenerateOptions {
  prd: PRDDocument;
  orgConfig: OrgConfig;
  maxEpics?: number;
  maxStoriesPerEpic?: number;
}

export interface GenerateResult {
  epics: Epic[];
  preview: string;
  stats: GenerationStats;
}

export interface GenerationStats {
  epicCount: number;
  storyCount: number;
  subTaskCount: number;
  totalStoryPoints: number;
  estimatedSprints: number;
}

/**
 * Orchestrates the story generation workflow within the Claude Code skill context.
 *
 * In the skill context, the actual LLM calls are made by Claude Code itself
 * via the skill's SKILL.md instructions. This module provides the workflow
 * structure and formatting utilities that the skill references.
 *
 * Flow:
 *  1. Parse PRD into structured sections
 *  2. (Claude) Decompose PRD into Epics via epic-generation prompt
 *  3. (Claude) Generate Stories per Epic via story-generation prompt
 *  4. (Claude) Generate Sub-Tasks per Story via subtask-generation prompt
 *  5. Validate all output against Zod schemas
 *  6. Format as Markdown preview for PO review
 */
export async function generateStories(options: GenerateOptions): Promise<GenerateResult> {
  const { prd, orgConfig } = options;

  // Placeholder: in the skill, Claude fills this via the multi-step prompt chain.
  const epics: Epic[] = [];

  const storyCount = epics.reduce((sum, e) => sum + e.stories.length, 0);
  const subTaskCount = epics.reduce(
    (sum, e) => sum + e.stories.reduce((s, st) => s + st.subTasks.length, 0),
    0,
  );
  const totalStoryPoints = epics.reduce(
    (sum, e) => sum + e.stories.reduce((s, st) => s + st.storyPoints, 0),
    0,
  );
  const velocity = orgConfig.jira.boardConfig.teamVelocity;
  const estimatedSprints = velocity > 0 ? Math.ceil(totalStoryPoints / velocity) : 0;

  const preview = formatMarkdownPreview(prd, epics);

  return {
    epics,
    preview,
    stats: {
      epicCount: epics.length,
      storyCount,
      subTaskCount,
      totalStoryPoints,
      estimatedSprints,
    },
  };
}
