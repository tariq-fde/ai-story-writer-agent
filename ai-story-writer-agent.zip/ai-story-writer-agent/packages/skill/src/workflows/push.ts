import type { Epic, JiraFieldMapping, JiraPushResult, JiraCreatedIssue } from '@ai-story-writer/core';
import { buildJiraPayloads } from '../formatters/jira-payload.js';
import { createJiraIssueViaMcp } from '../mcp-bridge.js';

export interface PushOptions {
  epics: Epic[];
  fieldMapping: JiraFieldMapping;
  dryRun?: boolean;
}

export interface PushResult {
  success: boolean;
  dryRun: boolean;
  created: JiraCreatedIssue[];
  errors: string[];
  summary: string;
}

/**
 * Pushes approved stories to JIRA via MCP.
 *
 * In the skill context, the actual MCP tool invocations are executed by
 * Claude Code. This module builds the payloads and provides the structure
 * for the skill to iterate through.
 */
export async function pushToJira(options: PushOptions): Promise<PushResult> {
  const { epics, fieldMapping, dryRun = false } = options;
  const approvedEpics = epics.filter((e) => e.reviewStatus === 'approved');

  if (approvedEpics.length === 0) {
    return {
      success: false,
      dryRun,
      created: [],
      errors: ['No approved epics to push. Run review first.'],
      summary: 'No approved epics found.',
    };
  }

  const payloadSets = buildJiraPayloads(approvedEpics, fieldMapping);

  if (dryRun) {
    const totalItems =
      payloadSets.length +
      payloadSets.reduce((sum, ps) => sum + ps.storyPayloads.length, 0) +
      payloadSets.reduce(
        (sum, ps) =>
          sum +
          Array.from(ps.subTaskPayloads.values()).reduce((s, arr) => s + arr.length, 0),
        0,
      );

    return {
      success: true,
      dryRun: true,
      created: [],
      errors: [],
      summary: `Dry run: would create ${payloadSets.length} epics, ${payloadSets.reduce((s, p) => s + p.storyPayloads.length, 0)} stories, and ${totalItems - payloadSets.length - payloadSets.reduce((s, p) => s + p.storyPayloads.length, 0)} sub-tasks in project ${fieldMapping.projectKey}.`,
    };
  }

  // In actual execution, the skill iterates through payloadSets and calls
  // createJiraIssueViaMcp for each, collecting the results.
  // The MCP tool invocations are listed here for the skill to use.
  const mcpInvocations = payloadSets.flatMap((ps) => [
    createJiraIssueViaMcp(ps.epicPayload),
    ...ps.storyPayloads.map((sp) => createJiraIssueViaMcp(sp)),
    ...Array.from(ps.subTaskPayloads.values()).flatMap((stps) =>
      stps.map((stp) => createJiraIssueViaMcp(stp)),
    ),
  ]);

  return {
    success: true,
    dryRun: false,
    created: [],
    errors: [],
    summary: `Prepared ${mcpInvocations.length} JIRA MCP tool invocations for Claude Code to execute.`,
  };
}
