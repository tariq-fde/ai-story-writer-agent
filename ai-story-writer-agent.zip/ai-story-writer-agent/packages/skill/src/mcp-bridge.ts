import type { JiraCreateIssuePayload } from '@ai-story-writer/core';

export interface McpToolInvocation {
  serverName: string;
  toolName: string;
  arguments: Record<string, unknown>;
}

export function createJiraIssueViaMcp(payload: JiraCreateIssuePayload): McpToolInvocation {
  return {
    serverName: 'jira',
    toolName: 'create_issue',
    arguments: {
      fields: payload.fields,
    },
  };
}

export function bulkCreateJiraIssuesViaMcp(
  payloads: JiraCreateIssuePayload[],
): McpToolInvocation {
  return {
    serverName: 'jira',
    toolName: 'bulk_create_issues',
    arguments: {
      issueUpdates: payloads.map((p) => ({ fields: p.fields })),
    },
  };
}

export function searchJiraViaMcp(jql: string, maxResults = 50): McpToolInvocation {
  return {
    serverName: 'jira',
    toolName: 'search_issues',
    arguments: { jql, maxResults },
  };
}

export function getConfluencePageViaMcp(pageId: string): McpToolInvocation {
  return {
    serverName: 'confluence',
    toolName: 'get_page',
    arguments: { pageId, expand: 'body.storage' },
  };
}

export function searchConfluenceViaMcp(cql: string, limit = 25): McpToolInvocation {
  return {
    serverName: 'confluence',
    toolName: 'search',
    arguments: { cql, limit },
  };
}

export function searchGithubCodeViaMcp(query: string): McpToolInvocation {
  return {
    serverName: 'github',
    toolName: 'search_code',
    arguments: { query },
  };
}

export function getGithubFileViaMcp(
  owner: string,
  repo: string,
  path: string,
  ref?: string,
): McpToolInvocation {
  return {
    serverName: 'github',
    toolName: 'get_file_contents',
    arguments: { owner, repo, path, ...(ref && { ref }) },
  };
}
