import Handlebars from 'handlebars';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import type { PRDDocument, OrgConfig } from '../types/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const systemSource = readFileSync(join(__dirname, 'templates', 'system.hbs'), 'utf-8');
const epicSource = readFileSync(join(__dirname, 'templates', 'epic.hbs'), 'utf-8');

const systemTemplate = Handlebars.compile(systemSource);
const epicTemplate = Handlebars.compile(epicSource);

export interface EpicPromptContext {
  prd: PRDDocument;
  orgConfig: OrgConfig;
}

export function buildEpicSystemPrompt(ctx: EpicPromptContext): string {
  return systemTemplate({ orgConfig: ctx.orgConfig });
}

export function buildEpicUserPrompt(ctx: EpicPromptContext): string {
  return epicTemplate({ prd: ctx.prd });
}
