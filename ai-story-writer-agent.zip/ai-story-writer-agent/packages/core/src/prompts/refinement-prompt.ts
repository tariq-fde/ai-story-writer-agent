import type { UserStory, ReviewComment } from '../types/index.js';

export interface RefinementPromptContext {
  story: UserStory;
  comments: ReviewComment[];
}

export function buildRefinementUserPrompt(ctx: RefinementPromptContext): string {
  const commentList = ctx.comments
    .map(
      (c) =>
        `- [${c.author}]${c.field ? ` (re: ${c.field})` : ''}: ${c.comment}`,
    )
    .join('\n');

  return `Refine the following user story based on PO review feedback.

## Current Story: ${ctx.story.title}
As a ${ctx.story.userStoryStatement.persona}, I want ${ctx.story.userStoryStatement.action}, so that ${ctx.story.userStoryStatement.benefit}

### Description
${ctx.story.description}

### Acceptance Criteria
${ctx.story.acceptanceCriteria.map((ac) => `- ${ac.title}: Given ${ac.given}, When ${ac.when}, Then ${ac.then}`).join('\n')}

### Story Points: ${ctx.story.storyPoints}

## Review Comments
${commentList}

## Instructions
1. Address each review comment
2. Update the story fields as needed
3. Preserve any fields that weren't mentioned in comments
4. If a comment requests splitting, produce multiple stories

Respond with the revised story as valid JSON matching the original story schema.`;
}
