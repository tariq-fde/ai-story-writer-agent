import Handlebars from 'handlebars';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import type { UserStory, OrgConfig } from '../types/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const subtaskSource = readFileSync(join(__dirname, 'templates', 'subtask.hbs'), 'utf-8');
const subtaskTemplate = Handlebars.compile(subtaskSource);

export interface SubtaskPromptContext {
  story: UserStory;
  orgConfig: OrgConfig;
}

export function buildSubtaskUserPrompt(ctx: SubtaskPromptContext): string {
  const allTemplates = Object.values(ctx.orgConfig.storyDefaults.subTaskTemplates).flat();
  return subtaskTemplate({
    story: ctx.story,
    subTaskTemplates: allTemplates,
  });
}
