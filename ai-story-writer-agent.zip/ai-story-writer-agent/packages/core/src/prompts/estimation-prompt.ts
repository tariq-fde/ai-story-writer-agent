import type { UserStory, OrgConfig } from '../types/index.js';

export interface EstimationPromptContext {
  stories: UserStory[];
  orgConfig: OrgConfig;
}

export function buildEstimationUserPrompt(ctx: EstimationPromptContext): string {
  const storyList = ctx.stories
    .map(
      (s, i) =>
        `${i + 1}. "${s.title}" (current: ${s.storyPoints} pts)\n` +
        `   As a ${s.userStoryStatement.persona}, I want ${s.userStoryStatement.action}, so that ${s.userStoryStatement.benefit}\n` +
        `   Acceptance Criteria: ${s.acceptanceCriteria.length}\n` +
        `   Sub-Tasks: ${s.subTasks.length}`,
    )
    .join('\n\n');

  return `Review and refine the story point estimates for the following stories.

## Stories
${storyList}

## Estimation Guidelines
- Use Fibonacci scale: 1, 2, 3, 5, 8, 13, 21
- Maximum story points per story: ${ctx.orgConfig.storyDefaults.maxStoryPoints}
- Stories exceeding the maximum should be flagged for splitting
- Consider complexity, uncertainty, and effort
- Team velocity: ${ctx.orgConfig.jira.boardConfig.teamVelocity} points/sprint

Respond with valid JSON:
{
  "estimates": [
    { "storyTitle": "...", "originalPoints": 5, "revisedPoints": 3, "rationale": "..." }
  ],
  "flaggedForSplitting": ["story title that exceeds max"]
}`;
}
