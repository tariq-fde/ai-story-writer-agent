import Handlebars from 'handlebars';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import type { Epic, PRDDocument, OrgConfig } from '../types/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const storySource = readFileSync(join(__dirname, 'templates', 'story.hbs'), 'utf-8');
const storyTemplate = Handlebars.compile(storySource);

export interface StoryPromptContext {
  epic: Epic;
  prd: PRDDocument;
  orgConfig: OrgConfig;
}

export function buildStoryUserPrompt(ctx: StoryPromptContext): string {
  return storyTemplate({
    epic: ctx.epic,
    prd: ctx.prd,
    maxPoints: ctx.orgConfig.storyDefaults.maxStoryPoints,
    velocity: ctx.orgConfig.jira.boardConfig.teamVelocity,
    exampleStories: ctx.orgConfig.promptOverrides?.exampleStories ?? [],
  });
}
