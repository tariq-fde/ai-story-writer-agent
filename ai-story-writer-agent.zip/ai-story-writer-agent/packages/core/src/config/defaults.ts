import type { OrgConfig } from '../types/index.js';

export const DEFAULT_ORG_CONFIG: OrgConfig = {
  orgId: 'default',
  orgName: 'Default Organization',
  jira: {
    projectKey: 'PROJ',
    issueTypes: {
      epicTypeId: '10000',
      storyTypeId: '10001',
      subTaskTypeId: '10003',
    },
    standardFields: {
      storyPointsField: 'customfield_10028',
      epicLinkField: 'customfield_10014',
      epicNameField: 'customfield_10011',
      sprintField: 'customfield_10020',
      priorityMapping: {
        'must-have': '1',
        'should-have': '2',
        'could-have': '3',
        'wont-have': '4',
      },
    },
    customFields: [],
    boardConfig: {
      boardId: '1',
      sprintDurationWeeks: 2,
      teamVelocity: 40,
    },
  },
  storyDefaults: {
    defaultLabels: ['ai-generated'],
    defaultComponents: [],
    definitionOfDoneTemplate: [
      'Code reviewed and approved',
      'Unit tests passing with >80% coverage',
      'Integration tests passing',
      'Documentation updated',
      'Deployed to staging and verified',
      'PO acceptance confirmed',
    ],
    subTaskTemplates: {
      backend: [
        { titleTemplate: 'Implement {feature} API endpoint', category: 'backend', estimatedHours: 4 },
        { titleTemplate: 'Write unit tests for {feature}', category: 'testing', estimatedHours: 3 },
        { titleTemplate: 'Update API documentation', category: 'documentation', estimatedHours: 1 },
      ],
      frontend: [
        { titleTemplate: 'Implement {feature} UI component', category: 'frontend', estimatedHours: 4 },
        { titleTemplate: 'Write component tests', category: 'testing', estimatedHours: 2 },
        { titleTemplate: 'Accessibility review', category: 'testing', estimatedHours: 1 },
      ],
    },
    estimationScale: 'fibonacci',
    maxStoryPoints: 13,
  },
  workflow: {
    requireApproval: true,
    autoAssignSprint: false,
    notifications: {},
  },
};
