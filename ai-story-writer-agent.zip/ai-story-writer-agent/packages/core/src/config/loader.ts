import { readFileSync } from 'node:fs';
import { orgConfigSchema } from '../schemas/index.js';
import type { OrgConfig } from '../types/index.js';
import { DEFAULT_ORG_CONFIG } from './defaults.js';

function deepMerge<T extends Record<string, unknown>>(base: T, override: Partial<T>): T {
  const result = { ...base };
  for (const key of Object.keys(override) as Array<keyof T>) {
    const overrideVal = override[key];
    if (overrideVal === undefined) continue;
    const baseVal = base[key];
    if (
      baseVal !== null &&
      overrideVal !== null &&
      typeof baseVal === 'object' &&
      typeof overrideVal === 'object' &&
      !Array.isArray(baseVal) &&
      !Array.isArray(overrideVal)
    ) {
      result[key] = deepMerge(
        baseVal as Record<string, unknown>,
        overrideVal as Record<string, unknown>,
      ) as T[keyof T];
    } else {
      result[key] = overrideVal as T[keyof T];
    }
  }
  return result;
}

export function loadOrgConfig(filePath: string): OrgConfig {
  const raw = readFileSync(filePath, 'utf-8');
  const parsed = JSON.parse(raw);
  const merged = deepMerge(DEFAULT_ORG_CONFIG as unknown as Record<string, unknown>, parsed);
  return orgConfigSchema.parse(merged);
}

export function loadOrgConfigFromObject(overrides: Record<string, unknown>): OrgConfig {
  const merged = deepMerge(DEFAULT_ORG_CONFIG as unknown as Record<string, unknown>, overrides);
  return orgConfigSchema.parse(merged);
}
