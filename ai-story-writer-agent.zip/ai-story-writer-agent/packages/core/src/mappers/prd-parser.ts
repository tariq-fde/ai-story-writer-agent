import { randomUUID } from 'node:crypto';
import type { PRDDocument, PRDMetadata } from '../types/index.js';
import { splitSections, extractFrontmatter } from '../utils/markdown.js';

export function parsePrdMarkdown(
  markdown: string,
  overrides?: { id?: string; sourceUrl?: string },
): PRDDocument {
  const { frontmatter, body } = extractFrontmatter(markdown);
  const sections = splitSections(body);

  const title = extractTitle(frontmatter, sections, body);
  const metadata = extractMetadata(frontmatter, sections);

  return {
    id: overrides?.id ?? randomUUID(),
    title,
    version: (frontmatter?.['version'] as string) ?? '1.0.0',
    sourceUrl: overrides?.sourceUrl ?? (frontmatter?.['sourceUrl'] as string | undefined),
    rawMarkdown: markdown,
    sections,
    metadata,
  };
}

function extractTitle(
  frontmatter: Record<string, unknown> | null,
  sections: ReturnType<typeof splitSections>,
  body: string,
): string {
  if (frontmatter?.['title']) return String(frontmatter['title']);
  if (sections.length > 0) return sections[0].heading;
  const firstLine = body.split('\n')[0]?.replace(/^#+\s*/, '').trim();
  return firstLine || 'Untitled PRD';
}

function extractMetadata(
  frontmatter: Record<string, unknown> | null,
  sections: ReturnType<typeof splitSections>,
): PRDMetadata {
  const base: PRDMetadata = {
    productArea: '',
    priority: 'P2',
    stakeholders: [],
    technicalConstraints: [],
    dependencies: [],
    nfrs: [],
  };

  if (frontmatter) {
    if (frontmatter['productArea']) base.productArea = String(frontmatter['productArea']);
    if (frontmatter['targetRelease']) base.targetRelease = String(frontmatter['targetRelease']);
    if (frontmatter['priority'] && isValidPriority(String(frontmatter['priority']))) {
      base.priority = String(frontmatter['priority']) as PRDMetadata['priority'];
    }
  }

  for (const section of sections) {
    const heading = section.heading.toLowerCase();
    if (heading.includes('technical constraint') || heading.includes('constraint')) {
      base.technicalConstraints = extractBulletItems(section.content);
    }
    if (heading.includes('dependenc')) {
      base.dependencies = extractBulletItems(section.content).map((d) => ({
        name: d,
        type: 'system' as const,
        description: d,
      }));
    }
    if (heading.includes('non-functional') || heading.includes('nfr')) {
      base.nfrs = extractBulletItems(section.content).map((n) => ({
        category: 'performance' as const,
        description: n,
      }));
    }
    if (heading.includes('stakeholder')) {
      base.stakeholders = extractBulletItems(section.content).map((s) => ({
        name: s,
        role: 'Stakeholder',
      }));
    }
    if (!base.productArea && heading.includes('product area')) {
      base.productArea = section.content.trim().split('\n')[0] ?? '';
    }
  }

  if (!base.productArea) base.productArea = 'General';

  return base;
}

function extractBulletItems(content: string): string[] {
  return content
    .split('\n')
    .filter((line) => /^\s*[-*]\s+/.test(line))
    .map((line) => line.replace(/^\s*[-*]\s+/, '').trim())
    .filter(Boolean);
}

function isValidPriority(value: string): boolean {
  return ['P0', 'P1', 'P2', 'P3', 'P4'].includes(value);
}
