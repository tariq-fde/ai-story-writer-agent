import Handlebars from 'handlebars';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import type { Epic, PRDDocument } from '../types/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const reviewSource = readFileSync(
  join(__dirname, '..', 'prompts', 'templates', 'review.hbs'),
  'utf-8',
);
const reviewTemplate = Handlebars.compile(reviewSource);

export function formatStoriesAsMarkdown(prd: PRDDocument, epics: Epic[]): string {
  const allStories = epics.flatMap((e) => e.stories);
  const allSubTasks = allStories.flatMap((s) => s.subTasks);
  const totalPoints = allStories.reduce((sum, s) => sum + s.storyPoints, 0);
  const velocity = 40;
  const estimatedSprints = Math.ceil(totalPoints / velocity);

  return reviewTemplate({
    prd,
    epics,
    epicCount: epics.length,
    storyCount: allStories.length,
    subTaskCount: allSubTasks.length,
    totalPoints,
    estimatedSprints,
  });
}

export function formatSingleStory(story: {
  title: string;
  userStoryStatement: { persona: string; action: string; benefit: string };
  description: string;
  storyPoints: number;
  priority: string;
  acceptanceCriteria: Array<{ title: string; given: string; when: string; then: string }>;
  subTasks: Array<{ title: string; category: string; estimatedHours: number }>;
  definitionOfDone: string[];
}): string {
  const lines: string[] = [
    `## ${story.title}`,
    '',
    `> As a ${story.userStoryStatement.persona}, I want ${story.userStoryStatement.action}, so that ${story.userStoryStatement.benefit}`,
    '',
    `**Points:** ${story.storyPoints} | **Priority:** ${story.priority}`,
    '',
    story.description,
    '',
    '### Acceptance Criteria',
  ];

  for (const ac of story.acceptanceCriteria) {
    lines.push(`#### ${ac.title}`);
    lines.push(`- **Given** ${ac.given}`);
    lines.push(`- **When** ${ac.when}`);
    lines.push(`- **Then** ${ac.then}`);
    lines.push('');
  }

  if (story.subTasks.length > 0) {
    lines.push('### Sub-Tasks');
    for (const st of story.subTasks) {
      lines.push(`- [ ] ${st.title} (${st.category}, ${st.estimatedHours}h)`);
    }
    lines.push('');
  }

  if (story.definitionOfDone.length > 0) {
    lines.push('### Definition of Done');
    for (const d of story.definitionOfDone) {
      lines.push(`- [ ] ${d}`);
    }
  }

  return lines.join('\n');
}
