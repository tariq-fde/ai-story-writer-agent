import type {
  Epic,
  UserStory,
  SubTask,
  JiraFieldMapping,
  JiraCreateIssuePayload,
  JiraAdfDocument,
  JiraAdfNode,
  JiraCustomFieldMapping,
} from '../types/index.js';

export function mapEpicToJira(epic: Epic, mapping: JiraFieldMapping): JiraCreateIssuePayload {
  const description = markdownToAdf(
    `${epic.description}\n\n**Business Value:** ${epic.businessValue}` +
      `\n\n**Acceptance Criteria:**\n${epic.acceptanceCriteria.map((ac) => `- ${ac}`).join('\n')}`,
  );

  const payload: JiraCreateIssuePayload = {
    fields: {
      project: { key: mapping.projectKey },
      issuetype: { id: mapping.issueTypes.epicTypeId },
      summary: epic.title,
      description,
      labels: epic.labels,
      components: epic.components.map((name) => ({ name })),
      [mapping.standardFields.epicNameField]: epic.title,
    },
  };

  applyCustomFields(payload, epic, mapping.customFields);
  return payload;
}

export function mapStoryToJira(
  story: UserStory,
  epicJiraKey: string,
  mapping: JiraFieldMapping,
): JiraCreateIssuePayload {
  const storyStatement =
    `**As a** ${story.userStoryStatement.persona}, ` +
    `**I want** ${story.userStoryStatement.action}, ` +
    `**so that** ${story.userStoryStatement.benefit}`;

  const acSection = story.acceptanceCriteria
    .map(
      (ac) =>
        `### ${ac.title}\n- **Given** ${ac.given}\n- **When** ${ac.when}\n- **Then** ${ac.then}`,
    )
    .join('\n\n');

  const dodSection = story.definitionOfDone.map((d) => `- [ ] ${d}`).join('\n');

  const fullDescription = [
    storyStatement,
    '',
    story.description,
    '',
    '## Acceptance Criteria',
    acSection,
    '',
    '## Definition of Done',
    dodSection,
    story.technicalNotes ? `\n## Technical Notes\n${story.technicalNotes}` : '',
  ].join('\n');

  const description = markdownToAdf(fullDescription);
  const priorityId = mapping.standardFields.priorityMapping[story.priority];

  const payload: JiraCreateIssuePayload = {
    fields: {
      project: { key: mapping.projectKey },
      issuetype: { id: mapping.issueTypes.storyTypeId },
      summary: story.title,
      description,
      priority: priorityId ? { id: priorityId } : undefined,
      labels: story.labels,
      components: story.components.map((name) => ({ name })),
      [mapping.standardFields.epicLinkField]: epicJiraKey,
      [mapping.standardFields.storyPointsField]: story.storyPoints,
    },
  };

  applyCustomFields(payload, story, mapping.customFields);
  return payload;
}

export function mapSubTaskToJira(
  subTask: SubTask,
  parentJiraKey: string,
  mapping: JiraFieldMapping,
): JiraCreateIssuePayload {
  const fullDescription = [
    subTask.description,
    '',
    `**Category:** ${subTask.category}`,
    `**Estimated Hours:** ${subTask.estimatedHours}`,
    subTask.technicalDetails ? `\n**Technical Details:**\n${subTask.technicalDetails}` : '',
  ].join('\n');

  return {
    fields: {
      project: { key: mapping.projectKey },
      issuetype: { id: mapping.issueTypes.subTaskTypeId },
      summary: subTask.title,
      description: markdownToAdf(fullDescription),
      parent: { key: parentJiraKey } as unknown as JiraAdfDocument,
      labels: subTask.labels,
      components: subTask.component ? [{ name: subTask.component }] : [],
    },
  };
}

function applyCustomFields(
  payload: JiraCreateIssuePayload,
  source: Record<string, unknown>,
  customFields: JiraCustomFieldMapping[],
) {
  for (const cf of customFields) {
    const value = source[cf.internalField as keyof typeof source];
    if (value === undefined) continue;

    switch (cf.transform) {
      case 'join_array':
        payload.fields[cf.jiraFieldId] = Array.isArray(value) ? value.join(', ') : value;
        break;
      case 'map_value':
        payload.fields[cf.jiraFieldId] = cf.valueMap?.[String(value)] ?? value;
        break;
      case 'format_date':
        payload.fields[cf.jiraFieldId] =
          value instanceof Date ? value.toISOString().split('T')[0] : value;
        break;
      default:
        payload.fields[cf.jiraFieldId] = value;
    }
  }
}

export function markdownToAdf(markdown: string): JiraAdfDocument {
  const lines = markdown.split('\n');
  const content: JiraAdfNode[] = [];
  let currentParagraph: JiraAdfNode[] = [];

  function flushParagraph() {
    if (currentParagraph.length > 0) {
      content.push({ type: 'paragraph', content: currentParagraph });
      currentParagraph = [];
    }
  }

  for (const line of lines) {
    const headingMatch = line.match(/^(#{1,6})\s+(.+)/);
    if (headingMatch) {
      flushParagraph();
      const level = headingMatch[1].length;
      content.push({
        type: 'heading',
        attrs: { level },
        content: [{ type: 'text', text: headingMatch[2] }],
      });
      continue;
    }

    const bulletMatch = line.match(/^\s*[-*]\s+(.*)/);
    if (bulletMatch) {
      flushParagraph();
      const itemContent = parseInlineMarks(bulletMatch[1]);
      content.push({
        type: 'bulletList',
        content: [
          {
            type: 'listItem',
            content: [{ type: 'paragraph', content: itemContent }],
          },
        ],
      });
      continue;
    }

    if (line.trim() === '') {
      flushParagraph();
      continue;
    }

    currentParagraph.push(...parseInlineMarks(line));
    currentParagraph.push({ type: 'text', text: ' ' });
  }

  flushParagraph();

  return { type: 'doc', version: 1, content };
}

function parseInlineMarks(text: string): JiraAdfNode[] {
  const nodes: JiraAdfNode[] = [];
  const regex = /\*\*(.+?)\*\*/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      nodes.push({ type: 'text', text: text.slice(lastIndex, match.index) });
    }
    nodes.push({
      type: 'text',
      text: match[1],
      marks: [{ type: 'strong' }],
    });
    lastIndex = regex.lastIndex;
  }

  if (lastIndex < text.length) {
    nodes.push({ type: 'text', text: text.slice(lastIndex) });
  }

  return nodes.length > 0 ? nodes : [{ type: 'text', text }];
}
