import type { PRDSection } from '../types/index.js';

export interface HeadingMatch {
  level: number;
  text: string;
  startIndex: number;
  endIndex: number;
}

export function extractHeadings(markdown: string): HeadingMatch[] {
  const headings: HeadingMatch[] = [];
  const regex = /^(#{1,6})\s+(.+)$/gm;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(markdown)) !== null) {
    headings.push({
      level: match[1].length,
      text: match[2].trim(),
      startIndex: match.index,
      endIndex: match.index + match[0].length,
    });
  }
  return headings;
}

export function splitSections(markdown: string): PRDSection[] {
  const headings = extractHeadings(markdown);
  if (headings.length === 0) {
    return [{ heading: 'Content', level: 1, content: markdown.trim(), subsections: [] }];
  }

  const flatSections: Array<{ heading: string; level: number; content: string }> = [];
  for (let i = 0; i < headings.length; i++) {
    const start = headings[i].endIndex;
    const end = i + 1 < headings.length ? headings[i + 1].startIndex : markdown.length;
    flatSections.push({
      heading: headings[i].text,
      level: headings[i].level,
      content: markdown.slice(start, end).trim(),
    });
  }

  return buildSectionTree(flatSections);
}

function buildSectionTree(
  flat: Array<{ heading: string; level: number; content: string }>,
): PRDSection[] {
  const root: PRDSection[] = [];
  const stack: PRDSection[] = [];

  for (const item of flat) {
    const section: PRDSection = {
      heading: item.heading,
      level: item.level,
      content: item.content,
      subsections: [],
    };

    while (stack.length > 0 && stack[stack.length - 1].level >= item.level) {
      stack.pop();
    }

    if (stack.length === 0) {
      root.push(section);
    } else {
      stack[stack.length - 1].subsections.push(section);
    }
    stack.push(section);
  }

  return root;
}

export function extractFrontmatter(markdown: string): {
  frontmatter: Record<string, unknown> | null;
  body: string;
} {
  const fmRegex = /^---\r?\n([\s\S]*?)\r?\n---\r?\n/;
  const match = fmRegex.exec(markdown);
  if (!match) return { frontmatter: null, body: markdown };

  const yamlBlock = match[1];
  const body = markdown.slice(match[0].length);
  const frontmatter: Record<string, unknown> = {};

  for (const line of yamlBlock.split('\n')) {
    const colonIdx = line.indexOf(':');
    if (colonIdx === -1) continue;
    const key = line.slice(0, colonIdx).trim();
    let value: unknown = line.slice(colonIdx + 1).trim();
    if (value === 'true') value = true;
    else if (value === 'false') value = false;
    else if (typeof value === 'string' && /^\d+$/.test(value)) value = parseInt(value, 10);
    if (key) frontmatter[key] = value;
  }

  return { frontmatter, body };
}
