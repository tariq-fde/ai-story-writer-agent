import { z } from 'zod';

export const stakeholderSchema = z.object({
  name: z.string().min(1),
  role: z.string().min(1),
  email: z.string().email().optional(),
});

export const dependencySchema = z.object({
  name: z.string().min(1),
  type: z.enum(['system', 'team', 'external']),
  description: z.string().min(1),
});

export const nfrSchema = z.object({
  category: z.enum(['performance', 'security', 'scalability', 'accessibility', 'compliance']),
  description: z.string().min(1),
  metric: z.string().optional(),
});

export const prdMetadataSchema = z.object({
  productArea: z.string().min(1),
  targetRelease: z.string().optional(),
  priority: z.enum(['P0', 'P1', 'P2', 'P3', 'P4']),
  stakeholders: z.array(stakeholderSchema),
  technicalConstraints: z.array(z.string()),
  dependencies: z.array(dependencySchema),
  nfrs: z.array(nfrSchema),
});

export const prdSectionSchema: z.ZodType<{
  heading: string;
  level: number;
  content: string;
  subsections: unknown[];
}> = z.object({
  heading: z.string().min(1),
  level: z.number().int().min(1).max(6),
  content: z.string(),
  subsections: z.lazy(() => z.array(prdSectionSchema)),
});

export const prdDocumentSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  version: z.string().min(1),
  sourceUrl: z.string().url().optional(),
  rawMarkdown: z.string().min(1),
  sections: z.array(prdSectionSchema),
  metadata: prdMetadataSchema,
});
