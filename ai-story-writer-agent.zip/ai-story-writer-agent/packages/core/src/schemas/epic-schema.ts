import { z } from 'zod';

export const epicEstimateSchema = z.object({
  size: z.enum(['XS', 'S', 'M', 'L', 'XL']),
  totalStoryPoints: z.number().int().min(0),
  estimatedSprintCount: z.number().int().min(1),
});

export const reviewStatusSchema = z.enum([
  'draft',
  'ready_for_review',
  'approved',
  'rejected',
  'revision_requested',
]);

export const sprintRangeSchema = z.object({
  startSprint: z.number().int().min(1),
  endSprint: z.number().int().min(1),
});

export const epicGenerationOutputSchema = z.object({
  epics: z.array(
    z.object({
      title: z.string().min(1),
      description: z.string().min(10),
      businessValue: z.string().min(10),
      acceptanceCriteria: z.array(z.string().min(1)).min(1),
      estimate: z.object({ size: z.enum(['XS', 'S', 'M', 'L', 'XL']) }),
      priority: z.number().int().min(1),
      labels: z.array(z.string()),
      components: z.array(z.string()),
    }),
  ),
});
