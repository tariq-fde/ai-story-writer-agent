import { z } from 'zod';
import { storyPointValueSchema } from './story-schema.js';
import { subTaskCategorySchema } from './subtask-schema.js';

export const jiraBoardConfigSchema = z.object({
  boardId: z.string().min(1),
  activeSprintId: z.string().optional(),
  sprintDurationWeeks: z.number().int().min(1).max(6),
  teamVelocity: z.number().int().min(1),
});

export const jiraCustomFieldSchema = z.object({
  internalField: z.string().min(1),
  jiraFieldId: z.string().min(1),
  displayName: z.string().min(1),
  transform: z.enum(['identity', 'join_array', 'map_value', 'format_date']).optional(),
  valueMap: z.record(z.string()).optional(),
});

export const jiraFieldMappingSchema = z.object({
  projectKey: z.string().min(1).max(10),
  issueTypes: z.object({
    epicTypeId: z.string().min(1),
    storyTypeId: z.string().min(1),
    subTaskTypeId: z.string().min(1),
  }),
  standardFields: z.object({
    storyPointsField: z.string().min(1),
    epicLinkField: z.string().min(1),
    epicNameField: z.string().min(1),
    sprintField: z.string().min(1),
    priorityMapping: z.record(z.string()),
  }),
  customFields: z.array(jiraCustomFieldSchema),
  boardConfig: jiraBoardConfigSchema,
});

export const subTaskTemplateSchema = z.object({
  titleTemplate: z.string().min(1),
  category: subTaskCategorySchema,
  estimatedHours: z.number().min(0.5).max(16),
});

export const orgConfigSchema = z.object({
  orgId: z.string().min(1),
  orgName: z.string().min(1),
  jira: jiraFieldMappingSchema,
  storyDefaults: z.object({
    defaultLabels: z.array(z.string()),
    defaultComponents: z.array(z.string()),
    definitionOfDoneTemplate: z.array(z.string().min(1)),
    subTaskTemplates: z.record(z.array(subTaskTemplateSchema)),
    estimationScale: z.enum(['fibonacci', 'linear', 'tshirt']),
    maxStoryPoints: storyPointValueSchema,
  }),
  promptOverrides: z
    .object({
      systemPromptAddendum: z.string().optional(),
      terminology: z.record(z.string()).optional(),
      exampleStories: z.array(z.any()).optional(),
    })
    .optional(),
  workflow: z.object({
    requireApproval: z.boolean(),
    autoAssignSprint: z.boolean(),
    notifications: z.object({
      pubsubTopic: z.string().optional(),
      slackWebhookUrl: z.string().url().optional(),
    }),
  }),
});
