import { z } from 'zod';

export const storyPointValueSchema = z.union([
  z.literal(1),
  z.literal(2),
  z.literal(3),
  z.literal(5),
  z.literal(8),
  z.literal(13),
  z.literal(21),
]);

export const acceptanceCriteriaSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  given: z.string().min(1),
  when: z.string().min(1),
  then: z.string().min(1),
});

export const userStoryStatementSchema = z.object({
  persona: z.string().min(1),
  action: z.string().min(1),
  benefit: z.string().min(1),
});

export const storyGenerationOutputSchema = z.object({
  stories: z.array(
    z.object({
      title: z.string().min(1),
      userStoryStatement: userStoryStatementSchema,
      description: z.string().min(10),
      acceptanceCriteria: z.array(acceptanceCriteriaSchema).min(2),
      storyPoints: storyPointValueSchema,
      priority: z.enum(['must-have', 'should-have', 'could-have', 'wont-have']),
      labels: z.array(z.string()),
      components: z.array(z.string()),
      dependsOn: z.array(z.string()),
      technicalNotes: z.string().optional(),
      definitionOfDone: z.array(z.string().min(1)).min(1),
      suggestedSprint: z.number().int().min(1).optional(),
    }),
  ),
});
