import { z } from 'zod';

export const subTaskCategorySchema = z.enum([
  'frontend',
  'backend',
  'api',
  'database',
  'infrastructure',
  'testing',
  'documentation',
  'design',
  'devops',
  'security',
  'integration',
]);

export const subtaskGenerationOutputSchema = z.object({
  subtasks: z.array(
    z.object({
      title: z.string().min(1),
      description: z.string().min(10),
      estimatedHours: z.number().min(0.5).max(16),
      category: subTaskCategorySchema,
      technicalDetails: z.string().optional(),
      labels: z.array(z.string()),
      component: z.string().optional(),
    }),
  ),
});
