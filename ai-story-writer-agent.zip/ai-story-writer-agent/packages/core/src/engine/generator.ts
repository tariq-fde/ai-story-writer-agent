import { randomUUID } from 'node:crypto';
import type { Epic, PRDDocument, OrgConfig, UserStory } from '../types/index.js';
import { storyGenerationOutputSchema } from '../schemas/index.js';
import { subtaskGenerationOutputSchema } from '../schemas/index.js';
import { buildStoryUserPrompt } from '../prompts/index.js';
import { buildSubtaskUserPrompt } from '../prompts/index.js';
import { buildEpicSystemPrompt } from '../prompts/index.js';
import type { LlmCaller } from './story-engine.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('generator');

export async function generateStoriesForEpic(
  epic: Epic,
  prd: PRDDocument,
  orgConfig: OrgConfig,
  llmCaller: LlmCaller,
  generateSubTasks: boolean,
  maxRetries: number,
): Promise<UserStory[]> {
  const systemPrompt = buildEpicSystemPrompt({ prd, orgConfig });
  const userPrompt = buildStoryUserPrompt({ epic, prd, orgConfig });

  let stories: UserStory[] = [];
  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const response = await llmCaller(systemPrompt, userPrompt);
      const json = extractJson(response);
      const parsed = storyGenerationOutputSchema.parse(json);

      stories = parsed.stories.map((raw) => ({
        id: randomUUID(),
        epicId: epic.id,
        title: raw.title,
        userStoryStatement: raw.userStoryStatement,
        description: raw.description,
        acceptanceCriteria: raw.acceptanceCriteria,
        storyPoints: raw.storyPoints,
        priority: raw.priority,
        labels: [...orgConfig.storyDefaults.defaultLabels, ...raw.labels],
        components: [...orgConfig.storyDefaults.defaultComponents, ...raw.components],
        dependsOn: raw.dependsOn,
        subTasks: [],
        technicalNotes: raw.technicalNotes,
        definitionOfDone: raw.definitionOfDone.length > 0
          ? raw.definitionOfDone
          : orgConfig.storyDefaults.definitionOfDoneTemplate,
        suggestedSprint: raw.suggestedSprint,
        reviewStatus: 'draft',
        reviewComments: [],
      }));
      break;
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
      logger.warn(
        { attempt, epicTitle: epic.title, error: lastError.message },
        'Story generation attempt failed',
      );
    }
  }

  if (stories.length === 0) {
    throw new Error(
      `Story generation for epic "${epic.title}" failed after ${maxRetries} attempts: ${lastError?.message}`,
    );
  }

  if (generateSubTasks) {
    for (const story of stories) {
      story.subTasks = await generateSubTasksForStory(
        story,
        orgConfig,
        llmCaller,
        systemPrompt,
        maxRetries,
      );
    }
  }

  return stories;
}

async function generateSubTasksForStory(
  story: UserStory,
  orgConfig: OrgConfig,
  llmCaller: LlmCaller,
  systemPrompt: string,
  maxRetries: number,
) {
  const userPrompt = buildSubtaskUserPrompt({ story, orgConfig });

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const response = await llmCaller(systemPrompt, userPrompt);
      const json = extractJson(response);
      const parsed = subtaskGenerationOutputSchema.parse(json);

      return parsed.subtasks.map((raw) => ({
        id: randomUUID(),
        storyId: story.id,
        title: raw.title,
        description: raw.description,
        estimatedHours: raw.estimatedHours,
        category: raw.category,
        technicalDetails: raw.technicalDetails,
        labels: raw.labels,
        component: raw.component,
      }));
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      logger.warn(
        { attempt, storyTitle: story.title, error: msg },
        'Sub-task generation attempt failed',
      );
    }
  }

  logger.warn({ storyTitle: story.title }, 'Sub-task generation exhausted retries, returning empty');
  return [];
}

function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/);
  const jsonStr = fenced ? fenced[1] : text;
  return JSON.parse(jsonStr.trim());
}
