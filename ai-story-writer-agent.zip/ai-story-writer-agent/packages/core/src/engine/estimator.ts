import type { UserStory, StoryPointValue, OrgConfig } from '../types/index.js';

const FIBONACCI: StoryPointValue[] = [1, 2, 3, 5, 8, 13, 21];

export function nearestFibonacci(value: number): StoryPointValue {
  let closest = FIBONACCI[0];
  let minDiff = Math.abs(value - closest);
  for (const fib of FIBONACCI) {
    const diff = Math.abs(value - fib);
    if (diff < minDiff) {
      minDiff = diff;
      closest = fib;
    }
  }
  return closest;
}

export function shouldSplit(story: UserStory, orgConfig: OrgConfig): boolean {
  return story.storyPoints > orgConfig.storyDefaults.maxStoryPoints;
}

export function estimateTotalEffort(stories: UserStory[]): {
  totalPoints: number;
  averagePoints: number;
  distribution: Record<StoryPointValue, number>;
} {
  const distribution = Object.fromEntries(FIBONACCI.map((f) => [f, 0])) as Record<
    StoryPointValue,
    number
  >;
  let totalPoints = 0;

  for (const story of stories) {
    totalPoints += story.storyPoints;
    distribution[story.storyPoints] = (distribution[story.storyPoints] || 0) + 1;
  }

  return {
    totalPoints,
    averagePoints: stories.length > 0 ? totalPoints / stories.length : 0,
    distribution,
  };
}
