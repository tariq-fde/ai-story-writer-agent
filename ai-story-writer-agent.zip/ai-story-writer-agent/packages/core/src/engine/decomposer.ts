import { randomUUID } from 'node:crypto';
import type { PRDDocument, OrgConfig, Epic } from '../types/index.js';
import { epicGenerationOutputSchema } from '../schemas/index.js';
import { buildEpicSystemPrompt, buildEpicUserPrompt } from '../prompts/index.js';
import type { LlmCaller } from './story-engine.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('decomposer');

export async function decomposePrdToEpics(
  prd: PRDDocument,
  orgConfig: OrgConfig,
  llmCaller: LlmCaller,
  maxRetries: number,
): Promise<Epic[]> {
  const systemPrompt = buildEpicSystemPrompt({ prd, orgConfig });
  const userPrompt = buildEpicUserPrompt({ prd, orgConfig });

  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const response = await llmCaller(systemPrompt, userPrompt);
      const json = extractJson(response);
      const parsed = epicGenerationOutputSchema.parse(json);

      return parsed.epics.map((raw) => ({
        id: randomUUID(),
        prdId: prd.id,
        title: raw.title,
        description: raw.description,
        businessValue: raw.businessValue,
        acceptanceCriteria: raw.acceptanceCriteria,
        estimate: {
          size: raw.estimate.size,
          totalStoryPoints: 0,
          estimatedSprintCount: 0,
        },
        priority: raw.priority,
        labels: [...orgConfig.storyDefaults.defaultLabels, ...raw.labels],
        components: [...orgConfig.storyDefaults.defaultComponents, ...raw.components],
        stories: [],
        reviewStatus: 'draft',
      }));
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
      logger.warn({ attempt, error: lastError.message }, 'Epic decomposition attempt failed');
    }
  }

  throw new Error(`Epic decomposition failed after ${maxRetries} attempts: ${lastError?.message}`);
}

function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/);
  const jsonStr = fenced ? fenced[1] : text;
  return JSON.parse(jsonStr.trim());
}
