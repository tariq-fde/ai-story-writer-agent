import { randomUUID } from 'node:crypto';
import type { PRDDocument, OrgConfig, Epic } from '../types/index.js';
import { decomposePrdToEpics } from './decomposer.js';
import { generateStoriesForEpic } from './generator.js';
import { assignSprints } from './sprint-planner.js';
import { createLogger } from '../utils/logger.js';

const logger = createLogger('story-engine');

export type LlmCaller = (systemPrompt: string, userPrompt: string) => Promise<string>;

export interface StoryEngineOptions {
  llmCaller: LlmCaller;
  orgConfig: OrgConfig;
  generateSubTasks?: boolean;
  maxRetries?: number;
}

export interface StoryEngineResult {
  runId: string;
  prdId: string;
  epics: Epic[];
  totalStoryPoints: number;
  estimatedSprints: number;
}

export async function generateStories(
  prd: PRDDocument,
  options: StoryEngineOptions,
): Promise<StoryEngineResult> {
  const { llmCaller, orgConfig, generateSubTasks = true, maxRetries = 3 } = options;
  const runId = randomUUID();

  logger.info({ runId, prdId: prd.id, title: prd.title }, 'Starting story generation');

  const epics = await decomposePrdToEpics(prd, orgConfig, llmCaller, maxRetries);
  logger.info({ runId, epicCount: epics.length }, 'Epics decomposed');

  for (const epic of epics) {
    const stories = await generateStoriesForEpic(
      epic,
      prd,
      orgConfig,
      llmCaller,
      generateSubTasks,
      maxRetries,
    );
    epic.stories = stories;

    const totalPoints = stories.reduce((sum, s) => sum + s.storyPoints, 0);
    epic.estimate.totalStoryPoints = totalPoints;
    epic.estimate.estimatedSprintCount = Math.ceil(
      totalPoints / orgConfig.jira.boardConfig.teamVelocity,
    );

    logger.info(
      { runId, epicTitle: epic.title, storyCount: stories.length, totalPoints },
      'Stories generated for epic',
    );
  }

  const allStories = epics.flatMap((e) => e.stories);
  assignSprints(allStories, orgConfig.jira.boardConfig.teamVelocity);

  const totalStoryPoints = allStories.reduce((sum, s) => sum + s.storyPoints, 0);
  const estimatedSprints = Math.ceil(totalStoryPoints / orgConfig.jira.boardConfig.teamVelocity);

  logger.info(
    {
      runId,
      epicCount: epics.length,
      storyCount: allStories.length,
      subTaskCount: allStories.reduce((sum, s) => sum + s.subTasks.length, 0),
      totalStoryPoints,
      estimatedSprints,
    },
    'Story generation complete',
  );

  return { runId, prdId: prd.id, epics, totalStoryPoints, estimatedSprints };
}
