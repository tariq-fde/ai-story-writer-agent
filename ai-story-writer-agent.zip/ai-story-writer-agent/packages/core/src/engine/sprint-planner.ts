import type { UserStory } from '../types/index.js';

export function assignSprints(stories: UserStory[], velocity: number): void {
  const ordered = topologicalSort(stories);
  let currentSprint = 1;
  let pointsInSprint = 0;

  for (const story of ordered) {
    const depSprint = maxDependencySprint(story, stories);
    if (depSprint >= currentSprint) {
      currentSprint = depSprint + 1;
      pointsInSprint = 0;
    }

    if (pointsInSprint + story.storyPoints > velocity) {
      currentSprint++;
      pointsInSprint = 0;
    }

    story.suggestedSprint = currentSprint;
    pointsInSprint += story.storyPoints;
  }
}

function maxDependencySprint(story: UserStory, allStories: UserStory[]): number {
  let maxSprint = 0;
  for (const depRef of story.dependsOn) {
    const dep = allStories.find(
      (s) => s.id === depRef || s.title === depRef,
    );
    if (dep?.suggestedSprint && dep.suggestedSprint > maxSprint) {
      maxSprint = dep.suggestedSprint;
    }
  }
  return maxSprint;
}

function topologicalSort(stories: UserStory[]): UserStory[] {
  const visited = new Set<string>();
  const result: UserStory[] = [];
  const lookup = new Map<string, UserStory>();

  for (const s of stories) {
    lookup.set(s.id, s);
    lookup.set(s.title, s);
  }

  function visit(story: UserStory) {
    if (visited.has(story.id)) return;
    visited.add(story.id);

    for (const depRef of story.dependsOn) {
      const dep = lookup.get(depRef);
      if (dep) visit(dep);
    }
    result.push(story);
  }

  for (const story of stories) {
    visit(story);
  }

  return result;
}
