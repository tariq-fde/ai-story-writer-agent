import type { Epic, UserStory, SubTask } from '../types/index.js';

export interface CompletenessReport {
  complete: boolean;
  missingFields: MissingField[];
}

export interface MissingField {
  entityType: 'epic' | 'story' | 'subtask';
  entityId: string;
  entityTitle: string;
  field: string;
  message: string;
}

export function checkEpicCompleteness(epic: Epic): CompletenessReport {
  const missingFields: MissingField[] = [];
  const ctx = { entityType: 'epic' as const, entityId: epic.id, entityTitle: epic.title };

  if (!epic.title.trim()) missingFields.push({ ...ctx, field: 'title', message: 'Title is empty' });
  if (!epic.description.trim())
    missingFields.push({ ...ctx, field: 'description', message: 'Description is empty' });
  if (!epic.businessValue.trim())
    missingFields.push({ ...ctx, field: 'businessValue', message: 'Business value is empty' });
  if (epic.acceptanceCriteria.length === 0)
    missingFields.push({
      ...ctx,
      field: 'acceptanceCriteria',
      message: 'No acceptance criteria',
    });
  if (epic.stories.length === 0)
    missingFields.push({ ...ctx, field: 'stories', message: 'No stories' });

  for (const story of epic.stories) {
    missingFields.push(...checkStoryCompleteness(story).missingFields);
  }

  return { complete: missingFields.length === 0, missingFields };
}

export function checkStoryCompleteness(story: UserStory): CompletenessReport {
  const missingFields: MissingField[] = [];
  const ctx = { entityType: 'story' as const, entityId: story.id, entityTitle: story.title };

  if (!story.title.trim()) missingFields.push({ ...ctx, field: 'title', message: 'Title is empty' });
  if (!story.description.trim())
    missingFields.push({ ...ctx, field: 'description', message: 'Description is empty' });
  if (story.acceptanceCriteria.length < 2)
    missingFields.push({
      ...ctx,
      field: 'acceptanceCriteria',
      message: 'Fewer than 2 acceptance criteria',
    });
  if (story.definitionOfDone.length === 0)
    missingFields.push({
      ...ctx,
      field: 'definitionOfDone',
      message: 'No definition of done items',
    });

  for (const subTask of story.subTasks) {
    missingFields.push(...checkSubTaskCompleteness(subTask).missingFields);
  }

  return { complete: missingFields.length === 0, missingFields };
}

export function checkSubTaskCompleteness(subTask: SubTask): CompletenessReport {
  const missingFields: MissingField[] = [];
  const ctx = {
    entityType: 'subtask' as const,
    entityId: subTask.id,
    entityTitle: subTask.title,
  };

  if (!subTask.title.trim())
    missingFields.push({ ...ctx, field: 'title', message: 'Title is empty' });
  if (!subTask.description.trim())
    missingFields.push({ ...ctx, field: 'description', message: 'Description is empty' });
  if (subTask.estimatedHours <= 0)
    missingFields.push({ ...ctx, field: 'estimatedHours', message: 'Estimated hours must be > 0' });

  return { complete: missingFields.length === 0, missingFields };
}
