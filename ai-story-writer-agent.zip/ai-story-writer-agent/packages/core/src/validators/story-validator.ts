import type { UserStory, Epic, StoryPointValue } from '../types/index.js';

export interface ValidationError {
  field: string;
  message: string;
  storyId?: string;
  storyTitle?: string;
}

const VALID_STORY_POINTS: StoryPointValue[] = [1, 2, 3, 5, 8, 13, 21];

export function validateStory(story: UserStory, maxPoints: StoryPointValue): ValidationError[] {
  const errors: ValidationError[] = [];
  const ctx = { storyId: story.id, storyTitle: story.title };

  if (!story.title.trim()) {
    errors.push({ field: 'title', message: 'Story title is required', ...ctx });
  }

  if (!story.userStoryStatement.persona.trim()) {
    errors.push({ field: 'userStoryStatement.persona', message: 'Persona is required', ...ctx });
  }
  if (!story.userStoryStatement.action.trim()) {
    errors.push({ field: 'userStoryStatement.action', message: 'Action is required', ...ctx });
  }
  if (!story.userStoryStatement.benefit.trim()) {
    errors.push({ field: 'userStoryStatement.benefit', message: 'Benefit is required', ...ctx });
  }

  if (story.acceptanceCriteria.length < 2) {
    errors.push({
      field: 'acceptanceCriteria',
      message: 'At least 2 acceptance criteria required',
      ...ctx,
    });
  }

  if (!VALID_STORY_POINTS.includes(story.storyPoints)) {
    errors.push({
      field: 'storyPoints',
      message: `Story points must be Fibonacci: ${VALID_STORY_POINTS.join(', ')}`,
      ...ctx,
    });
  }

  if (story.storyPoints > maxPoints) {
    errors.push({
      field: 'storyPoints',
      message: `Story exceeds max ${maxPoints} points — should be split`,
      ...ctx,
    });
  }

  if (story.definitionOfDone.length === 0) {
    errors.push({
      field: 'definitionOfDone',
      message: 'At least one Definition of Done item required',
      ...ctx,
    });
  }

  return errors;
}

export function validateEpicStories(
  epic: Epic,
  allStories: UserStory[],
  maxPoints: StoryPointValue,
): ValidationError[] {
  const errors: ValidationError[] = [];

  for (const story of epic.stories) {
    errors.push(...validateStory(story, maxPoints));
    errors.push(...validateDependencies(story, allStories));
  }

  return errors;
}

export function validateDependencies(
  story: UserStory,
  allStories: UserStory[],
): ValidationError[] {
  const errors: ValidationError[] = [];
  const allIds = new Set(allStories.map((s) => s.id));
  const allTitles = new Set(allStories.map((s) => s.title));

  for (const dep of story.dependsOn) {
    if (!allIds.has(dep) && !allTitles.has(dep)) {
      errors.push({
        field: 'dependsOn',
        message: `Dependency "${dep}" references a non-existent story`,
        storyId: story.id,
        storyTitle: story.title,
      });
    }
  }

  return errors;
}
