import type { SubTask } from './subtask.js';
import type { ReviewStatus } from './epic.js';

export interface UserStory {
  id: string;
  epicId: string;
  title: string;
  userStoryStatement: UserStoryStatement;
  description: string;
  acceptanceCriteria: AcceptanceCriteria[];
  storyPoints: StoryPointValue;
  priority: 'must-have' | 'should-have' | 'could-have' | 'wont-have';
  labels: string[];
  components: string[];
  dependsOn: string[];
  subTasks: SubTask[];
  technicalNotes?: string;
  definitionOfDone: string[];
  suggestedSprint?: number;
  reviewStatus: ReviewStatus;
  reviewComments: ReviewComment[];
}

export interface UserStoryStatement {
  persona: string;
  action: string;
  benefit: string;
}

export interface AcceptanceCriteria {
  id: string;
  title: string;
  given: string;
  when: string;
  then: string;
}

export type StoryPointValue = 1 | 2 | 3 | 5 | 8 | 13 | 21;

export interface ReviewComment {
  author: string;
  timestamp: string;
  comment: string;
  field?: string;
}
