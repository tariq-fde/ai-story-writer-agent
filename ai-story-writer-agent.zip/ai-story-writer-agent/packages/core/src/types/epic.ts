import type { UserStory } from './story.js';

export interface Epic {
  id: string;
  prdId: string;
  title: string;
  description: string;
  businessValue: string;
  acceptanceCriteria: string[];
  estimate: EpicEstimate;
  priority: number;
  labels: string[];
  components: string[];
  stories: UserStory[];
  targetSprints?: SprintRange;
  reviewStatus: ReviewStatus;
}

export interface EpicEstimate {
  size: 'XS' | 'S' | 'M' | 'L' | 'XL';
  totalStoryPoints: number;
  estimatedSprintCount: number;
}

export interface SprintRange {
  startSprint: number;
  endSprint: number;
}

export type ReviewStatus =
  | 'draft'
  | 'ready_for_review'
  | 'approved'
  | 'rejected'
  | 'revision_requested';
