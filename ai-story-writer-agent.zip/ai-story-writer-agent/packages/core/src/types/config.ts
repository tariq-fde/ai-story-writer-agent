import type { JiraFieldMapping } from './jira.js';
import type { SubTaskCategory } from './subtask.js';
import type { StoryPointValue } from './story.js';
import type { UserStory } from './story.js';

export interface OrgConfig {
  orgId: string;
  orgName: string;
  jira: JiraFieldMapping;
  storyDefaults: StoryDefaults;
  promptOverrides?: PromptOverrides;
  workflow: WorkflowConfig;
}

export interface StoryDefaults {
  defaultLabels: string[];
  defaultComponents: string[];
  definitionOfDoneTemplate: string[];
  subTaskTemplates: Record<string, SubTaskTemplate[]>;
  estimationScale: 'fibonacci' | 'linear' | 'tshirt';
  maxStoryPoints: StoryPointValue;
}

export interface SubTaskTemplate {
  titleTemplate: string;
  category: SubTaskCategory;
  estimatedHours: number;
}

export interface PromptOverrides {
  systemPromptAddendum?: string;
  terminology?: Record<string, string>;
  exampleStories?: UserStory[];
}

export interface WorkflowConfig {
  requireApproval: boolean;
  autoAssignSprint: boolean;
  notifications: NotificationConfig;
}

export interface NotificationConfig {
  pubsubTopic?: string;
  slackWebhookUrl?: string;
}
