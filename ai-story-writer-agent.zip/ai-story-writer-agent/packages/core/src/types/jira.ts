export interface JiraFieldMapping {
  projectKey: string;
  issueTypes: JiraIssueTypeMapping;
  standardFields: JiraStandardFieldMapping;
  customFields: JiraCustomFieldMapping[];
  boardConfig: JiraBoardConfig;
}

export interface JiraIssueTypeMapping {
  epicTypeId: string;
  storyTypeId: string;
  subTaskTypeId: string;
}

export interface JiraStandardFieldMapping {
  storyPointsField: string;
  epicLinkField: string;
  epicNameField: string;
  sprintField: string;
  priorityMapping: Record<string, string>;
}

export interface JiraCustomFieldMapping {
  internalField: string;
  jiraFieldId: string;
  displayName: string;
  transform?: 'identity' | 'join_array' | 'map_value' | 'format_date';
  valueMap?: Record<string, string>;
}

export interface JiraBoardConfig {
  boardId: string;
  activeSprintId?: string;
  sprintDurationWeeks: number;
  teamVelocity: number;
}

export interface JiraCreateIssuePayload {
  fields: {
    project: { key: string };
    issuetype: { id: string };
    summary: string;
    description: JiraAdfDocument;
    priority?: { id: string };
    labels?: string[];
    components?: Array<{ name: string }>;
    [customField: string]: unknown;
  };
}

export interface JiraAdfDocument {
  type: 'doc';
  version: 1;
  content: JiraAdfNode[];
}

export interface JiraAdfNode {
  type: string;
  content?: JiraAdfNode[];
  text?: string;
  attrs?: Record<string, unknown>;
  marks?: Array<{ type: string; attrs?: Record<string, unknown> }>;
}

export interface JiraPushResult {
  success: boolean;
  createdIssues: JiraCreatedIssue[];
  errors: JiraPushError[];
}

export interface JiraCreatedIssue {
  internalId: string;
  jiraKey: string;
  jiraId: string;
  issueType: 'epic' | 'story' | 'subtask';
  selfUrl: string;
}

export interface JiraPushError {
  internalId: string;
  issueType: 'epic' | 'story' | 'subtask';
  error: string;
  jiraErrors?: Record<string, string>;
}
