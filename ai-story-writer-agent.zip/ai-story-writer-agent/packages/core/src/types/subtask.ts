export interface SubTask {
  id: string;
  storyId: string;
  title: string;
  description: string;
  estimatedHours: number;
  category: SubTaskCategory;
  technicalDetails?: string;
  labels: string[];
  component?: string;
}

export type SubTaskCategory =
  | 'frontend'
  | 'backend'
  | 'api'
  | 'database'
  | 'infrastructure'
  | 'testing'
  | 'documentation'
  | 'design'
  | 'devops'
  | 'security'
  | 'integration';
