import type { ReviewStatus } from './epic.js';

export interface ReviewSession {
  id: string;
  previewId: string;
  reviewer: string;
  status: ReviewStatus;
  comments: ReviewThreadComment[];
  createdAt: string;
  updatedAt: string;
}

export interface ReviewThreadComment {
  id: string;
  author: string;
  timestamp: string;
  comment: string;
  targetType: 'epic' | 'story' | 'subtask';
  targetId: string;
  field?: string;
  resolved: boolean;
}

export interface GenerationRun {
  id: string;
  prdId: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  epicCount: number;
  storyCount: number;
  subTaskCount: number;
  startedAt: string;
  completedAt?: string;
  error?: string;
}
