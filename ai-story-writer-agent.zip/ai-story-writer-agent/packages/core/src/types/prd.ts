export interface PRDDocument {
  id: string;
  title: string;
  version: string;
  sourceUrl?: string;
  rawMarkdown: string;
  sections: PRDSection[];
  metadata: PRDMetadata;
}

export interface PRDSection {
  heading: string;
  level: number;
  content: string;
  subsections: PRDSection[];
}

export interface PRDMetadata {
  productArea: string;
  targetRelease?: string;
  priority: 'P0' | 'P1' | 'P2' | 'P3' | 'P4';
  stakeholders: Stakeholder[];
  technicalConstraints: string[];
  dependencies: Dependency[];
  nfrs: NonFunctionalRequirement[];
}

export interface Stakeholder {
  name: string;
  role: string;
  email?: string;
}

export interface Dependency {
  name: string;
  type: 'system' | 'team' | 'external';
  description: string;
}

export interface NonFunctionalRequirement {
  category: 'performance' | 'security' | 'scalability' | 'accessibility' | 'compliance';
  description: string;
  metric?: string;
}
