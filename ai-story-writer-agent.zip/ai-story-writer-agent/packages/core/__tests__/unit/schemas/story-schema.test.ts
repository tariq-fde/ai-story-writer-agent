import { describe, it, expect } from 'vitest';
import { storyGenerationOutputSchema, storyPointValueSchema } from '../../../src/schemas/index.js';

describe('storyPointValueSchema', () => {
  it('accepts valid Fibonacci values', () => {
    for (const v of [1, 2, 3, 5, 8, 13, 21]) {
      expect(storyPointValueSchema.parse(v)).toBe(v);
    }
  });

  it('rejects non-Fibonacci values', () => {
    for (const v of [0, 4, 6, 7, 10, 15, 22]) {
      expect(() => storyPointValueSchema.parse(v)).toThrow();
    }
  });

  it('rejects non-numbers', () => {
    expect(() => storyPointValueSchema.parse('5')).toThrow();
    expect(() => storyPointValueSchema.parse(null)).toThrow();
  });
});

describe('storyGenerationOutputSchema', () => {
  const validStory = {
    title: 'Implement login endpoint',
    userStoryStatement: {
      persona: 'end user',
      action: 'log in with email and password',
      benefit: 'I can access my account',
    },
    description: 'Create the POST /auth/login endpoint with credential validation.',
    acceptanceCriteria: [
      { id: 'AC-1', title: 'Valid login', given: 'valid credentials', when: 'user submits', then: 'JWT is returned' },
      { id: 'AC-2', title: 'Invalid login', given: 'wrong password', when: 'user submits', then: '401 is returned' },
    ],
    storyPoints: 5,
    priority: 'must-have' as const,
    labels: ['auth'],
    components: ['backend'],
    dependsOn: [],
    definitionOfDone: ['Code reviewed', 'Tests passing'],
  };

  it('accepts valid story output', () => {
    const result = storyGenerationOutputSchema.parse({ stories: [validStory] });
    expect(result.stories).toHaveLength(1);
    expect(result.stories[0].title).toBe('Implement login endpoint');
  });

  it('accepts stories with optional fields', () => {
    const withOptional = { ...validStory, technicalNotes: 'Use bcrypt', suggestedSprint: 1 };
    const result = storyGenerationOutputSchema.parse({ stories: [withOptional] });
    expect(result.stories[0].technicalNotes).toBe('Use bcrypt');
    expect(result.stories[0].suggestedSprint).toBe(1);
  });

  it('rejects stories with fewer than 2 acceptance criteria', () => {
    const tooFewAc = {
      ...validStory,
      acceptanceCriteria: [validStory.acceptanceCriteria[0]],
    };
    expect(() => storyGenerationOutputSchema.parse({ stories: [tooFewAc] })).toThrow();
  });

  it('rejects stories with empty title', () => {
    const noTitle = { ...validStory, title: '' };
    expect(() => storyGenerationOutputSchema.parse({ stories: [noTitle] })).toThrow();
  });

  it('rejects stories with short description', () => {
    const shortDesc = { ...validStory, description: 'too short' };
    expect(() => storyGenerationOutputSchema.parse({ stories: [shortDesc] })).toThrow();
  });

  it('rejects stories with invalid priority', () => {
    const badPriority = { ...validStory, priority: 'critical' };
    expect(() => storyGenerationOutputSchema.parse({ stories: [badPriority] })).toThrow();
  });

  it('rejects stories with invalid story points', () => {
    const badPoints = { ...validStory, storyPoints: 4 };
    expect(() => storyGenerationOutputSchema.parse({ stories: [badPoints] })).toThrow();
  });

  it('rejects stories with empty definitionOfDone', () => {
    const noDod = { ...validStory, definitionOfDone: [] };
    expect(() => storyGenerationOutputSchema.parse({ stories: [noDod] })).toThrow();
  });

  it('accepts empty stories array', () => {
    const result = storyGenerationOutputSchema.parse({ stories: [] });
    expect(result.stories).toHaveLength(0);
  });
});
