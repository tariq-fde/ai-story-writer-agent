import { describe, it, expect } from 'vitest';
import { validateStory, validateDependencies } from '../../../src/validators/story-validator.js';
import type { UserStory } from '../../../src/types/index.js';

function makeStory(overrides: Partial<UserStory> = {}): UserStory {
  return {
    id: 'story-1',
    epicId: 'epic-1',
    title: 'Test Story',
    userStoryStatement: { persona: 'user', action: 'do something', benefit: 'get value' },
    description: 'A test story description.',
    acceptanceCriteria: [
      { id: 'AC-1', title: 'First', given: 'state', when: 'action', then: 'result' },
      { id: 'AC-2', title: 'Second', given: 'state', when: 'action', then: 'result' },
    ],
    storyPoints: 5,
    priority: 'must-have',
    labels: [],
    components: [],
    dependsOn: [],
    subTasks: [],
    definitionOfDone: ['Code reviewed'],
    reviewStatus: 'draft',
    reviewComments: [],
    ...overrides,
  };
}

describe('validateStory', () => {
  it('returns no errors for a valid story', () => {
    const errors = validateStory(makeStory(), 13);
    expect(errors).toHaveLength(0);
  });

  it('flags empty title', () => {
    const errors = validateStory(makeStory({ title: '' }), 13);
    expect(errors.some((e) => e.field === 'title')).toBe(true);
  });

  it('flags empty persona', () => {
    const errors = validateStory(
      makeStory({ userStoryStatement: { persona: '', action: 'do', benefit: 'get' } }),
      13,
    );
    expect(errors.some((e) => e.field === 'userStoryStatement.persona')).toBe(true);
  });

  it('flags fewer than 2 acceptance criteria', () => {
    const errors = validateStory(
      makeStory({
        acceptanceCriteria: [
          { id: 'AC-1', title: 'Only one', given: 'g', when: 'w', then: 't' },
        ],
      }),
      13,
    );
    expect(errors.some((e) => e.field === 'acceptanceCriteria')).toBe(true);
  });

  it('flags non-Fibonacci story points', () => {
    const errors = validateStory(makeStory({ storyPoints: 4 as never }), 13);
    expect(errors.some((e) => e.field === 'storyPoints')).toBe(true);
  });

  it('flags story points exceeding max', () => {
    const errors = validateStory(makeStory({ storyPoints: 21 }), 13);
    expect(errors.some((e) => e.field === 'storyPoints' && e.message.includes('split'))).toBe(
      true,
    );
  });

  it('flags empty definition of done', () => {
    const errors = validateStory(makeStory({ definitionOfDone: [] }), 13);
    expect(errors.some((e) => e.field === 'definitionOfDone')).toBe(true);
  });

  it('returns multiple errors at once', () => {
    const errors = validateStory(
      makeStory({
        title: '',
        acceptanceCriteria: [],
        definitionOfDone: [],
      }),
      13,
    );
    expect(errors.length).toBeGreaterThanOrEqual(3);
  });
});

describe('validateDependencies', () => {
  it('returns no errors when dependencies exist', () => {
    const story1 = makeStory({ id: 'story-1', title: 'Story A', dependsOn: [] });
    const story2 = makeStory({
      id: 'story-2',
      title: 'Story B',
      dependsOn: ['story-1'],
    });
    const errors = validateDependencies(story2, [story1, story2]);
    expect(errors).toHaveLength(0);
  });

  it('resolves dependencies by title', () => {
    const story1 = makeStory({ id: 'story-1', title: 'Story A', dependsOn: [] });
    const story2 = makeStory({
      id: 'story-2',
      title: 'Story B',
      dependsOn: ['Story A'],
    });
    const errors = validateDependencies(story2, [story1, story2]);
    expect(errors).toHaveLength(0);
  });

  it('flags orphan dependencies', () => {
    const story = makeStory({ dependsOn: ['non-existent-id'] });
    const errors = validateDependencies(story, [story]);
    expect(errors.length).toBe(1);
    expect(errors[0].message).toContain('non-existent');
  });
});
