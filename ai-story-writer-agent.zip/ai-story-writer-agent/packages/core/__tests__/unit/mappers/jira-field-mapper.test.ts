import { describe, it, expect } from 'vitest';
import { mapEpicToJira, mapStoryToJira, mapSubTaskToJira, markdownToAdf } from '../../../src/mappers/jira-field-mapper.js';
import type { Epic, UserStory, SubTask, JiraFieldMapping } from '../../../src/types/index.js';

const testMapping: JiraFieldMapping = {
  projectKey: 'TEST',
  issueTypes: {
    epicTypeId: '10000',
    storyTypeId: '10001',
    subTaskTypeId: '10003',
  },
  standardFields: {
    storyPointsField: 'customfield_10028',
    epicLinkField: 'customfield_10014',
    epicNameField: 'customfield_10011',
    sprintField: 'customfield_10020',
    priorityMapping: {
      'must-have': '1',
      'should-have': '2',
      'could-have': '3',
      'wont-have': '4',
    },
  },
  customFields: [
    {
      internalField: 'businessValue',
      jiraFieldId: 'customfield_10050',
      displayName: 'Business Value',
      transform: 'identity',
    },
  ],
  boardConfig: {
    boardId: '1',
    sprintDurationWeeks: 2,
    teamVelocity: 40,
  },
};

const testEpic: Epic = {
  id: 'epic-1',
  prdId: 'prd-1',
  title: 'Authentication',
  description: 'Implement authentication system',
  businessValue: 'Enables secure user access',
  acceptanceCriteria: ['Users can log in', 'Users can log out'],
  estimate: { size: 'L', totalStoryPoints: 21, estimatedSprintCount: 1 },
  priority: 1,
  labels: ['auth'],
  components: ['backend'],
  stories: [],
  reviewStatus: 'draft',
};

const testStory: UserStory = {
  id: 'story-1',
  epicId: 'epic-1',
  title: 'Login endpoint',
  userStoryStatement: { persona: 'user', action: 'log in', benefit: 'access the app' },
  description: 'Create login endpoint with password validation.',
  acceptanceCriteria: [
    { id: 'AC-1', title: 'Valid login', given: 'valid creds', when: 'submit', then: 'JWT returned' },
    { id: 'AC-2', title: 'Invalid login', given: 'bad creds', when: 'submit', then: '401 returned' },
  ],
  storyPoints: 5,
  priority: 'must-have',
  labels: ['auth'],
  components: ['backend'],
  dependsOn: [],
  subTasks: [],
  definitionOfDone: ['Code reviewed', 'Tests passing'],
  reviewStatus: 'draft',
  reviewComments: [],
};

const testSubTask: SubTask = {
  id: 'st-1',
  storyId: 'story-1',
  title: 'Write unit tests for login',
  description: 'Cover valid and invalid credential scenarios in unit tests.',
  estimatedHours: 3,
  category: 'testing',
  labels: ['testing'],
  component: 'backend',
};

describe('mapEpicToJira', () => {
  it('maps epic to JIRA payload with correct project and issue type', () => {
    const payload = mapEpicToJira(testEpic, testMapping);
    expect(payload.fields.project.key).toBe('TEST');
    expect(payload.fields.issuetype.id).toBe('10000');
    expect(payload.fields.summary).toBe('Authentication');
  });

  it('includes epic name custom field', () => {
    const payload = mapEpicToJira(testEpic, testMapping);
    expect(payload.fields['customfield_10011']).toBe('Authentication');
  });

  it('produces a valid ADF description', () => {
    const payload = mapEpicToJira(testEpic, testMapping);
    expect(payload.fields.description.type).toBe('doc');
    expect(payload.fields.description.version).toBe(1);
    expect(payload.fields.description.content.length).toBeGreaterThan(0);
  });

  it('applies custom field mappings', () => {
    const epicWithBizValue = { ...testEpic } as unknown as Record<string, unknown>;
    epicWithBizValue['businessValue'] = 'Enables secure user access';
    const payload = mapEpicToJira(epicWithBizValue as unknown as Epic, testMapping);
    expect(payload.fields['customfield_10050']).toBe('Enables secure user access');
  });
});

describe('mapStoryToJira', () => {
  it('maps story with epic link and story points', () => {
    const payload = mapStoryToJira(testStory, 'TEST-1', testMapping);
    expect(payload.fields.project.key).toBe('TEST');
    expect(payload.fields.issuetype.id).toBe('10001');
    expect(payload.fields.summary).toBe('Login endpoint');
    expect(payload.fields['customfield_10014']).toBe('TEST-1');
    expect(payload.fields['customfield_10028']).toBe(5);
  });

  it('maps priority correctly', () => {
    const payload = mapStoryToJira(testStory, 'TEST-1', testMapping);
    expect(payload.fields.priority).toEqual({ id: '1' });
  });

  it('includes labels and components', () => {
    const payload = mapStoryToJira(testStory, 'TEST-1', testMapping);
    expect(payload.fields.labels).toEqual(['auth']);
    expect(payload.fields.components).toEqual([{ name: 'backend' }]);
  });
});

describe('mapSubTaskToJira', () => {
  it('maps sub-task with parent reference', () => {
    const payload = mapSubTaskToJira(testSubTask, 'TEST-2', testMapping);
    expect(payload.fields.project.key).toBe('TEST');
    expect(payload.fields.issuetype.id).toBe('10003');
    expect(payload.fields.summary).toBe('Write unit tests for login');
    expect((payload.fields as Record<string, unknown>)['parent']).toEqual({ key: 'TEST-2' });
  });
});

describe('markdownToAdf', () => {
  it('converts headings', () => {
    const adf = markdownToAdf('## Hello World');
    const heading = adf.content.find((n) => n.type === 'heading');
    expect(heading).toBeDefined();
    expect(heading!.attrs!['level']).toBe(2);
    expect(heading!.content![0].text).toBe('Hello World');
  });

  it('converts bullet lists', () => {
    const adf = markdownToAdf('- Item one\n- Item two');
    const bullets = adf.content.filter((n) => n.type === 'bulletList');
    expect(bullets.length).toBe(2);
  });

  it('converts bold text', () => {
    const adf = markdownToAdf('This is **bold** text');
    const paragraph = adf.content.find((n) => n.type === 'paragraph');
    expect(paragraph).toBeDefined();
    const boldNode = paragraph!.content!.find(
      (n) => n.marks && n.marks.some((m) => m.type === 'strong'),
    );
    expect(boldNode).toBeDefined();
    expect(boldNode!.text).toBe('bold');
  });

  it('returns valid ADF structure', () => {
    const adf = markdownToAdf('Simple paragraph');
    expect(adf.type).toBe('doc');
    expect(adf.version).toBe(1);
    expect(Array.isArray(adf.content)).toBe(true);
  });
});
