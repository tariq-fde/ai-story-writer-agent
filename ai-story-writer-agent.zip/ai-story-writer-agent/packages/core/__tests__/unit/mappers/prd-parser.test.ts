import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { parsePrdMarkdown } from '../../../src/mappers/prd-parser.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const fixturesDir = join(__dirname, '..', '..', 'fixtures');

describe('parsePrdMarkdown', () => {
  it('parses the sample PRD with frontmatter', () => {
    const markdown = readFileSync(join(fixturesDir, 'sample-prd.md'), 'utf-8');
    const prd = parsePrdMarkdown(markdown);

    expect(prd.title).toBe('User Authentication System');
    expect(prd.version).toBe('1.0.0');
    expect(prd.metadata.productArea).toBe('Identity & Access Management');
    expect(prd.metadata.priority).toBe('P1');
    expect(prd.metadata.targetRelease).toBe('Q1 2027');
    expect(prd.sections.length).toBeGreaterThan(0);
  });

  it('extracts technical constraints from sections', () => {
    const markdown = readFileSync(join(fixturesDir, 'sample-prd.md'), 'utf-8');
    const prd = parsePrdMarkdown(markdown);

    expect(prd.metadata.technicalConstraints.length).toBeGreaterThan(0);
    expect(prd.metadata.technicalConstraints).toContain(
      'Must use existing PostgreSQL user database',
    );
  });

  it('extracts dependencies from sections', () => {
    const markdown = readFileSync(join(fixturesDir, 'sample-prd.md'), 'utf-8');
    const prd = parsePrdMarkdown(markdown);

    expect(prd.metadata.dependencies.length).toBe(3);
  });

  it('extracts stakeholders from sections', () => {
    const markdown = readFileSync(join(fixturesDir, 'sample-prd.md'), 'utf-8');
    const prd = parsePrdMarkdown(markdown);

    expect(prd.metadata.stakeholders.length).toBe(3);
  });

  it('parses markdown without frontmatter', () => {
    const markdown = `# My Feature

## Overview
This is a simple feature.

## Technical Constraints
- Must use REST API
- Must support pagination
`;
    const prd = parsePrdMarkdown(markdown);

    expect(prd.title).toBe('My Feature');
    expect(prd.version).toBe('1.0.0');
    expect(prd.metadata.productArea).toBe('General');
    expect(prd.metadata.technicalConstraints).toContain('Must use REST API');
    expect(prd.metadata.technicalConstraints).toContain('Must support pagination');
  });

  it('uses overrides for id and sourceUrl', () => {
    const markdown = '# Test\n\nContent here.';
    const prd = parsePrdMarkdown(markdown, {
      id: 'custom-id',
      sourceUrl: 'https://confluence.example.com/page/123',
    });

    expect(prd.id).toBe('custom-id');
    expect(prd.sourceUrl).toBe('https://confluence.example.com/page/123');
  });

  it('handles empty markdown gracefully', () => {
    const prd = parsePrdMarkdown('');
    expect(prd.title).toBe('Untitled PRD');
    expect(prd.metadata.productArea).toBe('General');
  });

  it('builds nested section tree', () => {
    const markdown = `# Top Level

## Section A
Content A

### Sub-Section A1
Content A1

## Section B
Content B
`;
    const prd = parsePrdMarkdown(markdown);
    const topSections = prd.sections;

    expect(topSections.length).toBe(1);
    expect(topSections[0].heading).toBe('Top Level');
    expect(topSections[0].subsections.length).toBe(2);
    expect(topSections[0].subsections[0].heading).toBe('Section A');
    expect(topSections[0].subsections[0].subsections.length).toBe(1);
    expect(topSections[0].subsections[0].subsections[0].heading).toBe('Sub-Section A1');
    expect(topSections[0].subsections[1].heading).toBe('Section B');
  });
});
