---
name: hybrid-story-writer
description: >
  Hybrid AI Story Writer — uses the shared core library for story generation.
  Supports both interactive skill mode and headless Cloud Run service mode.
when_to_use: >
  When using the hybrid deployment of the Story Writer agent that shares
  core logic between Claude Code and Cloud Run contexts.
allowed-tools:
  - mcp__jira__create_issue
  - mcp__jira__search_issues
  - mcp__jira__get_issue
  - mcp__confluence__get_page
  - mcp__confluence__search
  - mcp__github__search_code
  - mcp__github__get_file_contents
  - Bash(npm run *)
  - Read
  - Write
model: claude-sonnet-4-5-20250514
effort: high
---

# Hybrid Story Writer

This skill delegates to the shared core engine at `packages/core` via the hybrid adapter at `packages/hybrid/src/adapters/skill-adapter.ts`.

Follow the same workflow as the primary story-writer skill:
1. Load and parse the PRD
2. Decompose into Epics
3. Generate User Stories per Epic
4. Generate Sub-Tasks per Story
5. Present preview for PO review
6. Push to JIRA after approval

The hybrid adapter provides `SkillAdapter.generateFromFile()` and `SkillAdapter.generateFromMarkdown()` for the generation step.
