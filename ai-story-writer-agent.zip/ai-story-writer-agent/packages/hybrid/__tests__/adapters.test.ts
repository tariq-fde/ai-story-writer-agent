import { describe, it, expect } from 'vitest';
import { SharedStoryAgent } from '../src/shared-agent.js';
import type { OrgConfig } from '@ai-story-writer/core';

const mockOrgConfig: OrgConfig = {
  orgId: 'test-org',
  orgName: 'Test Organization',
  jira: {
    projectKey: 'TEST',
    issueTypes: { epicTypeId: '10000', storyTypeId: '10001', subTaskTypeId: '10003' },
    standardFields: {
      storyPointsField: 'customfield_10028',
      epicLinkField: 'customfield_10014',
      epicNameField: 'customfield_10011',
      sprintField: 'customfield_10020',
      priorityMapping: { 'must-have': '1', 'should-have': '2' },
    },
    customFields: [],
    boardConfig: { boardId: '1', sprintDurationWeeks: 2, teamVelocity: 40 },
  },
  storyDefaults: {
    defaultLabels: ['ai-generated'],
    defaultComponents: [],
    definitionOfDoneTemplate: ['Code reviewed', 'Tests passing'],
    subTaskTemplates: {},
    estimationScale: 'fibonacci',
    maxStoryPoints: 13,
  },
  workflow: {
    requireApproval: true,
    autoAssignSprint: false,
    notifications: {},
  },
};

describe('SharedStoryAgent', () => {
  it('parses a PRD title from markdown', async () => {
    const agent = new SharedStoryAgent(mockOrgConfig);
    const result = await agent.generate('# My Feature PRD\n\nSome content here.');
    expect(result.prd.title).toBe('My Feature PRD');
  });

  it('falls back to Untitled PRD when no heading is found', async () => {
    const agent = new SharedStoryAgent(mockOrgConfig);
    const result = await agent.generate('No heading here, just content.');
    expect(result.prd.title).toBe('Untitled PRD');
  });

  it('returns empty epics array as scaffold', async () => {
    const agent = new SharedStoryAgent(mockOrgConfig);
    const result = await agent.generate('# Test PRD');
    expect(result.epics).toEqual([]);
  });

  it('exposes org config', () => {
    const agent = new SharedStoryAgent(mockOrgConfig);
    expect(agent.getOrgConfig().orgId).toBe('test-org');
  });
});
