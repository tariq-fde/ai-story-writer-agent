import type { PRDDocument, Epic, OrgConfig } from '@ai-story-writer/core';

/**
 * Shared agent logic that works in both Claude Code skill and Cloud Run contexts.
 *
 * The core generation workflow is identical regardless of runtime:
 * 1. Parse the PRD markdown into a structured PRDDocument
 * 2. Decompose into Epics (via LLM or skill prompt chain)
 * 3. Generate Stories per Epic
 * 4. Generate Sub-Tasks per Story
 * 5. Validate output against Zod schemas
 *
 * The difference between skill and service contexts is in how LLM calls are made:
 * - Skill: Claude Code makes the calls via its own context (SKILL.md instructions)
 * - Service: The Anthropic SDK makes direct API calls
 *
 * This class provides the shared parsing, validation, and orchestration logic.
 */
export class SharedStoryAgent {
  private orgConfig: OrgConfig;

  constructor(orgConfig: OrgConfig) {
    this.orgConfig = orgConfig;
  }

  async generate(rawMarkdown: string): Promise<{ prd: PRDDocument; epics: Epic[] }> {
    const prd = this.parsePrd(rawMarkdown);

    // Epic/story generation is delegated to the adapter-specific LLM integration.
    // This placeholder returns the parsed PRD with empty epics for the adapter to fill.
    const epics: Epic[] = [];

    return { prd, epics };
  }

  private parsePrd(rawMarkdown: string): PRDDocument {
    const title = this.extractTitle(rawMarkdown);

    return {
      id: crypto.randomUUID(),
      title,
      version: '1.0.0',
      rawMarkdown,
      sections: [],
      metadata: {
        productArea: '',
        priority: 'P2',
        stakeholders: [],
        technicalConstraints: [],
        dependencies: [],
        nfrs: [],
      },
    };
  }

  private extractTitle(markdown: string): string {
    const match = markdown.match(/^#\s+(.+)$/m);
    return match?.[1]?.trim() ?? 'Untitled PRD';
  }

  getOrgConfig(): OrgConfig {
    return this.orgConfig;
  }
}
