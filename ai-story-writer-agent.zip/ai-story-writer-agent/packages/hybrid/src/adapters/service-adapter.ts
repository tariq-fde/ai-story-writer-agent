import express, { type Express, type Request, type Response } from 'express';
import type { OrgConfig } from '@ai-story-writer/core';
import { orgConfigSchema } from '@ai-story-writer/core';
import { SharedStoryAgent } from '../shared-agent.js';

export class ServiceAdapter {
  private app: Express;
  private agent: SharedStoryAgent;

  constructor(orgConfig: OrgConfig) {
    this.agent = new SharedStoryAgent(orgConfig);
    this.app = express();
    this.app.use(express.json({ limit: '5mb' }));
    this.setupRoutes();
  }

  private setupRoutes(): void {
    this.app.get('/health', (_req: Request, res: Response) => {
      res.json({ status: 'ok', service: 'hybrid-story-writer' });
    });

    this.app.post('/api/v1/stories/generate', async (req: Request, res: Response) => {
      try {
        const { markdown } = req.body as { markdown: string };
        if (!markdown) {
          res.status(400).json({ error: 'markdown field is required' });
          return;
        }
        const result = await this.agent.generate(markdown);
        res.json(result);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Internal error';
        res.status(500).json({ error: message });
      }
    });
  }

  getApp(): Express {
    return this.app;
  }

  listen(port: number): void {
    this.app.listen(port, () => {
      console.log(`Hybrid story writer service listening on port ${port}`);
    });
  }
}
