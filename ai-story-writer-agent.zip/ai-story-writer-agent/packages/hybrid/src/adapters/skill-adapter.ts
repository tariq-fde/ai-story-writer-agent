import { readFileSync } from 'node:fs';
import type { PRDDocument, Epic, OrgConfig } from '@ai-story-writer/core';
import { orgConfigSchema } from '@ai-story-writer/core';
import { SharedStoryAgent } from '../shared-agent.js';

export class SkillAdapter {
  private agent: SharedStoryAgent;
  private orgConfig: OrgConfig;

  constructor(orgConfigPath: string) {
    const raw = readFileSync(orgConfigPath, 'utf-8');
    this.orgConfig = orgConfigSchema.parse(JSON.parse(raw));
    this.agent = new SharedStoryAgent(this.orgConfig);
  }

  async generateFromFile(prdPath: string): Promise<{ prd: PRDDocument; epics: Epic[] }> {
    const rawMarkdown = readFileSync(prdPath, 'utf-8');
    return this.agent.generate(rawMarkdown);
  }

  async generateFromMarkdown(markdown: string): Promise<{ prd: PRDDocument; epics: Epic[] }> {
    return this.agent.generate(markdown);
  }

  getOrgConfig(): OrgConfig {
    return this.orgConfig;
  }
}
