# Using the Story Writer Skill

## Prerequisites

1. Claude Code installed and configured
2. JIRA, Confluence, and GitHub MCP servers configured (see `.mcp.json`)
3. API tokens set in Claude Code environment

## Available Commands

### `/story-writer <prd-path>`

Main skill. Generates JIRA-ready epics, stories, and sub-tasks from a PRD.

**Workflow:**
1. Reads and parses the PRD file
2. Decomposes the PRD into 2–6 Epics
3. Generates 3–8 User Stories per Epic
4. Generates 3–7 Sub-Tasks per Story
5. Presents a structured Markdown preview
6. Waits for PO approval before JIRA push

**Example:**
```
/story-writer docs/prds/user-auth-prd.md
```

The skill also accepts Confluence page URLs:
```
/story-writer https://your-instance.atlassian.net/wiki/spaces/PROJ/pages/12345
```

### `/review-stories [preview-path]`

Review a previously generated story set against the quality checklist.

### `/push-to-jira [--dry-run]`

Push approved stories to JIRA. Use `--dry-run` to preview what would be created.

## Configuration

The skill uses `config/org/default.json` for organization-specific settings. Key options:

- **Team velocity**: controls sprint assignment suggestions
- **Max story points**: stories exceeding this are flagged for splitting
- **Definition of Done template**: default checklist items for all stories
- **Prompt overrides**: customize the generation prompts for your org

## Tips

- Provide detailed PRDs for better story quality — the more context, the better the decomposition
- Review and adjust story points; the AI estimates are starting points
- Use the review workflow to iterate before pushing to JIRA
- Custom field mappings in `config/jira/field-mappings.json` must match your JIRA instance
