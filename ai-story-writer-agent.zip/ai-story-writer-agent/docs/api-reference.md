# REST API Reference

Base URL: `https://<cloud-run-service-url>/api/v1`

All endpoints require GCP IAM authentication (Bearer token).

---

## Health Check

```
GET /health
```

**Response:** `200 OK`
```json
{
  "status": "ok",
  "service": "story-writer-service",
  "version": "1.0.0"
}
```

---

## Generate Stories

```
POST /api/v1/stories/generate
```

Accepts a PRD and generates epics, stories, and sub-tasks.

**Request Body:**
```json
{
  "markdown": "# PRD Title\n\n## Overview\n...",
  "orgConfigId": "default",
  "options": {
    "maxEpics": 6,
    "maxStoriesPerEpic": 8,
    "includeSubTasks": true
  }
}
```

**Response:** `202 Accepted`
```json
{
  "runId": "run_abc123",
  "status": "in_progress",
  "previewUrl": "/api/v1/reviews/run_abc123"
}
```

---

## Get Review / Preview

```
GET /api/v1/reviews/:runId
```

Returns the generated stories for review.

**Response:** `200 OK`
```json
{
  "runId": "run_abc123",
  "status": "ready_for_review",
  "prd": { "id": "...", "title": "..." },
  "epics": [
    {
      "id": "epic_1",
      "title": "...",
      "stories": [...]
    }
  ],
  "stats": {
    "epicCount": 3,
    "storyCount": 12,
    "subTaskCount": 45,
    "totalStoryPoints": 89,
    "estimatedSprints": 3
  }
}
```

---

## Submit Review Decisions

```
PUT /api/v1/reviews/:runId
```

**Request Body:**
```json
{
  "decisions": [
    { "epicId": "epic_1", "status": "approved" },
    { "epicId": "epic_2", "storyId": "story_5", "status": "revision_requested", "comment": "Split this into two stories" }
  ]
}
```

**Response:** `200 OK`
```json
{
  "approved": 2,
  "rejected": 0,
  "needsRevision": 1,
  "allApproved": false
}
```

---

## Push to JIRA

```
POST /api/v1/jira/push
```

Pushes approved stories to JIRA. Only items with `approved` status are pushed.

**Request Body:**
```json
{
  "runId": "run_abc123",
  "dryRun": false
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "created": [
    { "internalId": "epic_1", "jiraKey": "PROJ-100", "issueType": "epic" },
    { "internalId": "story_1", "jiraKey": "PROJ-101", "issueType": "story" }
  ],
  "errors": []
}
```

---

## Webhooks (Pub/Sub Push)

```
POST /api/v1/webhooks
```

Receives Pub/Sub push messages for async processing.

**Events:**
- `story-writer.story-approved` — triggers JIRA push for approved stories
