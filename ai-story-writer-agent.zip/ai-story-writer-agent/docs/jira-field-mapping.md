# JIRA Field Mapping Guide

## Overview

Each JIRA instance has unique custom field IDs. The Story Writer Agent uses a configurable mapping to translate its internal data model into the correct JIRA API payloads.

## Configuration File

Field mappings are defined in the org config at `config/org/<your-org>.json` under the `jira` key.

## Discovering Your Field IDs

### Via JIRA REST API

```bash
# List all fields (requires JIRA admin or project admin)
curl -u email:token https://your-instance.atlassian.net/rest/api/3/field | jq '.[] | {id, name, custom}'
```

### Via JIRA MCP

```
mcp__jira__get_project { projectKey: "YOUR_PROJECT" }
```

### Common Field Mappings

| Field | Typical JIRA ID | Notes |
|-------|----------------|-------|
| Story Points | `customfield_10028` | Varies by instance; check Agile board config |
| Epic Link | `customfield_10014` | Links stories to epics |
| Epic Name | `customfield_10011` | Display name for the epic |
| Sprint | `customfield_10020` | Sprint assignment |

## Mapping Structure

```json
{
  "jira": {
    "projectKey": "PROJ",
    "issueTypes": {
      "epicTypeId": "10000",
      "storyTypeId": "10001",
      "subTaskTypeId": "10003"
    },
    "standardFields": {
      "storyPointsField": "customfield_10028",
      "epicLinkField": "customfield_10014",
      "epicNameField": "customfield_10011",
      "sprintField": "customfield_10020",
      "priorityMapping": {
        "must-have": "1",
        "should-have": "2",
        "could-have": "3",
        "wont-have": "4"
      }
    },
    "customFields": [
      {
        "internalField": "businessValue",
        "jiraFieldId": "customfield_10050",
        "displayName": "Business Value",
        "transform": "identity"
      }
    ]
  }
}
```

## Custom Field Transforms

| Transform | Behavior |
|-----------|----------|
| `identity` | Pass the value as-is |
| `join_array` | Join array values with commas |
| `map_value` | Map internal values to JIRA values using `valueMap` |
| `format_date` | Format dates to JIRA's expected format |

## Priority Mapping

JIRA priority IDs vary by instance. Query your priorities:

```bash
curl -u email:token https://your-instance.atlassian.net/rest/api/3/priority | jq '.[] | {id, name}'
```

Map internal priorities (must-have, should-have, could-have, wont-have) to your JIRA priority IDs in `standardFields.priorityMapping`.

## Issue Type IDs

Query your project's issue types:

```bash
curl -u email:token https://your-instance.atlassian.net/rest/api/3/issuetype | jq '.[] | {id, name, subtask}'
```

Set `epicTypeId`, `storyTypeId`, and `subTaskTypeId` accordingly.
