# Developer Setup

## Prerequisites

- Node.js 22+ (use `nvm use` to match `.nvmrc`)
- npm 10+
- Docker (for building service/hybrid images)
- Pulumi CLI (for infrastructure deployment)
- GCP CLI (`gcloud`) authenticated to the target project

## Getting Started

```bash
# Clone the repository
git clone <repo-url>
cd ai-story-writer-agent

# Install dependencies (all workspaces)
npm install

# Build all packages
npm run build

# Run all tests
npm test

# Type-check
npm run typecheck

# Lint
npm run lint
```

## Environment Variables

Create a `.env` file in the project root (never committed):

```bash
# Required for the service package
ANTHROPIC_API_KEY=sk-ant-...

# Required for JIRA integration
JIRA_BASE_URL=https://your-instance.atlassian.net
JIRA_API_TOKEN=your-jira-pat
JIRA_USER_EMAIL=your-email@company.com

# Required for Confluence integration
CONFLUENCE_BASE_URL=https://your-instance.atlassian.net/wiki
CONFLUENCE_API_TOKEN=your-confluence-pat

# Required for GitHub integration (no local cloning)
GITHUB_PAT=ghp_...

# Optional: org config override
ORG_CONFIG_PATH=config/org/your-org.json
```

## MCP Configuration

For the Claude Code skill, MCP servers are configured in `.mcp.json`. Set your tokens in the Claude Code environment:

1. Open Claude Code settings
2. Add environment variables for `JIRA_API_TOKEN`, `CONFLUENCE_API_TOKEN`, `GITHUB_PAT`
3. The `.mcp.json` file references these via `${VAR_NAME}` syntax

## Running Individual Packages

```bash
# Core package only
npm run test --workspace=@ai-story-writer/core

# Service package (development mode)
npm run dev --workspace=@ai-story-writer/service

# Hybrid package (development mode)
npm run dev --workspace=@ai-story-writer/hybrid
```

## Using the Claude Code Skill

1. Open Claude Code in this project directory
2. Run `/story-writer path/to/your-prd.md`
3. Follow the interactive workflow

## Docker Builds

```bash
# Build service image
docker build -f packages/service/Dockerfile -t story-writer-service .

# Build hybrid image
docker build -f packages/hybrid/Dockerfile -t story-writer-hybrid .

# Run locally
docker run -p 8080:8080 --env-file .env story-writer-service
```

## Infrastructure Deployment

```bash
cd infra/pulumi

# Install Pulumi dependencies
npm install

# Select a stack
pulumi stack select dev

# Preview changes
pulumi preview

# Deploy
pulumi up
```
