# Prompt Engineering Guide

## Template System

The Story Writer uses Handlebars templates in `packages/core/src/prompts/templates/` with corresponding TypeScript builder functions in the parent directory.

## Template Hierarchy

1. **System prompt** (`system.hbs`) — sets the persona, output standards, and org-specific context. Sent as the `system` parameter on every LLM call.

2. **Epic generation** (`epic.hbs`) — decomposes a PRD into 2–6 epics. Runs once per PRD.

3. **Story generation** (`story.hbs`) — generates 3–8 stories per epic. Runs once per epic (parallelizable).

4. **Sub-task generation** (`subtask.hbs`) — breaks stories into implementation tasks. Runs once per story (parallelizable).

5. **Refinement** (`refinement.hbs`) — revises specific stories based on PO feedback. Runs per revision request.

6. **Estimation** (`estimation.hbs`) — validates or adjusts story point estimates. Optional pass.

## Customizing Prompts

### Via Org Config

The simplest customization is through `config.promptOverrides`:

```json
{
  "promptOverrides": {
    "systemPromptAddendum": "All stories must include a security review sub-task.",
    "terminology": {
      "sprint": "iteration",
      "story points": "complexity points"
    },
    "exampleStories": [...]
  }
}
```

- `systemPromptAddendum`: appended to the system prompt for every call
- `terminology`: search-and-replace for org-specific terms
- `exampleStories`: added as few-shot examples in the story generation prompt

### Via Template Modification

For deeper changes, modify the `.hbs` templates directly. Key principles:

1. **Structured JSON output**: all templates request JSON matching Zod schemas. Keep the schema reference in the prompt to ensure conformance.

2. **Context windowing**: for large PRDs, the story generation prompt includes the full PRD as `<prd_context>` reference. If PRDs exceed context limits, the engine chunks by section.

3. **Validation loop**: the engine validates every LLM response against the schema and retries up to 3 times, including the validation error in the retry prompt.

## Output Quality Tips

- **Few-shot examples** significantly improve output consistency. Add 2–3 representative stories to `exampleStories` in the org config.

- **Terminology mapping** prevents the LLM from using generic terms your org doesn't use.

- **Max story points constraint** in the system prompt triggers automatic splitting when stories are too large.

- **Definition of Done template** ensures consistent quality criteria across all generated stories.

## Prompt Builder API

Each template has a TypeScript builder:

```typescript
import { buildStoryPrompt } from '@ai-story-writer/core';

const prompt = buildStoryPrompt({
  epic: myEpic,
  prd: myPrd,
  orgConfig: myOrgConfig,
  maxPoints: 13,
  velocity: 40,
});
```

Builders handle Handlebars compilation, context injection, and optional section inclusion based on the provided data.
