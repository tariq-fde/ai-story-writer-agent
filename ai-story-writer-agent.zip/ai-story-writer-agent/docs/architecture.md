# Architecture

## Agent Pipeline

```
PRD Agent ──> Discovery Agent ──> AI Story Writer Agent ──> JIRA
  (input)    (refine + enrich)   (decompose + generate)   (output)
```

The **AI Story Writer Agent** is the third stage. It receives refined PRDs (Markdown) from the Discovery Agent and produces JIRA-ready Scrum artifacts.

## Three Implementations

This monorepo contains three implementation approaches sharing a common core:

### 1. Claude Code Skill (`packages/skill`)

Runs inside Claude Code as an interactive skill. The PO invokes `/story-writer <prd-path>` and Claude drives the multi-step generation workflow, using MCP servers for JIRA, Confluence, and GitHub integration.

**Best for:** Interactive use by POs, ad-hoc story generation, iterative refinement with human-in-the-loop.

### 2. Standalone Service (`packages/service`)

A Node.js/Express service using the Anthropic SDK directly. Deployable to GCP Cloud Run with Firestore persistence and Pub/Sub event publishing.

**Best for:** API-driven automation, CI/CD integration, batch processing, webhook-triggered generation.

### 3. Hybrid (`packages/hybrid`)

Thin adapter layer over the shared core library. Supports both interactive (skill) and headless (service) contexts from a single codebase.

**Best for:** Teams that want one codebase serving both use cases.

## Package Dependency Graph

```
packages/core        (zod, handlebars, pino — no internal deps)
    ↑
    ├── packages/skill    (core)
    ├── packages/service  (core, @anthropic-ai/sdk, express, @google-cloud/*)
    └── packages/hybrid   (core, @anthropic-ai/sdk, express, @google-cloud/firestore)
```

## Data Flow

```
 PRD (Markdown)
      │
      ▼
 ┌─────────────┐
 │  PRD Parser  │  packages/core/src/mappers/prd-parser.ts
 └──────┬──────┘
        │ PRDDocument
        ▼
 ┌─────────────┐
 │  Decomposer │  Prompt: epic-generation → LLM → epicGenerationOutputSchema
 └──────┬──────┘
        │ Epic[]
        ▼
 ┌─────────────┐
 │  Generator  │  Prompt: story-generation → LLM → storyGenerationOutputSchema
 └──────┬──────┘  (per epic, parallelizable)
        │ UserStory[]
        ▼
 ┌─────────────┐
 │  Sub-Tasker  │  Prompt: subtask-generation → LLM → subtaskGenerationOutputSchema
 └──────┬──────┘  (per story, parallelizable)
        │ SubTask[]
        ▼
 ┌─────────────┐
 │  Validator   │  Zod schema validation + business rules
 └──────┬──────┘
        │
        ▼
 ┌─────────────┐
 │   Preview   │  Markdown preview for PO review
 └──────┬──────┘
        │ PO approves
        ▼
 ┌─────────────┐
 │ JIRA Mapper │  Internal model → JiraCreateIssuePayload (with ADF)
 └──────┬──────┘
        │
        ▼
 ┌─────────────┐
 │  JIRA Push  │  MCP (skill) or REST API (service)
 └─────────────┘
```

## GCP Deployment

```
                    GitHub Actions CI/CD
                           │
              ┌────────────┼────────────┐
              ▼            ▼            ▼
        Artifact      Cloud Run     Cloud Run
        Registry      (service)     (hybrid)
                          │            │
                    ┌─────┴────────────┘
                    ▼
              ┌──────────┐  ┌───────────────┐  ┌─────────┐
              │ Firestore │  │Secret Manager │  │ Pub/Sub │
              └──────────┘  └───────────────┘  └─────────┘
```

- **Cloud Run**: Auto-scaling 0–10 instances, 512MiB, 300s timeout, IAM auth
- **Firestore**: Stores PRDs, generation runs, previews, review sessions
- **Secret Manager**: API tokens (Anthropic, JIRA, Confluence, GitHub)
- **Pub/Sub**: Event topics for story-generated, story-approved, jira-pushed
- **Artifact Registry**: Docker images with 10-version retention

## Configuration

Organization-specific configuration lives in `config/org/`. It controls:
- JIRA project key, issue types, and custom field mappings
- Story defaults (labels, components, DoD template, estimation scale)
- Prompt overrides (additional system context, terminology, example stories)
- Workflow settings (approval requirements, sprint auto-assignment, notifications)

See `docs/jira-field-mapping.md` for details on configuring JIRA field mappings.
