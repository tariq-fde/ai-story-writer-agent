## Summary

<!-- 1-3 bullet points describing the change -->

-

## Changes

<!-- What was changed and why -->

### Packages affected
- [ ] `packages/core`
- [ ] `packages/skill`
- [ ] `packages/service`
- [ ] `packages/hybrid`
- [ ] `infra/`
- [ ] `.claude/skills/`
- [ ] `config/`

## Testing

<!-- How was this tested? -->

- [ ] Unit tests added/updated
- [ ] Integration tests added/updated
- [ ] Manual testing performed
- [ ] Skill tested in Claude Code

## Checklist

- [ ] TypeScript compiles without errors (`npm run typecheck`)
- [ ] All tests pass (`npm test`)
- [ ] Linting passes (`npm run lint`)
- [ ] JIRA field mappings validated (if applicable)
- [ ] Prompt templates reviewed for quality (if applicable)
- [ ] Documentation updated (if applicable)
- [ ] No secrets or API tokens in code
