import * as pulumi from '@pulumi/pulumi';
import { createServiceAccount, createIamBindings } from './src/iam.js';
import { createArtifactRegistry } from './src/artifact-registry.js';
import { createSecrets } from './src/secrets.js';
import { createFirestore } from './src/firestore.js';
import { createPubSubTopics } from './src/pubsub.js';
import { createCloudRunService } from './src/cloud-run.js';

const config = new pulumi.Config('ai-story-writer');
const environment = config.require('environment');

const serviceAccount = createServiceAccount(environment);
const registry = createArtifactRegistry(environment);
const secrets = createSecrets(environment, serviceAccount);
const firestore = createFirestore(environment);
const pubsub = createPubSubTopics(environment);

createIamBindings(environment, serviceAccount);

const cloudRun = createCloudRunService(environment, {
  serviceAccount,
  registry,
  secrets,
  firestore,
  pubsub,
});

export const serviceUrl = cloudRun.serviceUrl;
export const registryUrl = registry.repositoryUrl;
export const firestoreDb = firestore.databaseName;
