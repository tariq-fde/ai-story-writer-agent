import * as gcp from '@pulumi/gcp';

export function createSecrets(
  environment: string,
  serviceAccount: gcp.serviceaccount.Account,
) {
  const secretNames = ['anthropic-key', 'jira-token', 'confluence-token', 'github-pat'];
  const secrets: Record<string, gcp.secretmanager.Secret> = {};

  for (const name of secretNames) {
    const secret = new gcp.secretmanager.Secret(`${name}-${environment}`, {
      secretId: `story-writer-${name}-${environment}`,
      replication: {
        auto: {},
      },
    });

    new gcp.secretmanager.SecretIamMember(`${name}-access-${environment}`, {
      secretId: secret.secretId,
      role: 'roles/secretmanager.secretAccessor',
      member: serviceAccount.email.apply((email) => `serviceAccount:${email}`),
    });

    secrets[name] = secret;
  }

  return secrets;
}
