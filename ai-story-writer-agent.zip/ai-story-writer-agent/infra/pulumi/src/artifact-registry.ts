import * as gcp from '@pulumi/gcp';
import * as pulumi from '@pulumi/pulumi';

export function createArtifactRegistry(environment: string) {
  const repository = new gcp.artifactregistry.Repository(`story-writer-repo-${environment}`, {
    repositoryId: `story-writer-${environment}`,
    format: 'DOCKER',
    location: gcp.config.region!,
    description: `Container images for AI Story Writer (${environment})`,
    cleanupPolicies: [
      {
        id: 'keep-recent',
        action: 'KEEP',
        mostRecentVersions: {
          keepCount: 10,
        },
      },
    ],
  });

  const repositoryUrl = pulumi.interpolate`${gcp.config.region}-docker.pkg.dev/${gcp.config.project}/${repository.repositoryId}`;

  return { repository, repositoryUrl };
}
