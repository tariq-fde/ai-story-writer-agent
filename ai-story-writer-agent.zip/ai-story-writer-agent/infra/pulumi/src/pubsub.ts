import * as gcp from '@pulumi/gcp';

export function createPubSubTopics(environment: string) {
  const storyGenerated = new gcp.pubsub.Topic(`story-generated-${environment}`, {
    name: `story-writer.story-generated.${environment}`,
    messageRetentionDuration: '86400s',
  });

  const storyApproved = new gcp.pubsub.Topic(`story-approved-${environment}`, {
    name: `story-writer.story-approved.${environment}`,
    messageRetentionDuration: '86400s',
  });

  const jiraPushed = new gcp.pubsub.Topic(`jira-pushed-${environment}`, {
    name: `story-writer.jira-pushed.${environment}`,
    messageRetentionDuration: '86400s',
  });

  new gcp.pubsub.Subscription(`story-generated-audit-${environment}`, {
    topic: storyGenerated.name,
    ackDeadlineSeconds: 60,
    messageRetentionDuration: '604800s',
    retainAckedMessages: true,
    expirationPolicy: { ttl: '' },
  });

  new gcp.pubsub.Subscription(`story-approved-push-${environment}`, {
    topic: storyApproved.name,
    ackDeadlineSeconds: 60,
    messageRetentionDuration: '604800s',
  });

  new gcp.pubsub.Subscription(`jira-pushed-notify-${environment}`, {
    topic: jiraPushed.name,
    ackDeadlineSeconds: 60,
    messageRetentionDuration: '604800s',
  });

  return {
    'story-generated': storyGenerated,
    'story-approved': storyApproved,
    'jira-pushed': jiraPushed,
  };
}
