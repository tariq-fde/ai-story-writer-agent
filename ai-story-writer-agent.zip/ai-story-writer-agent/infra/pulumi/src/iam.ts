import * as gcp from '@pulumi/gcp';

export function createServiceAccount(environment: string) {
  return new gcp.serviceaccount.Account(`story-writer-sa-${environment}`, {
    accountId: `story-writer-${environment}`,
    displayName: `AI Story Writer Service Account (${environment})`,
  });
}

export function createIamBindings(
  environment: string,
  serviceAccount: gcp.serviceaccount.Account,
) {
  const roles = [
    'roles/datastore.user',
    'roles/pubsub.publisher',
    'roles/secretmanager.secretAccessor',
    'roles/run.invoker',
  ];

  for (const role of roles) {
    const roleSuffix = role.split('/').pop()!.replace(/\./g, '-');
    new gcp.projects.IAMMember(`sa-${roleSuffix}-${environment}`, {
      project: gcp.config.project!,
      role,
      member: serviceAccount.email.apply((email) => `serviceAccount:${email}`),
    });
  }
}
