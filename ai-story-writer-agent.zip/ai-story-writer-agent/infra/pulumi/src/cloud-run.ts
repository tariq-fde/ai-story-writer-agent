import * as gcp from '@pulumi/gcp';
import * as pulumi from '@pulumi/pulumi';

interface CloudRunDeps {
  serviceAccount: gcp.serviceaccount.Account;
  registry: { repositoryUrl: pulumi.Output<string> };
  secrets: Record<string, gcp.secretmanager.Secret>;
  firestore: { databaseName: pulumi.Output<string> };
  pubsub: Record<string, gcp.pubsub.Topic>;
}

export function createCloudRunService(environment: string, deps: CloudRunDeps) {
  const config = new pulumi.Config('ai-story-writer');
  const minInstances = config.getNumber('minInstances') ?? 0;
  const maxInstances = config.getNumber('maxInstances') ?? 10;

  const service = new gcp.cloudrunv2.Service(`story-writer-service-${environment}`, {
    location: gcp.config.region!,
    template: {
      serviceAccount: deps.serviceAccount.email,
      scaling: {
        minInstanceCount: minInstances,
        maxInstanceCount: maxInstances,
      },
      containers: [
        {
          image: pulumi.interpolate`${deps.registry.repositoryUrl}/story-writer-service:latest`,
          ports: [{ containerPort: 8080 }],
          resources: {
            limits: {
              cpu: '1',
              memory: '512Mi',
            },
          },
          envs: [
            { name: 'NODE_ENV', value: 'production' },
            { name: 'ENVIRONMENT', value: environment },
            {
              name: 'ANTHROPIC_API_KEY',
              valueSource: {
                secretKeyRef: {
                  secret: deps.secrets['anthropic-key'].secretId,
                  version: 'latest',
                },
              },
            },
            {
              name: 'JIRA_API_TOKEN',
              valueSource: {
                secretKeyRef: {
                  secret: deps.secrets['jira-token'].secretId,
                  version: 'latest',
                },
              },
            },
            {
              name: 'CONFLUENCE_API_TOKEN',
              valueSource: {
                secretKeyRef: {
                  secret: deps.secrets['confluence-token'].secretId,
                  version: 'latest',
                },
              },
            },
            {
              name: 'GITHUB_PAT',
              valueSource: {
                secretKeyRef: {
                  secret: deps.secrets['github-pat'].secretId,
                  version: 'latest',
                },
              },
            },
          ],
        },
      ],
      timeout: '300s',
      maxInstanceRequestConcurrency: 10,
    },
  });

  const serviceUrl = service.uri;

  return { service, serviceUrl };
}
