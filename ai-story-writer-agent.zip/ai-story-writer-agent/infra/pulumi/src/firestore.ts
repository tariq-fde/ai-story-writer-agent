import * as gcp from '@pulumi/gcp';

export function createFirestore(environment: string) {
  const database = new gcp.firestore.Database(`story-writer-db-${environment}`, {
    locationId: gcp.config.region!,
    type: 'FIRESTORE_NATIVE',
  });

  new gcp.firestore.Index(`idx-generation-runs-${environment}`, {
    database: database.name,
    collection: 'generation_runs',
    fields: [
      { fieldPath: 'prdId', order: 'ASCENDING' },
      { fieldPath: 'startedAt', order: 'DESCENDING' },
    ],
  });

  new gcp.firestore.Index(`idx-story-previews-${environment}`, {
    database: database.name,
    collection: 'story_previews',
    fields: [
      { fieldPath: 'runId', order: 'ASCENDING' },
      { fieldPath: 'createdAt', order: 'DESCENDING' },
    ],
  });

  new gcp.firestore.Index(`idx-review-sessions-${environment}`, {
    database: database.name,
    collection: 'review_sessions',
    fields: [
      { fieldPath: 'previewId', order: 'ASCENDING' },
      { fieldPath: 'updatedAt', order: 'DESCENDING' },
    ],
  });

  const databaseName = database.name;

  return { database, databaseName };
}
